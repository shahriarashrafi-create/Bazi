# Module 09/20 — Minion Task System

Independent module: `:feature:minions`

## Purpose

This module connects real-life Tasks to enemy Minions inside the 30-minute battle.

## Implemented gameplay rules

- Task -> Minion binding
- Priority-based deterministic spawn planning
- Lane-aware task binding
- World positions for minions
- Interaction-range detection
- Encounter focus
- Cinematic encounter panel
- COMPLETE
- LATER
- SWAP 1/1
- REMOVE FROM MATCH
- Task Library remains untouched when removing from a Match
- Later causes smaller enemy pressure
- Remove causes stronger enemy pressure
- Completion grants XP / Gold / optional rare Diamond
- Bridge into Module 07 MatchEngine
- Encounter HUD
- Threat levels
- Unit tests

## Architectural rules

UI does not mutate MatchState directly.
`MinionResolutionReducer` is the bridge between encounter decisions and MatchEngine.

The module depends only on public contracts from:
- core:model
- core:designsystem
- feature:tasks
- feature:match
- feature:map

## Next

Module 10 will implement:
- Tower health
- Core health
- enemy pressure damage
- Later / Remove damage application
- tower destruction
- victory / defeat graph
- balanced objective rules
