package com.herolife.feature.minions

import com.herolife.core.model.GameLane
import com.herolife.core.model.TaskPriority
import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.minions.domain.MinionSpawnPlanner
import com.herolife.feature.tasks.model.ManagedTask
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MinionSpawnPlannerTest {

    @Test
    fun criticalTaskIsPlacedBeforeLowPriorityTask() {
        val low = ManagedTask(
            id = "low",
            title = "Low",
            priority = TaskPriority.LOW,
            lane = GameLane.PERSONAL
        )

        val critical = ManagedTask(
            id = "critical",
            title = "Critical",
            priority = TaskPriority.CRITICAL,
            lane = GameLane.NETWORKING
        )

        val result = MinionSpawnPlanner.bindTasks(
            tasks = listOf(low, critical),
            laneStart = WorldPoint(0f, 0f),
            laneEnd = WorldPoint(1000f, 0f),
            maximum = 2
        )

        assertEquals("critical", result.first().taskId)
    }

    @Test
    fun positionsStayInsideLaneSegment() {
        val task = ManagedTask(
            id = "t1",
            title = "Task"
        )

        val result = MinionSpawnPlanner.bindTasks(
            tasks = listOf(task),
            laneStart = WorldPoint(100f, 200f),
            laneEnd = WorldPoint(900f, 200f),
            maximum = 1
        )

        assertTrue(result.first().worldPosition.x in 100f..900f)
    }
}
