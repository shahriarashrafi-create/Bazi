package com.herolife.feature.minions

import com.herolife.core.model.GameLane
import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.minions.domain.MinionEncounterEngine
import com.herolife.feature.minions.model.EncounterAction
import com.herolife.feature.minions.model.EncounterStatus
import com.herolife.feature.minions.model.MinionEncounterState
import com.herolife.feature.minions.model.MinionTaskBinding
import com.herolife.feature.minions.model.MinionThreatLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MinionEncounterEngineTest {

    private val binding = MinionTaskBinding(
        minionId = "m1",
        taskId = "t1",
        title = "دعوت",
        description = "",
        lane = GameLane.NETWORKING,
        worldPosition = WorldPoint(100f, 100f),
        xpReward = 10,
        goldReward = 5,
        diamondReward = 0,
        estimatedMinutes = 5,
        threatLevel = MinionThreatLevel.LOW
    )

    @Test
    fun heroInRangeGetsEncounter() {
        val state = MinionEncounterEngine.detectEncounter(
            state = MinionEncounterState(),
            heroPosition = WorldPoint(110f, 100f),
            bindings = listOf(binding),
            range = 30f
        )

        assertEquals(EncounterStatus.IN_RANGE, state.status)
        assertEquals("m1", state.focusedMinionId)
    }

    @Test
    fun completeRewardsTask() {
        val result = MinionEncounterEngine.complete(
            state = MinionEncounterState(),
            binding = binding
        )

        assertEquals(EncounterAction.COMPLETE, result.second.action)
        assertEquals(10, result.second.earnedXp)
        assertEquals(5, result.second.earnedGold)
        assertEquals(1, result.first.completedCount)
    }

    @Test
    fun laterPenaltyIsSmallerThanRemovePenalty() {
        val later = MinionEncounterEngine.later(
            MinionEncounterState(),
            binding
        ).second

        val removed = MinionEncounterEngine.removeFromMatch(
            MinionEncounterState(),
            binding
        ).second

        assertTrue(
            removed.enemyPressureDelta > later.enemyPressureDelta
        )
    }

    @Test
    fun swapCanBeConsumedOnlyOnce() {
        val first = MinionEncounterEngine.consumeSwap(
            MinionEncounterState()
        )
        val second = MinionEncounterEngine.consumeSwap(first)

        assertEquals(0, first.swapRemaining)
        assertEquals(0, second.swapRemaining)
    }
}
