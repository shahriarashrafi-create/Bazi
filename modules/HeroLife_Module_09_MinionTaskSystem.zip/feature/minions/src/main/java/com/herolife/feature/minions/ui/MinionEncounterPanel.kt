package com.herolife.feature.minions.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeDivider
import com.herolife.core.designsystem.HeroLifePrimaryButton
import com.herolife.core.designsystem.HeroLifeRadius
import com.herolife.core.designsystem.HeroLifeSpacing
import com.herolife.feature.minions.model.MinionTaskBinding

@Composable
fun MinionEncounterPanel(
    visible: Boolean,
    binding: MinionTaskBinding?,
    swapRemaining: Int,
    onComplete: () -> Unit,
    onLater: () -> Unit,
    onSwap: () -> Unit,
    onRemoveFromMatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible && binding != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 3 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 3 })
    ) {
        if (binding != null) {
            val shape = RoundedCornerShape(HeroLifeRadius.hero)

            Column(
                modifier = modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(
                                HeroLifeColors.SurfaceHighlight,
                                HeroLifeColors.DeepNavy,
                                HeroLifeColors.Void
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            listOf(
                                HeroLifeColors.Gold.copy(alpha = 0.55f),
                                HeroLifeColors.Crystal.copy(alpha = 0.35f)
                            )
                        ),
                        shape = shape
                    )
                    .padding(HeroLifeSpacing.lg),
                verticalArrangement = Arrangement.spacedBy(HeroLifeSpacing.sm)
            ) {
                Text(
                    text = "مواجهه با مأموریت",
                    style = MaterialTheme.typography.labelLarge,
                    color = HeroLifeColors.Crystal
                )

                Text(
                    text = binding.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )

                if (binding.description.isNotBlank()) {
                    Text(
                        text = binding.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = HeroLifeColors.TextSecondary
                    )
                }

                HeroLifeDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${binding.estimatedMinutes} دقیقه",
                        color = HeroLifeColors.TextSecondary
                    )

                    Text(
                        text = "XP ${binding.xpReward}",
                        color = HeroLifeColors.Crystal
                    )

                    Text(
                        text = "🪙 ${binding.goldReward}",
                        color = HeroLifeColors.Gold
                    )
                }

                HeroLifePrimaryButton(
                    text = "⚔ انجام کار",
                    onClick = onComplete,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedButton(
                    onClick = onLater,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(HeroLifeRadius.medium),
                    border = BorderStroke(
                        1.dp,
                        HeroLifeColors.Warning.copy(alpha = 0.65f)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HeroLifeColors.Warning
                    )
                ) {
                    Text("⏳ بعداً")
                }

                OutlinedButton(
                    onClick = onSwap,
                    enabled = swapRemaining > 0,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(HeroLifeRadius.medium),
                    border = BorderStroke(
                        1.dp,
                        HeroLifeColors.Crystal.copy(alpha = 0.65f)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HeroLifeColors.Crystal
                    )
                ) {
                    Text("🔄 تعویض ${swapRemaining}/1")
                }

                OutlinedButton(
                    onClick = onRemoveFromMatch,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(HeroLifeRadius.medium),
                    border = BorderStroke(
                        1.dp,
                        HeroLifeColors.Danger.copy(alpha = 0.62f)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HeroLifeColors.Danger
                    )
                ) {
                    Text("✖ حذف از این بازی")
                }

                Text(
                    text = "«حذف از این بازی» فقط همین Match را تغییر می‌دهد و Task اصلی حذف نمی‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = HeroLifeColors.TextMuted
                )
            }
        }
    }
}
