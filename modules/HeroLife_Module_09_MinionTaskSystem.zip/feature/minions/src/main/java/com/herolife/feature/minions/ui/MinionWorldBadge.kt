package com.herolife.feature.minions.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeRadius
import com.herolife.feature.minions.model.MinionTaskBinding
import com.herolife.feature.minions.model.MinionThreatLevel

@Composable
fun MinionWorldBadge(
    binding: MinionTaskBinding,
    modifier: Modifier = Modifier
) {
    val accent: Color = when (binding.threatLevel) {
        MinionThreatLevel.LOW -> HeroLifeColors.Success
        MinionThreatLevel.MEDIUM -> HeroLifeColors.Crystal
        MinionThreatLevel.HIGH -> HeroLifeColors.Warning
        MinionThreatLevel.CRITICAL -> HeroLifeColors.Danger
    }

    val shape = RoundedCornerShape(HeroLifeRadius.medium)

    Column(
        modifier = modifier
            .clip(shape)
            .background(HeroLifeColors.Overlay)
            .border(1.dp, accent.copy(alpha = 0.65f), shape)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = binding.title,
            style = MaterialTheme.typography.labelLarge,
            color = HeroLifeColors.TextPrimary,
            maxLines = 1
        )

        Text(
            text = "${binding.estimatedMinutes} دقیقه • ${binding.threatLevel.name}",
            style = MaterialTheme.typography.bodySmall,
            color = accent
        )
    }
}
