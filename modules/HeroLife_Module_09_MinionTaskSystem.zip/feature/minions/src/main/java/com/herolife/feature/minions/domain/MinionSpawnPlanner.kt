package com.herolife.feature.minions.domain

import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.minions.model.MinionTaskBinding
import com.herolife.feature.tasks.model.ManagedTask

/**
 * Deterministic task -> minion placement.
 *
 * The visual renderer can later replace these positions with authored lane curves,
 * but the gameplay contract stays stable.
 */
object MinionSpawnPlanner {

    fun bindTasks(
        tasks: List<ManagedTask>,
        laneStart: WorldPoint,
        laneEnd: WorldPoint,
        maximum: Int = 8
    ): List<MinionTaskBinding> {
        if (maximum <= 0) return emptyList()

        val selected = tasks
            .filter { it.isActive }
            .sortedWith(
                compareBy<ManagedTask>(
                    { priorityRank(it) * -1 },
                    { it.sortOrder },
                    { it.estimatedMinutes }
                )
            )
            .take(maximum)

        if (selected.isEmpty()) return emptyList()

        val dx = laneEnd.x - laneStart.x
        val dy = laneEnd.y - laneStart.y
        val denominator = (selected.size + 1).toFloat()

        return selected.mapIndexed { index, task ->
            val t = (index + 1).toFloat() / denominator
            val point = WorldPoint(
                x = laneStart.x + dx * t,
                y = laneStart.y + dy * t
            )

            MinionTaskBinding.fromTask(
                minionId = "minion_${task.id}",
                task = task,
                worldPosition = point
            )
        }
    }

    private fun priorityRank(task: ManagedTask): Int =
        when (task.priority.name) {
            "CRITICAL" -> 4
            "HIGH" -> 3
            "MEDIUM" -> 2
            else -> 1
        }
}
