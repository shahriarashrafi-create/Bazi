package com.herolife.feature.minions.domain

import com.herolife.feature.match.domain.MatchEngine
import com.herolife.feature.match.model.MatchState
import com.herolife.feature.minions.model.EncounterAction
import com.herolife.feature.minions.model.MinionResolution

/**
 * Bridges Module 09 encounter decisions into Module 07 MatchEngine
 * without making the UI aware of Match internals.
 */
object MinionResolutionReducer {

    fun apply(
        engine: MatchEngine,
        match: MatchState,
        resolution: MinionResolution
    ): MatchState =
        when (resolution.action) {
            EncounterAction.COMPLETE -> engine.completeTask(
                state = match,
                taskId = resolution.binding.taskId,
                xp = resolution.earnedXp,
                gold = resolution.earnedGold,
                diamonds = resolution.earnedDiamonds
            )

            EncounterAction.LATER -> engine.markLater(
                state = match,
                taskId = resolution.binding.taskId
            )

            EncounterAction.REMOVE_FROM_MATCH -> engine.removeFromMatch(
                state = match,
                taskId = resolution.binding.taskId
            )

            EncounterAction.SWAP -> engine.useSwap(match)
        }
}
