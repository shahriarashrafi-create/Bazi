package com.herolife.feature.minions.model

import com.herolife.core.model.GameLane
import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.tasks.model.ManagedTask

enum class MinionThreatLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

enum class EncounterAction {
    COMPLETE,
    LATER,
    SWAP,
    REMOVE_FROM_MATCH
}

enum class EncounterStatus {
    IDLE,
    IN_RANGE,
    PANEL_OPEN,
    RESOLVED
}

data class MinionTaskBinding(
    val minionId: String,
    val taskId: String,
    val title: String,
    val description: String,
    val lane: GameLane,
    val worldPosition: WorldPoint,
    val xpReward: Int,
    val goldReward: Int,
    val diamondReward: Int,
    val estimatedMinutes: Int,
    val threatLevel: MinionThreatLevel,
    val active: Boolean = true
) {
    init {
        require(minionId.isNotBlank())
        require(taskId.isNotBlank())
        require(title.isNotBlank())
        require(xpReward >= 0)
        require(goldReward >= 0)
        require(diamondReward >= 0)
        require(estimatedMinutes > 0)
    }

    companion object {
        fun fromTask(
            minionId: String,
            task: ManagedTask,
            worldPosition: WorldPoint
        ): MinionTaskBinding {
            val threat = when {
                task.estimatedMinutes >= 25 -> MinionThreatLevel.CRITICAL
                task.estimatedMinutes >= 15 -> MinionThreatLevel.HIGH
                task.estimatedMinutes >= 8 -> MinionThreatLevel.MEDIUM
                else -> MinionThreatLevel.LOW
            }

            return MinionTaskBinding(
                minionId = minionId,
                taskId = task.id,
                title = task.title,
                description = task.description,
                lane = task.lane,
                worldPosition = worldPosition,
                xpReward = task.xpReward,
                goldReward = task.goldReward,
                diamondReward = task.diamondReward,
                estimatedMinutes = task.estimatedMinutes,
                threatLevel = threat
            )
        }
    }
}

data class MinionEncounterState(
    val status: EncounterStatus = EncounterStatus.IDLE,
    val focusedMinionId: String? = null,
    val swapRemaining: Int = 1,
    val completedCount: Int = 0,
    val laterCount: Int = 0,
    val removedCount: Int = 0,
    val lastAction: EncounterAction? = null
) {
    init {
        require(swapRemaining in 0..1)
        require(completedCount >= 0)
        require(laterCount >= 0)
        require(removedCount >= 0)
    }
}

data class MinionResolution(
    val binding: MinionTaskBinding,
    val action: EncounterAction,
    val earnedXp: Int = 0,
    val earnedGold: Int = 0,
    val earnedDiamonds: Int = 0,
    val enemyPressureDelta: Int = 0
)
