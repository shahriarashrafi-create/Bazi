package com.herolife.feature.minions.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeHudBadge
import com.herolife.feature.minions.model.MinionEncounterState

@Composable
fun EncounterHud(
    state: MinionEncounterState,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        HeroLifeHudBadge(
            title = "انجام",
            value = state.completedCount.toString(),
            accent = HeroLifeColors.Success
        )

        HeroLifeHudBadge(
            title = "بعداً",
            value = state.laterCount.toString(),
            accent = HeroLifeColors.Warning
        )

        HeroLifeHudBadge(
            title = "تعویض",
            value = "${state.swapRemaining}/1",
            accent = HeroLifeColors.Crystal
        )
    }
}
