package com.herolife.feature.minions.domain

import com.herolife.feature.map.domain.MovementEngine
import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.minions.model.EncounterAction
import com.herolife.feature.minions.model.EncounterStatus
import com.herolife.feature.minions.model.MinionEncounterState
import com.herolife.feature.minions.model.MinionResolution
import com.herolife.feature.minions.model.MinionTaskBinding

/**
 * Pure encounter engine.
 *
 * Important product rules:
 * - COMPLETE is rewarded.
 * - LATER keeps the minion alive and applies a small pressure penalty.
 * - REMOVE_FROM_MATCH does not delete Task Library data and applies a stronger penalty.
 * - SWAP is available at most once per match.
 */
object MinionEncounterEngine {

    const val DEFAULT_INTERACTION_RANGE = 120f
    const val LATER_PRESSURE_PENALTY = 6
    const val REMOVE_PRESSURE_PENALTY = 14

    fun detectEncounter(
        state: MinionEncounterState,
        heroPosition: WorldPoint,
        bindings: List<MinionTaskBinding>,
        range: Float = DEFAULT_INTERACTION_RANGE
    ): MinionEncounterState {
        val nearest = bindings
            .asSequence()
            .filter { it.active }
            .map { binding ->
                binding to MovementEngine.distanceTo(
                    heroPosition,
                    binding.worldPosition
                )
            }
            .filter { pair -> pair.second <= range }
            .minByOrNull { pair -> pair.second }
            ?.first

        return if (nearest == null) {
            if (state.status == EncounterStatus.PANEL_OPEN) {
                state
            } else {
                state.copy(
                    status = EncounterStatus.IDLE,
                    focusedMinionId = null
                )
            }
        } else {
            state.copy(
                status = EncounterStatus.IN_RANGE,
                focusedMinionId = nearest.minionId
            )
        }
    }

    fun openPanel(
        state: MinionEncounterState,
        minionId: String
    ): MinionEncounterState {
        require(minionId.isNotBlank())

        return state.copy(
            status = EncounterStatus.PANEL_OPEN,
            focusedMinionId = minionId
        )
    }

    fun closePanel(
        state: MinionEncounterState
    ): MinionEncounterState =
        state.copy(
            status = EncounterStatus.IN_RANGE
        )

    fun complete(
        state: MinionEncounterState,
        binding: MinionTaskBinding
    ): Pair<MinionEncounterState, MinionResolution> {
        val nextState = state.copy(
            status = EncounterStatus.RESOLVED,
            focusedMinionId = binding.minionId,
            completedCount = state.completedCount + 1,
            lastAction = EncounterAction.COMPLETE
        )

        val resolution = MinionResolution(
            binding = binding,
            action = EncounterAction.COMPLETE,
            earnedXp = binding.xpReward,
            earnedGold = binding.goldReward,
            earnedDiamonds = binding.diamondReward,
            enemyPressureDelta = 0
        )

        return nextState to resolution
    }

    fun later(
        state: MinionEncounterState,
        binding: MinionTaskBinding
    ): Pair<MinionEncounterState, MinionResolution> {
        val nextState = state.copy(
            status = EncounterStatus.RESOLVED,
            focusedMinionId = binding.minionId,
            laterCount = state.laterCount + 1,
            lastAction = EncounterAction.LATER
        )

        val resolution = MinionResolution(
            binding = binding,
            action = EncounterAction.LATER,
            enemyPressureDelta = LATER_PRESSURE_PENALTY
        )

        return nextState to resolution
    }

    fun removeFromMatch(
        state: MinionEncounterState,
        binding: MinionTaskBinding
    ): Pair<MinionEncounterState, MinionResolution> {
        val nextState = state.copy(
            status = EncounterStatus.RESOLVED,
            focusedMinionId = binding.minionId,
            removedCount = state.removedCount + 1,
            lastAction = EncounterAction.REMOVE_FROM_MATCH
        )

        val resolution = MinionResolution(
            binding = binding,
            action = EncounterAction.REMOVE_FROM_MATCH,
            enemyPressureDelta = REMOVE_PRESSURE_PENALTY
        )

        return nextState to resolution
    }

    fun consumeSwap(
        state: MinionEncounterState
    ): MinionEncounterState {
        if (state.swapRemaining <= 0) return state

        return state.copy(
            status = EncounterStatus.RESOLVED,
            swapRemaining = 0,
            lastAction = EncounterAction.SWAP
        )
    }
}
