# Module 03/20 — Profile & Player

این ZIP یک ماژول مستقل Gradle با مسیر زیر اضافه می‌کند:

`:feature:profile`

## مسئولیت ماژول

- مدل پروفایل بازیکن
- نام نمایشی
- عنوان Hero
- Level
- XP
- Gold
- Diamond
- Avatar key
- Repository contract
- In-memory implementation برای مرحله فعلی
- ProfileCard قابل استفاده در Compose
- Unit test پایه

## وابستگی‌ها

این ماژول فقط به قراردادهای عمومی زیر وابسته است:

- `:core:model`
- `:core:designsystem`

به `app` وابسته نیست.

## آماده برای مراحل بعدی

در ماژول‌های بعدی می‌توان persistence واقعی، انتخاب Hero،
ویرایش پروفایل، Achievement title و اطلاعات بیشتر را بدون شکستن API فعلی اضافه کرد.
