package com.herolife.feature.profile

import com.herolife.feature.profile.model.PlayerProfile
import org.junit.Assert.assertEquals
import org.junit.Test

class PlayerProfileTest {

    @Test
    fun xpProgress_isCalculatedCorrectly() {
        val profile = PlayerProfile(
            id = "1",
            displayName = "Test",
            heroTitle = "Warrior",
            level = 2,
            xp = 50,
            xpToNextLevel = 100,
            gold = 10,
            diamonds = 1
        )

        assertEquals(0.5f, profile.xpProgress, 0.001f)
    }
}
