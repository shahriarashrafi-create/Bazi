package com.herolife.feature.profile.data

import com.herolife.feature.profile.model.PlayerProfile

class InMemoryProfileRepository(
    initialProfile: PlayerProfile = defaultProfile()
) : ProfileRepository {

    private var profile: PlayerProfile = initialProfile

    override fun getProfile(): PlayerProfile = profile

    override fun updateProfile(profile: PlayerProfile) {
        this.profile = profile
    }

    companion object {
        fun defaultProfile() = PlayerProfile(
            id = "local-player",
            displayName = "بازیکن",
            heroTitle = "جنگنده",
            level = 1,
            xp = 0,
            xpToNextLevel = 100,
            gold = 0,
            diamonds = 0
        )
    }
}
