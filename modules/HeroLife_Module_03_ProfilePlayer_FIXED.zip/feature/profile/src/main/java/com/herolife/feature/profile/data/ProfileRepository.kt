package com.herolife.feature.profile.data

import com.herolife.feature.profile.model.PlayerProfile

interface ProfileRepository {
    fun getProfile(): PlayerProfile
    fun updateProfile(profile: PlayerProfile)
}
