package com.herolife.feature.profile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.core.designsystem.HeroLifeXpBar
import com.herolife.feature.profile.model.PlayerProfile

@Composable
fun ProfileCard(
    profile: PlayerProfile,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = profile.displayName,
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            text = profile.heroTitle,
            style = MaterialTheme.typography.titleMedium,
            color = HeroLifeColors.Gold
        )

        Text(
            text = "سطح ${profile.level}",
            style = MaterialTheme.typography.titleLarge
        )

        HeroLifeXpBar(progress = profile.xpProgress)

        Text(
            text = "${profile.xp} / ${profile.xpToNextLevel} XP",
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextSecondary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            HeroLifeStatChip(
                label = "طلا",
                value = "🪙 ${profile.gold}",
                accent = HeroLifeColors.Gold,
                modifier = Modifier.weight(1f)
            )

            HeroLifeStatChip(
                label = "الماس",
                value = "💎 ${profile.diamonds}",
                accent = HeroLifeColors.Crystal,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
