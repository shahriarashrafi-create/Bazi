package com.herolife.feature.profile.model

data class PlayerProfile(
    val id: String,
    val displayName: String,
    val heroTitle: String,
    val level: Int,
    val xp: Int,
    val xpToNextLevel: Int,
    val gold: Long,
    val diamonds: Long,
    val avatarKey: String? = null
) {
    init {
        require(id.isNotBlank()) { "id must not be blank" }
        require(displayName.isNotBlank()) { "displayName must not be blank" }
        require(level >= 1) { "level must be at least 1" }
        require(xp >= 0) { "xp must not be negative" }
        require(xpToNextLevel > 0) { "xpToNextLevel must be greater than 0" }
        require(gold >= 0) { "gold must not be negative" }
        require(diamonds >= 0) { "diamonds must not be negative" }
    }

    val xpProgress: Float
        get() = (xp.toFloat() / xpToNextLevel.toFloat()).coerceIn(0f, 1f)
}
