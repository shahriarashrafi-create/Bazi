package com.herolife.feature.achievements.domain

import com.herolife.feature.achievements.model.AchievementDefinition
import com.herolife.feature.achievements.model.AchievementProgress
import com.herolife.feature.economy.domain.EconomyEngine
import com.herolife.feature.economy.model.DailyEconomyUsage
import com.herolife.feature.economy.model.EconomyApplyResult
import com.herolife.feature.economy.model.EconomyWallet
import com.herolife.feature.economy.model.WeeklyEconomyUsage

object AchievementRewardBridge {

    fun claimReward(
        economyEngine: EconomyEngine,
        wallet: EconomyWallet,
        definition: AchievementDefinition,
        progress: AchievementProgress,
        dailyUsage: DailyEconomyUsage,
        weeklyUsage: WeeklyEconomyUsage
    ): Pair<AchievementProgress, EconomyApplyResult> {
        require(progress.unlocked)
        require(!progress.claimed)

        val economyResult =
            economyEngine.apply(
                wallet = wallet,
                requested = definition.reward,
                dailyUsage = dailyUsage,
                weeklyUsage = weeklyUsage
            )

        val claimed =
            AchievementEngine.claim(
                definition = definition,
                progress = progress
            )

        return claimed to economyResult
    }
}
