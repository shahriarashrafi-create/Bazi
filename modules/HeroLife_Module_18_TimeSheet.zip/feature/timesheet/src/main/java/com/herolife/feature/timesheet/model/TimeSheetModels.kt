package com.herolife.feature.timesheet.model

enum class TimeBlockCategory {
    NETWORKING,
    PERSONAL_GROWTH,
    PERSONAL,
    TEAM,
    EVENT,
    ADMIN,
    REST
}

enum class TimeBlockPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

enum class ReminderType {
    NONE,
    AT_START,
    FIVE_MINUTES_BEFORE,
    TEN_MINUTES_BEFORE,
    THIRTY_MINUTES_BEFORE
}

data class TimeBlock(
    val id: String,
    val title: String,
    val description: String = "",
    val startAtMillis: Long,
    val endAtMillis: Long,
    val category: TimeBlockCategory,
    val priority: TimeBlockPriority = TimeBlockPriority.MEDIUM,
    val reminder: ReminderType = ReminderType.TEN_MINUTES_BEFORE,
    val completed: Boolean = false,
    val archived: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(title.isNotBlank())
        require(startAtMillis >= 0L)
        require(endAtMillis > startAtMillis)
    }

    val durationMillis: Long
        get() = endAtMillis - startAtMillis
}

data class DayPlan(
    val dayStartMillis: Long,
    val blocks: List<TimeBlock>
) {
    init {
        require(dayStartMillis >= 0L)
    }
}

data class WeekPlan(
    val weekStartMillis: Long,
    val days: List<DayPlan>
) {
    init {
        require(weekStartMillis >= 0L)
    }
}

data class TimeUsageSnapshot(
    val totalScheduledMillis: Long,
    val completedMillis: Long,
    val focusedMillis: Long,
    val freeMillis: Long,
    val completionRate: Float,
    val categoryMillis: Map<TimeBlockCategory, Long>
)
