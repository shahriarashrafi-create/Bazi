package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.TimeBlock

data class TimeConflict(
    val firstBlockId: String,
    val secondBlockId: String,
    val overlapMillis: Long
)

object TimeSheetEngine {

    fun validateNoOverlap(
        blocks: List<TimeBlock>
    ): List<TimeConflict> {
        val active = blocks
            .filterNot { it.archived }
            .sortedBy { it.startAtMillis }

        val conflicts = mutableListOf<TimeConflict>()

        for (i in active.indices) {
            val a = active[i]

            for (j in (i + 1) until active.size) {
                val b = active[j]

                if (b.startAtMillis >= a.endAtMillis) {
                    break
                }

                val overlap =
                    minOf(a.endAtMillis, b.endAtMillis) -
                        maxOf(a.startAtMillis, b.startAtMillis)

                if (overlap > 0L) {
                    conflicts += TimeConflict(
                        firstBlockId = a.id,
                        secondBlockId = b.id,
                        overlapMillis = overlap
                    )
                }
            }
        }

        return conflicts
    }

    fun blocksForRange(
        blocks: List<TimeBlock>,
        startMillis: Long,
        endMillis: Long
    ): List<TimeBlock> {
        require(endMillis > startMillis)

        return blocks
            .filterNot { it.archived }
            .filter {
                it.startAtMillis < endMillis &&
                    it.endAtMillis > startMillis
            }
            .sortedBy { it.startAtMillis }
    }

    fun complete(
        block: TimeBlock
    ): TimeBlock =
        block.copy(completed = true)
}
