package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.TimeBlock

class InMemoryTimeSheetRepository : TimeSheetRepository {

    private val blocks = linkedMapOf<String, TimeBlock>()

    override fun allBlocks(): List<TimeBlock> =
        blocks.values.toList()

    override fun blockById(id: String): TimeBlock? =
        blocks[id]

    override fun save(block: TimeBlock) {
        blocks[block.id] = block
    }

    override fun archive(id: String) {
        val current = blocks[id] ?: return
        blocks[id] = current.copy(archived = true)
    }

    override fun delete(id: String) {
        blocks.remove(id)
    }
}
