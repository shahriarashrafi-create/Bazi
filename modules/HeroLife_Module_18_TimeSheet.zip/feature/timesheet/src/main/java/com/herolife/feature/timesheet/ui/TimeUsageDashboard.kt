package com.herolife.feature.timesheet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.feature.timesheet.model.TimeUsageSnapshot

@Composable
fun TimeUsageDashboard(
    snapshot: TimeUsageSnapshot,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "Time Sheet",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        LinearProgressIndicator(
            progress = {
                snapshot.completionRate
            },
            modifier = Modifier.fillMaxWidth(),
            color = HeroLifeColors.Success,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                label = "برنامه‌ریزی",
                value = minutes(snapshot.totalScheduledMillis),
                accent = HeroLifeColors.Crystal,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "انجام شده",
                value = minutes(snapshot.completedMillis),
                accent = HeroLifeColors.Success,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "زمان آزاد",
                value = minutes(snapshot.freeMillis),
                accent = HeroLifeColors.Gold,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

private fun minutes(
    millis: Long
): String =
    "${millis / 60_000L} دقیقه"
