package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.TimeBlock
import com.herolife.feature.timesheet.model.TimeUsageSnapshot

object TimeUsageEngine {

    private const val DAY_MILLIS =
        24L * 60L * 60L * 1000L

    fun daySnapshot(
        blocks: List<TimeBlock>
    ): TimeUsageSnapshot {
        val active =
            blocks.filterNot { it.archived }

        val scheduled =
            active.sumOf { it.durationMillis }

        val completed =
            active.filter { it.completed }
                .sumOf { it.durationMillis }

        val focused =
            active.filter {
                it.category.name != "REST"
            }.sumOf { it.durationMillis }

        val free =
            (DAY_MILLIS - scheduled)
                .coerceAtLeast(0L)

        val rate =
            if (scheduled == 0L) {
                0f
            } else {
                (
                    completed.toDouble() /
                        scheduled.toDouble()
                    )
                    .toFloat()
                    .coerceIn(0f, 1f)
            }

        return TimeUsageSnapshot(
            totalScheduledMillis = scheduled,
            completedMillis = completed,
            focusedMillis = focused,
            freeMillis = free,
            completionRate = rate,
            categoryMillis = active
                .groupBy { it.category }
                .mapValues { (_, values) ->
                    values.sumOf { it.durationMillis }
                }
        )
    }
}
