package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.DayPlan
import com.herolife.feature.timesheet.model.TimeBlock
import com.herolife.feature.timesheet.model.WeekPlan

object PlanBuilder {

    private const val DAY_MILLIS =
        24L * 60L * 60L * 1000L

    fun day(
        dayStartMillis: Long,
        blocks: List<TimeBlock>
    ): DayPlan =
        DayPlan(
            dayStartMillis = dayStartMillis,
            blocks = TimeSheetEngine.blocksForRange(
                blocks = blocks,
                startMillis = dayStartMillis,
                endMillis = dayStartMillis + DAY_MILLIS
            )
        )

    fun week(
        weekStartMillis: Long,
        blocks: List<TimeBlock>
    ): WeekPlan {
        val days =
            (0 until 7).map { offset ->
                day(
                    dayStartMillis =
                        weekStartMillis +
                            offset * DAY_MILLIS,
                    blocks = blocks
                )
            }

        return WeekPlan(
            weekStartMillis = weekStartMillis,
            days = days
        )
    }
}
