package com.herolife.feature.timesheet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.timesheet.model.TimeBlock

@Composable
fun TimeBlockCard(
    block: TimeBlock,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = block.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = HeroLifeColors.TextPrimary
                )

                Text(
                    text = block.category.name,
                    style = MaterialTheme.typography.bodySmall,
                    color = HeroLifeColors.Crystal
                )
            }

            Text(
                text = if (block.completed) "انجام شد" else "برنامه‌ریزی شده",
                color = if (block.completed) {
                    HeroLifeColors.Success
                } else {
                    HeroLifeColors.Gold
                }
            )
        }

        if (block.description.isNotBlank()) {
            Text(
                text = block.description,
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.TextSecondary
            )
        }

        Text(
            text = "مدت: ${block.durationMillis / 60_000L} دقیقه",
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextMuted
        )
    }
}
