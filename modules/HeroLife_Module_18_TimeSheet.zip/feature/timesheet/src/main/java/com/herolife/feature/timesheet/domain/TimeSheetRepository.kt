package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.TimeBlock

interface TimeSheetRepository {
    fun allBlocks(): List<TimeBlock>
    fun blockById(id: String): TimeBlock?
    fun save(block: TimeBlock)
    fun archive(id: String)
    fun delete(id: String)
}
