package com.herolife.feature.timesheet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.timesheet.model.DayPlan

@Composable
fun DayPlanner(
    plan: DayPlan,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "برنامه روز",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        if (plan.blocks.isEmpty()) {
            Text(
                text = "برای این روز Time Block ثبت نشده.",
                color = HeroLifeColors.TextMuted
            )
        } else {
            plan.blocks.forEach { block ->
                TimeBlockCard(
                    block = block
                )
            }
        }
    }
}
