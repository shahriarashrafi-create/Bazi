package com.herolife.feature.timesheet.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.timesheet.model.WeekPlan

@Composable
fun WeekPlanner(
    plan: WeekPlan,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "برنامه هفتگی",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            plan.days.forEachIndexed { index, day ->
                Text(
                    text = "روز ${index + 1} • ${day.blocks.size} بلوک",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (day.blocks.isEmpty()) {
                        HeroLifeColors.TextMuted
                    } else {
                        HeroLifeColors.Crystal
                    }
                )
            }
        }
    }
}
