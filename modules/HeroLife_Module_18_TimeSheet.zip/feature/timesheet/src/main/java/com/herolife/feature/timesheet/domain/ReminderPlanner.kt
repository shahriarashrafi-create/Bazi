package com.herolife.feature.timesheet.domain

import com.herolife.feature.timesheet.model.ReminderType
import com.herolife.feature.timesheet.model.TimeBlock

data class ReminderSchedule(
    val blockId: String,
    val triggerAtMillis: Long,
    val title: String
)

object ReminderPlanner {

    fun scheduleFor(
        block: TimeBlock
    ): ReminderSchedule? {
        val offset =
            when (block.reminder) {
                ReminderType.NONE -> return null
                ReminderType.AT_START -> 0L
                ReminderType.FIVE_MINUTES_BEFORE -> 5L * 60L * 1000L
                ReminderType.TEN_MINUTES_BEFORE -> 10L * 60L * 1000L
                ReminderType.THIRTY_MINUTES_BEFORE -> 30L * 60L * 1000L
            }

        val trigger =
            (block.startAtMillis - offset)
                .coerceAtLeast(0L)

        return ReminderSchedule(
            blockId = block.id,
            triggerAtMillis = trigger,
            title = block.title
        )
    }
}
