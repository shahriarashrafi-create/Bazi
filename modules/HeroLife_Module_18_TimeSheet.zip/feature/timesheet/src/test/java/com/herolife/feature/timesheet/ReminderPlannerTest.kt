package com.herolife.feature.timesheet

import com.herolife.feature.timesheet.domain.ReminderPlanner
import com.herolife.feature.timesheet.model.ReminderType
import com.herolife.feature.timesheet.model.TimeBlock
import com.herolife.feature.timesheet.model.TimeBlockCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReminderPlannerTest {

    @Test
    fun tenMinuteReminderIsCorrect() {
        val block =
            TimeBlock(
                id = "1",
                title = "Plan",
                startAtMillis = 1_000_000L,
                endAtMillis = 2_000_000L,
                category = TimeBlockCategory.ADMIN,
                reminder = ReminderType.TEN_MINUTES_BEFORE
            )

        val reminder =
            ReminderPlanner.scheduleFor(block)

        assertEquals(
            400_000L,
            reminder?.triggerAtMillis
        )
    }

    @Test
    fun noneReturnsNull() {
        val block =
            TimeBlock(
                id = "1",
                title = "Plan",
                startAtMillis = 1_000_000L,
                endAtMillis = 2_000_000L,
                category = TimeBlockCategory.ADMIN,
                reminder = ReminderType.NONE
            )

        assertNull(
            ReminderPlanner.scheduleFor(block)
        )
    }
}
