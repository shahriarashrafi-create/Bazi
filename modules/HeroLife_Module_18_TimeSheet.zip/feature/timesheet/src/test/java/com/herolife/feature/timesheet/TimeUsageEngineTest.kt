package com.herolife.feature.timesheet

import com.herolife.feature.timesheet.domain.TimeUsageEngine
import com.herolife.feature.timesheet.model.TimeBlock
import com.herolife.feature.timesheet.model.TimeBlockCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TimeUsageEngineTest {

    @Test
    fun completionRateIsCalculated() {
        val blocks = listOf(
            TimeBlock(
                id = "1",
                title = "A",
                startAtMillis = 0,
                endAtMillis = 60_000,
                category = TimeBlockCategory.NETWORKING,
                completed = true
            ),
            TimeBlock(
                id = "2",
                title = "B",
                startAtMillis = 60_000,
                endAtMillis = 120_000,
                category = TimeBlockCategory.PERSONAL
            )
        )

        val snapshot =
            TimeUsageEngine.daySnapshot(blocks)

        assertEquals(120_000L, snapshot.totalScheduledMillis)
        assertTrue(snapshot.completionRate in 0.49f..0.51f)
    }
}
