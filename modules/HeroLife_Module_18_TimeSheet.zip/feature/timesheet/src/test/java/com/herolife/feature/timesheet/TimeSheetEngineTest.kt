package com.herolife.feature.timesheet

import com.herolife.feature.timesheet.domain.TimeSheetEngine
import com.herolife.feature.timesheet.model.TimeBlock
import com.herolife.feature.timesheet.model.TimeBlockCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TimeSheetEngineTest {

    private fun block(
        id: String,
        start: Long,
        end: Long
    ) = TimeBlock(
        id = id,
        title = id,
        startAtMillis = start,
        endAtMillis = end,
        category = TimeBlockCategory.NETWORKING
    )

    @Test
    fun detectsOverlap() {
        val conflicts =
            TimeSheetEngine.validateNoOverlap(
                listOf(
                    block("a", 0, 100),
                    block("b", 50, 150)
                )
            )

        assertEquals(1, conflicts.size)
        assertTrue(conflicts.first().overlapMillis > 0)
    }

    @Test
    fun adjacentBlocksDoNotOverlap() {
        val conflicts =
            TimeSheetEngine.validateNoOverlap(
                listOf(
                    block("a", 0, 100),
                    block("b", 100, 200)
                )
            )

        assertTrue(conflicts.isEmpty())
    }
}
