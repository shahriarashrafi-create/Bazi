# HeroLife Final QA Checklist

## Build
- Android Build is green
- all 20 modules discovered
- debug APK installs
- no startup crash

## Home
- Persian RTL
- hero visible
- level / XP / Gold / Diamond visible
- no Energy
- Start Game CTA works

## Match
- exactly 30-minute duration
- timer continues after app closes
- manual movement only
- no auto-move
- three lanes
- task-minion interactions work
- swap limited to one
- Later / Remove pressure works
- tower/core victory and defeat work
- VFX and announcer triggers work

## Productivity
- task CRUD
- mandatory priority
- CRM prospect lifecycle
- team analytics
- events
- time sheet
- future vision

## Economy
- XP progression
- Gold hero/cosmetics
- Diamonds remain rare
- no loot boxes

## Final UX
- bottom nav has five canonical destinations
- Future Vision remains reachable
- Persian labels render correctly
- no clipped critical controls
- back navigation is predictable
