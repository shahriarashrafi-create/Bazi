# Module 20/20 — Final Integration & Release

Independent module: `:feature:integration`

This is the final architecture module for HeroLife.

## Dependency graph

The integration module declares dependencies on every finished feature:
Profile, Home, Hero, Tasks, Match, Map, Minions, Objectives, VFX, Audio,
Economy, Achievements, CRM, Team, Events, Time Sheet and Future Vision.

It intentionally integrates through stable app-level contracts rather than
importing fragile internal classes from every feature.

## Final app shell

The module provides:
- canonical route registry
- exact five-item bottom navigation:
  Home / Tasks / Team Stats / Time Sheet / Networking
- 30-minute game route
- Future Vision and utility routes
- app coordinator
- game session restoration contract
- non-pausing game timer behavior
- screen-slot composition contract
- release readiness validation
- module registry
- immutable product principles
- final release tests

## Screen-slot integration

`HeroLifeAppShell` accepts `HeroLifeScreenSlots`.

The final application layer can connect each existing feature screen into
these slots without making the integration module depend on unstable screen
implementation names.

This prevents a single renamed Composable from breaking the entire project.

## Canonical release platform

- minSdk 26
- compileSdk 35
- targetSdk 35
- JDK 17
- Gradle 8.7
- Kotlin 1.9.24
- Compose Compiler 1.5.14
- Compose BOM 2024.06.00

## Immutable product rules

- manual hero movement only
- no auto-move
- 30-minute match timer never pauses
- no Energy
- no loot boxes
- no pets
- no bosses
- no hero skills
- XP = progression
- Gold = heroes/cosmetics
- Diamond = rare real-life rewards
- Persian RTL first
- slow long-term Empire growth

## Release sequence

1. Upload Module 20 ZIP into `modules/` without extracting.
2. Commit and wait for Android Build.
3. Confirm green.
4. Run final debug APK smoke test.
5. Verify navigation, 30-minute session restore and RTL.
6. Create signed release configuration only after functional QA.
