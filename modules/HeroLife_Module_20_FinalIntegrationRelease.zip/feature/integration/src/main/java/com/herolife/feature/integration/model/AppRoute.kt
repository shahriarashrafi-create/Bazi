package com.herolife.feature.integration.model

enum class AppRoute {
    HOME,
    TASKS,
    TEAM,
    TIME_SHEET,
    NETWORKING,
    FUTURE_VISION,
    HERO,
    ACHIEVEMENTS,
    EVENTS,
    ECONOMY,
    PROFILE,
    GAME
}

data class RouteSpec(
    val route: AppRoute,
    val titleFa: String,
    val showInBottomBar: Boolean,
    val order: Int
)

object HeroLifeRoutes {
    val all: List<RouteSpec> = listOf(
        RouteSpec(AppRoute.HOME, "خانه", true, 0),
        RouteSpec(AppRoute.TASKS, "کارها", true, 1),
        RouteSpec(AppRoute.TEAM, "آمار تیم", true, 2),
        RouteSpec(AppRoute.TIME_SHEET, "برنامه زمانی", true, 3),
        RouteSpec(AppRoute.NETWORKING, "شبکه‌سازی", true, 4),
        RouteSpec(AppRoute.FUTURE_VISION, "چشم‌انداز آینده", false, 5),
        RouteSpec(AppRoute.HERO, "قهرمان", false, 6),
        RouteSpec(AppRoute.ACHIEVEMENTS, "افتخارات", false, 7),
        RouteSpec(AppRoute.EVENTS, "رویدادها", false, 8),
        RouteSpec(AppRoute.ECONOMY, "اقتصاد", false, 9),
        RouteSpec(AppRoute.PROFILE, "پروفایل", false, 10),
        RouteSpec(AppRoute.GAME, "بازی ۳۰ دقیقه‌ای", false, 11)
    )

    val bottomBar: List<RouteSpec>
        get() = all.filter { it.showInBottomBar }.sortedBy { it.order }
}
