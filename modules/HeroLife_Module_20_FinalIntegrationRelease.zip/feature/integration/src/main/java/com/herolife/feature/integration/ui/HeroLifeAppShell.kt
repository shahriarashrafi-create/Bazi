package com.herolife.feature.integration.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.integration.domain.AppCoordinator
import com.herolife.feature.integration.model.*

@Composable
fun HeroLifeAppShell(
    slots: HeroLifeScreenSlots,
    nowMillis: () -> Long,
    modifier: Modifier = Modifier
) {
    var state by remember { mutableStateOf(AppState()) }

    Scaffold(
        modifier = modifier,
        containerColor = HeroLifeColors.Void,
        bottomBar = {
            if (state.route != AppRoute.GAME) {
                HeroLifeBottomBar(
                    selected = state.route,
                    onSelect = {
                        state = AppCoordinator.reduce(
                            state,
                            AppIntent.Navigate(it)
                        )
                    }
                )
            }
        },
        floatingActionButton = {
            if (state.route == AppRoute.HOME && !state.gameActive) {
                FloatingActionButton(
                    onClick = {
                        state = AppCoordinator.reduce(
                            state,
                            AppIntent.StartGame(nowMillis())
                        )
                    },
                    containerColor = HeroLifeColors.Gold,
                    contentColor = HeroLifeColors.Void
                ) {
                    Text("⚔️")
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (state.route) {
                AppRoute.HOME -> slots.home()
                AppRoute.TASKS -> slots.tasks()
                AppRoute.TEAM -> slots.team()
                AppRoute.TIME_SHEET -> slots.timeSheet()
                AppRoute.NETWORKING -> slots.networking()
                AppRoute.FUTURE_VISION -> slots.futureVision()
                AppRoute.HERO -> slots.hero()
                AppRoute.ACHIEVEMENTS -> slots.achievements()
                AppRoute.EVENTS -> slots.events()
                AppRoute.ECONOMY -> slots.economy()
                AppRoute.PROFILE -> slots.profile()
                AppRoute.GAME -> slots.game()
            }
        }
    }
}
