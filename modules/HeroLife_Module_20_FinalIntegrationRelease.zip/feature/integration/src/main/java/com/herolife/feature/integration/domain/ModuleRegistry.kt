package com.herolife.feature.integration.domain

data class ModuleDescriptor(
    val number: Int,
    val key: String,
    val gradlePath: String,
    val releaseCritical: Boolean = true
)

object ModuleRegistry {
    val modules: List<ModuleDescriptor> = listOf(
        ModuleDescriptor(1, "project-core", ":app"),
        ModuleDescriptor(2, "design-system", ":core:designsystem"),
        ModuleDescriptor(3, "profile", ":feature:profile"),
        ModuleDescriptor(4, "home", ":feature:home"),
        ModuleDescriptor(5, "hero", ":feature:hero"),
        ModuleDescriptor(6, "tasks", ":feature:tasks"),
        ModuleDescriptor(7, "match", ":feature:match"),
        ModuleDescriptor(8, "map", ":feature:map"),
        ModuleDescriptor(9, "minions", ":feature:minions"),
        ModuleDescriptor(10, "objectives", ":feature:objectives"),
        ModuleDescriptor(11, "vfx", ":feature:vfx"),
        ModuleDescriptor(12, "audio", ":feature:audio"),
        ModuleDescriptor(13, "economy", ":feature:economy"),
        ModuleDescriptor(14, "achievements", ":feature:achievements"),
        ModuleDescriptor(15, "crm", ":feature:crm"),
        ModuleDescriptor(16, "team", ":feature:team"),
        ModuleDescriptor(17, "events", ":feature:events"),
        ModuleDescriptor(18, "timesheet", ":feature:timesheet"),
        ModuleDescriptor(19, "vision", ":feature:vision"),
        ModuleDescriptor(20, "integration", ":feature:integration")
    )

    fun requiredKeys(): Set<String> =
        modules.filter { it.releaseCritical }.map { it.key }.toSet()
}
