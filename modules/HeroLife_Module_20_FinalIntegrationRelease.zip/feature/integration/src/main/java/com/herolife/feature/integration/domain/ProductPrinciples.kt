package com.herolife.feature.integration.domain

object ProductPrinciples {
    val immutableRules: List<String> = listOf(
        "30-minute match timer does not pause",
        "Hero movement is manual only",
        "No auto-move",
        "No Energy system",
        "No loot boxes",
        "No pets",
        "No bosses",
        "No hero skill progression",
        "XP controls progression",
        "Gold buys heroes and cosmetics",
        "Diamonds are rare and reserved for real-life rewards",
        "RTL Persian-first experience",
        "Task priority is mandatory",
        "Empire progression remains deliberately slow"
    )
}
