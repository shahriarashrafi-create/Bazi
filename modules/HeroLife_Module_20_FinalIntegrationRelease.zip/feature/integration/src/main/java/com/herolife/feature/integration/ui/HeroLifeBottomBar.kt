package com.herolife.feature.integration.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.integration.model.*

@Composable
fun HeroLifeBottomBar(
    selected: AppRoute,
    onSelect: (AppRoute) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.fillMaxWidth(),
        containerColor = HeroLifeColors.DeepNavy
    ) {
        HeroLifeRoutes.bottomBar.forEach { item ->
            NavigationBarItem(
                selected = selected == item.route,
                onClick = { onSelect(item.route) },
                icon = {
                    Text(
                        text = iconFor(item.route),
                        color = if (selected == item.route) {
                            HeroLifeColors.GoldBright
                        } else {
                            HeroLifeColors.TextMuted
                        }
                    )
                },
                label = {
                    Text(
                        text = item.titleFa,
                        color = if (selected == item.route) {
                            HeroLifeColors.TextPrimary
                        } else {
                            HeroLifeColors.TextMuted
                        }
                    )
                }
            )
        }
    }
}

private fun iconFor(route: AppRoute): String =
    when (route) {
        AppRoute.HOME -> "⌂"
        AppRoute.TASKS -> "✓"
        AppRoute.TEAM -> "♜"
        AppRoute.TIME_SHEET -> "◷"
        AppRoute.NETWORKING -> "◎"
        else -> "•"
    }
