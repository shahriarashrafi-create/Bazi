package com.herolife.feature.integration.domain

data class ReleaseEnvironment(
    val availableModuleKeys: Set<String>,
    val minSdk: Int,
    val targetSdk: Int,
    val compileSdk: Int,
    val jdkMajor: Int,
    val gradleVersion: String,
    val packageName: String,
    val versionName: String
)

data class ReleaseIssue(
    val code: String,
    val message: String,
    val blocking: Boolean
)

data class ReleaseReadiness(
    val ready: Boolean,
    val issues: List<ReleaseIssue>
)

object ReleaseReadinessEngine {

    fun evaluate(
        environment: ReleaseEnvironment
    ): ReleaseReadiness {
        val issues = mutableListOf<ReleaseIssue>()

        val missing =
            ModuleRegistry.requiredKeys() -
                environment.availableModuleKeys

        if (missing.isNotEmpty()) {
            issues += ReleaseIssue(
                code = "MISSING_MODULES",
                message = "Missing: ${missing.sorted().joinToString()}",
                blocking = true
            )
        }

        if (environment.minSdk != 26) {
            issues += ReleaseIssue(
                code = "MIN_SDK",
                message = "Expected minSdk 26",
                blocking = true
            )
        }

        if (environment.targetSdk != 35 ||
            environment.compileSdk != 35
        ) {
            issues += ReleaseIssue(
                code = "SDK_LEVEL",
                message = "Expected compileSdk/targetSdk 35",
                blocking = true
            )
        }

        if (environment.jdkMajor != 17) {
            issues += ReleaseIssue(
                code = "JDK",
                message = "Expected JDK 17",
                blocking = true
            )
        }

        if (environment.gradleVersion != "8.7") {
            issues += ReleaseIssue(
                code = "GRADLE",
                message = "Expected Gradle 8.7",
                blocking = true
            )
        }

        if (environment.packageName.isBlank()) {
            issues += ReleaseIssue(
                code = "PACKAGE",
                message = "Package name is blank",
                blocking = true
            )
        }

        if (environment.versionName.isBlank()) {
            issues += ReleaseIssue(
                code = "VERSION",
                message = "Version name is blank",
                blocking = true
            )
        }

        return ReleaseReadiness(
            ready = issues.none { it.blocking },
            issues = issues
        )
    }
}
