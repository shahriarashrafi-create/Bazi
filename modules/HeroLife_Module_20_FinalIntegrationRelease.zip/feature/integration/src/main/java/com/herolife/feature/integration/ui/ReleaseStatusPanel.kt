package com.herolife.feature.integration.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.integration.domain.ReleaseReadiness

@Composable
fun ReleaseStatusPanel(
    readiness: ReleaseReadiness,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text(
            if (readiness.ready) "Release Ready" else "Release Blocked",
            style = MaterialTheme.typography.headlineMedium,
            color = if (readiness.ready) HeroLifeColors.Success else HeroLifeColors.Danger
        )

        if (readiness.issues.isEmpty()) {
            Text(
                "تمام بررسی‌های اصلی پاس شده‌اند.",
                color = HeroLifeColors.TextSecondary
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                readiness.issues.forEach {
                    Text(
                        "${it.code}: ${it.message}",
                        color = if (it.blocking) HeroLifeColors.Warning else HeroLifeColors.TextMuted
                    )
                }
            }
        }
    }
}
