package com.herolife.feature.integration.model

data class AppState(
    val route: AppRoute = AppRoute.HOME,
    val previousRoute: AppRoute? = null,
    val gameActive: Boolean = false,
    val gameStartedAtMillis: Long? = null,
    val gameDurationMillis: Long = 30L * 60L * 1000L,
    val lastForegroundAtMillis: Long? = null
) {
    init {
        require(gameDurationMillis > 0L)
        require(gameStartedAtMillis == null || gameStartedAtMillis >= 0L)
        require(lastForegroundAtMillis == null || lastForegroundAtMillis >= 0L)
    }
}

sealed interface AppIntent {
    data class Navigate(val route: AppRoute) : AppIntent
    data class StartGame(val nowMillis: Long) : AppIntent
    data class Foreground(val nowMillis: Long) : AppIntent
    data object ExitGame : AppIntent
    data object Back : AppIntent
}
