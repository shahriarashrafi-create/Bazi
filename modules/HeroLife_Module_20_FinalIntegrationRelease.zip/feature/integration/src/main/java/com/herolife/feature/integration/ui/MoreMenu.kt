package com.herolife.feature.integration.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.integration.model.AppRoute

@Composable
fun MoreMenu(
    onNavigate: (AppRoute) -> Unit,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text(
            "بخش‌های بیشتر",
            style = MaterialTheme.typography.titleLarge,
            color = HeroLifeColors.GoldBright
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MenuButton("چشم‌انداز آینده") { onNavigate(AppRoute.FUTURE_VISION) }
            MenuButton("قهرمان") { onNavigate(AppRoute.HERO) }
            MenuButton("افتخارات") { onNavigate(AppRoute.ACHIEVEMENTS) }
            MenuButton("رویدادها") { onNavigate(AppRoute.EVENTS) }
            MenuButton("اقتصاد و پاداش") { onNavigate(AppRoute.ECONOMY) }
            MenuButton("پروفایل") { onNavigate(AppRoute.PROFILE) }
        }
    }
}

@Composable
private fun MenuButton(
    title: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(title)
    }
}
