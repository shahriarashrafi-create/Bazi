package com.herolife.feature.integration.ui

import androidx.compose.runtime.Composable

data class HeroLifeScreenSlots(
    val home: @Composable () -> Unit,
    val tasks: @Composable () -> Unit,
    val team: @Composable () -> Unit,
    val timeSheet: @Composable () -> Unit,
    val networking: @Composable () -> Unit,
    val futureVision: @Composable () -> Unit,
    val hero: @Composable () -> Unit,
    val achievements: @Composable () -> Unit,
    val events: @Composable () -> Unit,
    val economy: @Composable () -> Unit,
    val profile: @Composable () -> Unit,
    val game: @Composable () -> Unit
)
