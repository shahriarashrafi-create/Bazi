package com.herolife.feature.integration.domain

import com.herolife.feature.integration.model.*

object AppCoordinator {

    fun reduce(
        state: AppState,
        intent: AppIntent
    ): AppState =
        when (intent) {
            is AppIntent.Navigate ->
                state.copy(
                    previousRoute = state.route,
                    route = intent.route
                )

            is AppIntent.StartGame ->
                state.copy(
                    previousRoute = state.route,
                    route = AppRoute.GAME,
                    gameActive = true,
                    gameStartedAtMillis = intent.nowMillis
                )

            is AppIntent.Foreground ->
                state.copy(
                    lastForegroundAtMillis = intent.nowMillis
                )

            AppIntent.ExitGame ->
                state.copy(
                    route = state.previousRoute ?: AppRoute.HOME,
                    gameActive = false,
                    gameStartedAtMillis = null
                )

            AppIntent.Back ->
                state.copy(
                    route = state.previousRoute ?: AppRoute.HOME,
                    previousRoute = null
                )
        }

    fun gameRemainingMillis(
        state: AppState,
        nowMillis: Long
    ): Long {
        val started = state.gameStartedAtMillis ?: return state.gameDurationMillis
        val elapsed = (nowMillis - started).coerceAtLeast(0L)
        return (state.gameDurationMillis - elapsed).coerceAtLeast(0L)
    }

    fun gameExpired(
        state: AppState,
        nowMillis: Long
    ): Boolean =
        state.gameActive &&
            gameRemainingMillis(state, nowMillis) == 0L
}
