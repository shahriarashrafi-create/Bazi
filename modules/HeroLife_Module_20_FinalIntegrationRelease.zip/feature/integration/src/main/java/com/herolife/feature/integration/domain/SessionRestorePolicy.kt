package com.herolife.feature.integration.domain

data class RestoredMatchSession(
    val active: Boolean,
    val remainingMillis: Long,
    val expiredWhileAway: Boolean
)

object SessionRestorePolicy {

    fun restore(
        startedAtMillis: Long?,
        durationMillis: Long,
        nowMillis: Long
    ): RestoredMatchSession {
        require(durationMillis > 0L)

        if (startedAtMillis == null) {
            return RestoredMatchSession(
                active = false,
                remainingMillis = durationMillis,
                expiredWhileAway = false
            )
        }

        val elapsed =
            (nowMillis - startedAtMillis)
                .coerceAtLeast(0L)

        val remaining =
            (durationMillis - elapsed)
                .coerceAtLeast(0L)

        return RestoredMatchSession(
            active = remaining > 0L,
            remainingMillis = remaining,
            expiredWhileAway = remaining == 0L
        )
    }
}
