package com.herolife.feature.integration

import com.herolife.feature.integration.domain.SessionRestorePolicy
import org.junit.Assert.*
import org.junit.Test

class SessionRestorePolicyTest {

    @Test
    fun closingAppDoesNotPauseMatch() {
        val duration = 30L * 60L * 1000L
        val start = 1_000L
        val now = start + 31L * 60L * 1000L

        val restored = SessionRestorePolicy.restore(
            startedAtMillis = start,
            durationMillis = duration,
            nowMillis = now
        )

        assertFalse(restored.active)
        assertTrue(restored.expiredWhileAway)
        assertEquals(0L, restored.remainingMillis)
    }
}
