package com.herolife.feature.integration

import com.herolife.feature.integration.domain.AppCoordinator
import com.herolife.feature.integration.model.*
import org.junit.Assert.*
import org.junit.Test

class AppCoordinatorTest {

    @Test
    fun gameStartsForThirtyMinutes() {
        val start = 1000L
        val state = AppCoordinator.reduce(
            AppState(),
            AppIntent.StartGame(start)
        )

        assertTrue(state.gameActive)
        assertEquals(AppRoute.GAME, state.route)
        assertEquals(30L * 60L * 1000L, state.gameDurationMillis)
    }

    @Test
    fun timerDoesNotPauseWhenAway() {
        val start = 1000L
        val state = AppCoordinator.reduce(
            AppState(),
            AppIntent.StartGame(start)
        )

        val remaining = AppCoordinator.gameRemainingMillis(
            state,
            start + 10L * 60L * 1000L
        )

        assertEquals(20L * 60L * 1000L, remaining)
    }
}
