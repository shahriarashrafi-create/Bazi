package com.herolife.feature.integration

import com.herolife.feature.integration.domain.*
import org.junit.Assert.*
import org.junit.Test

class ReleaseReadinessEngineTest {

    @Test
    fun canonicalEnvironmentIsReady() {
        val result = ReleaseReadinessEngine.evaluate(
            ReleaseEnvironment(
                availableModuleKeys = ModuleRegistry.requiredKeys(),
                minSdk = 26,
                targetSdk = 35,
                compileSdk = 35,
                jdkMajor = 17,
                gradleVersion = "8.7",
                packageName = "com.herolife",
                versionName = "1.0.0"
            )
        )

        assertTrue(result.ready)
        assertTrue(result.issues.isEmpty())
    }

    @Test
    fun missingModuleBlocksRelease() {
        val result = ReleaseReadinessEngine.evaluate(
            ReleaseEnvironment(
                availableModuleKeys = emptySet(),
                minSdk = 26,
                targetSdk = 35,
                compileSdk = 35,
                jdkMajor = 17,
                gradleVersion = "8.7",
                packageName = "com.herolife",
                versionName = "1.0.0"
            )
        )

        assertFalse(result.ready)
    }
}
