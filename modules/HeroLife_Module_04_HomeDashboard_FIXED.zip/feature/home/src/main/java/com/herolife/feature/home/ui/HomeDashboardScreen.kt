package com.herolife.feature.home.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifePrimaryButton
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.feature.home.model.HomeDashboardState
import com.herolife.feature.profile.ui.ProfileCard

@Composable
fun HomeDashboardScreen(
    state: HomeDashboardState,
    onStartGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { HeroLifeBottomBar() }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            Text(
                text = "HeroLife",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black
            )

            Text(
                text = "امروز یک قدم جلوتر برو.",
                style = MaterialTheme.typography.bodyMedium,
                color = HeroLifeColors.TextSecondary
            )

            ProfileCard(profile = state.profile)

            HeroLifePanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Text(
                    text = "قهرمان شما",
                    style = MaterialTheme.typography.titleLarge
                )

                Text(
                    text = "ظاهر و شخصی‌سازی Hero در ماژول 05 فعال می‌شود.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = HeroLifeColors.TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "آماده نبرد ۳۰ دقیقه‌ای",
                    color = HeroLifeColors.Crystal,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HeroLifeStatChip(
                    label = "کارهای فعال",
                    value = state.activeTasks.toString(),
                    accent = HeroLifeColors.Gold,
                    modifier = Modifier.fillMaxWidth()
                )

                HeroLifeStatChip(
                    label = "انجام امروز",
                    value = state.completedToday.toString(),
                    accent = HeroLifeColors.Success,
                    modifier = Modifier.fillMaxWidth()
                )

                HeroLifeStatChip(
                    label = "شبکه‌سازی",
                    value = state.networkingActions.toString(),
                    accent = HeroLifeColors.Crystal,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            HeroLifePanel(
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "رویداد بعدی",
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    text = state.nextEventTitle,
                    style = MaterialTheme.typography.bodyLarge
                )

                Text(
                    text = "${state.nextEventProgress}% پیشرفت",
                    color = HeroLifeColors.Gold
                )
            }

            HeroLifePrimaryButton(
                text = "⚔ شروع بازی ۳۰ دقیقه‌ای",
                onClick = onStartGame,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun HeroLifeBottomBar() {
    val items = listOf(
        "خانه" to "◆",
        "کارها" to "◇",
        "آمار تیم" to "◇",
        "برنامه زمانی" to "◇",
        "شبکه‌سازی" to "◇"
    )

    NavigationBar(
        containerColor = HeroLifeColors.DeepNavy
    ) {
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = index == 0,
                onClick = {},
                icon = { Text(item.second) },
                label = { Text(item.first) }
            )
        }
    }
}
