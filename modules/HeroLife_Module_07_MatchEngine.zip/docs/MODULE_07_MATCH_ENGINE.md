# Module 07/20 — 30-Min Match Engine

Independent module: `:feature:match`

Core rules implemented:
- Exact 30-minute match duration
- No pause state
- Persistent-clock architecture using start/end epoch timestamps
- READY / RUNNING / VICTORY / DEFEAT
- Task -> BattleTask conversion
- Complete / Later / Remove-from-match
- One swap per match
- Minion kill counter
- Tower destruction counter
- XP / Gold / rare Diamond reward accumulation
- Deterministic finish result
- Unit tests for the clock and core match actions

Important:
This module is the state/domain engine, not the visual MOBA renderer.
Manual movement, camera, lanes and minimap arrive in Module 08.
Persistent database/background notification wiring will be integrated in later infrastructure/final integration without changing the match clock contract.
