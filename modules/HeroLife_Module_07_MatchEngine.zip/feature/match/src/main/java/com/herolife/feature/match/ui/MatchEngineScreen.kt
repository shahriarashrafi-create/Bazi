package com.herolife.feature.match.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.match.domain.MatchClock
import com.herolife.feature.match.model.MatchState

@Composable
fun MatchEngineScreen(
    state: MatchState,
    nowEpochMillis: Long,
    modifier: Modifier = Modifier
) {
    val remaining = state.endsAtEpochMillis?.let {
        MatchClock.remainingMillis(it, nowEpochMillis)
    } ?: (30L * 60L * 1000L)

    val totalSeconds = remaining / 1000L
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    val timeText = "%02d:%02d".format(minutes, seconds)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("نبرد", style = MaterialTheme.typography.headlineMedium)
        Text(
            text = timeText,
            style = MaterialTheme.typography.headlineLarge,
            color = HeroLifeColors.Gold
        )

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            Text("وضعیت: ${state.status.name}")
            Text("Minion شکست‌خورده: ${state.minionsDefeated}")
            Text("برج نابودشده: ${state.towersDestroyed}")
            Text("XP: ${state.earnedXp} | 🪙 ${state.earnedGold} | 💎 ${state.earnedDiamonds}")
            Text("تعویض: ${if (state.swapUsed) "0/1" else "1/1"}")
        }

        Text(
            text = "تایمر بر اساس زمان شروع و پایان واقعی محاسبه می‌شود؛ خروج از صفحه آن را متوقف نمی‌کند.",
            color = HeroLifeColors.TextSecondary
        )
    }
}
