package com.herolife.feature.match.domain

import com.herolife.feature.match.model.*
import com.herolife.feature.tasks.model.ManagedTask

class MatchEngine {

    fun create(
        matchId: String,
        tasks: List<ManagedTask>
    ): MatchState = MatchState(
        matchId = matchId,
        startedAtEpochMillis = null,
        endsAtEpochMillis = null,
        status = MatchStatus.READY,
        tasks = tasks.map { BattleTask(it.id, it.title) }
    )

    fun start(state: MatchState, nowEpochMillis: Long): MatchState {
        require(state.status == MatchStatus.READY)
        return state.copy(
            startedAtEpochMillis = nowEpochMillis,
            endsAtEpochMillis = MatchClock.endTime(nowEpochMillis),
            status = MatchStatus.RUNNING
        )
    }

    fun completeTask(
        state: MatchState,
        taskId: String,
        xp: Int,
        gold: Int,
        diamonds: Int = 0
    ): MatchState {
        require(state.status == MatchStatus.RUNNING)
        require(xp >= 0 && gold >= 0 && diamonds >= 0)

        val current = state.tasks.firstOrNull { it.taskId == taskId }
            ?: return state
        if (current.status == BattleTaskStatus.COMPLETED) return state

        return state.copy(
            tasks = state.tasks.map {
                if (it.taskId == taskId) it.copy(status = BattleTaskStatus.COMPLETED) else it
            },
            minionsDefeated = state.minionsDefeated + 1,
            earnedXp = state.earnedXp + xp,
            earnedGold = state.earnedGold + gold,
            earnedDiamonds = state.earnedDiamonds + diamonds
        )
    }

    fun markLater(state: MatchState, taskId: String): MatchState =
        changeTaskStatus(state, taskId, BattleTaskStatus.LATER)

    fun removeFromMatch(state: MatchState, taskId: String): MatchState =
        changeTaskStatus(state, taskId, BattleTaskStatus.REMOVED)

    fun useSwap(state: MatchState): MatchState {
        require(state.status == MatchStatus.RUNNING)
        if (state.swapUsed) return state
        return state.copy(swapUsed = true)
    }

    fun destroyTower(state: MatchState): MatchState {
        require(state.status == MatchStatus.RUNNING)
        return state.copy(towersDestroyed = state.towersDestroyed + 1)
    }

    fun finish(
        state: MatchState,
        victory: Boolean
    ): MatchState {
        require(state.status == MatchStatus.RUNNING)
        return state.copy(
            status = if (victory) MatchStatus.VICTORY else MatchStatus.DEFEAT
        )
    }

    private fun changeTaskStatus(
        state: MatchState,
        taskId: String,
        newStatus: BattleTaskStatus
    ): MatchState {
        require(state.status == MatchStatus.RUNNING)
        return state.copy(
            tasks = state.tasks.map {
                if (it.taskId == taskId) it.copy(status = newStatus) else it
            }
        )
    }
}
