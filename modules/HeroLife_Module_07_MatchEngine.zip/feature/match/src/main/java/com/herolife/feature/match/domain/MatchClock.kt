package com.herolife.feature.match.domain

import com.herolife.feature.match.model.MATCH_DURATION_MILLIS

object MatchClock {
    fun endTime(startedAtEpochMillis: Long): Long =
        startedAtEpochMillis + MATCH_DURATION_MILLIS

    fun remainingMillis(
        endsAtEpochMillis: Long,
        nowEpochMillis: Long
    ): Long = (endsAtEpochMillis - nowEpochMillis).coerceAtLeast(0L)

    fun isExpired(
        endsAtEpochMillis: Long,
        nowEpochMillis: Long
    ): Boolean = nowEpochMillis >= endsAtEpochMillis
}
