package com.herolife.feature.match.model

const val MATCH_DURATION_MILLIS: Long = 30L * 60L * 1000L

enum class MatchStatus {
    READY, RUNNING, VICTORY, DEFEAT
}

enum class BattleTaskStatus {
    ACTIVE, COMPLETED, LATER, REMOVED
}

data class BattleTask(
    val taskId: String,
    val title: String,
    val status: BattleTaskStatus = BattleTaskStatus.ACTIVE
)

data class MatchState(
    val matchId: String,
    val startedAtEpochMillis: Long?,
    val endsAtEpochMillis: Long?,
    val status: MatchStatus,
    val tasks: List<BattleTask>,
    val swapUsed: Boolean = false,
    val minionsDefeated: Int = 0,
    val towersDestroyed: Int = 0,
    val earnedXp: Int = 0,
    val earnedGold: Int = 0,
    val earnedDiamonds: Int = 0
)
