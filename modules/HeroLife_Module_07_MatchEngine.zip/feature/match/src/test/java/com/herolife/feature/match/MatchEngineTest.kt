package com.herolife.feature.match

import com.herolife.feature.match.domain.MatchClock
import com.herolife.feature.match.domain.MatchEngine
import com.herolife.feature.match.model.MatchStatus
import com.herolife.feature.tasks.model.ManagedTask
import org.junit.Assert.*
import org.junit.Test

class MatchEngineTest {

    @Test
    fun matchAlwaysEndsThirtyMinutesAfterStart() {
        val start = 1_000_000L
        assertEquals(start + 1_800_000L, MatchClock.endTime(start))
    }

    @Test
    fun leavingUiCannotPauseClock() {
        val end = 2_800_000L
        assertEquals(600_000L, MatchClock.remainingMillis(end, 2_200_000L))
        assertEquals(0L, MatchClock.remainingMillis(end, 3_000_000L))
    }

    @Test
    fun completingTaskAddsRewardsAndMinionKill() {
        val engine = MatchEngine()
        val task = ManagedTask(id = "t1", title = "دعوت")
        val ready = engine.create("m1", listOf(task))
        val running = engine.start(ready, 1000L)
        val done = engine.completeTask(running, "t1", xp = 10, gold = 5)

        assertEquals(1, done.minionsDefeated)
        assertEquals(10, done.earnedXp)
        assertEquals(5, done.earnedGold)
        assertEquals(MatchStatus.RUNNING, done.status)
    }

    @Test
    fun swapCanOnlyBeConsumedOnce() {
        val engine = MatchEngine()
        val running = engine.start(engine.create("m1", emptyList()), 1000L)
        val first = engine.useSwap(running)
        val second = engine.useSwap(first)

        assertTrue(first.swapUsed)
        assertTrue(second.swapUsed)
    }
}
