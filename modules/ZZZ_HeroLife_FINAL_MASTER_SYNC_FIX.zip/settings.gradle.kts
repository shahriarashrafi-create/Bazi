pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "HeroLife"

include(":app")
include(":core:model")
include(":core:designsystem")

include(":feature:profile")
include(":feature:home")
include(":feature:hero")
include(":feature:tasks")
include(":feature:match")
include(":feature:map")
include(":feature:minions")
include(":feature:objectives")
include(":feature:vfx")
include(":feature:audio")
include(":feature:economy")
include(":feature:achievements")
include(":feature:crm")
include(":feature:team")
include(":feature:events")
include(":feature:timesheet")
include(":feature:vision")
include(":feature:integration")
