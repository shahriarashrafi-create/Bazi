# ZZZ HeroLife Final Master Sync Fix

This ZIP MUST stay named with the `ZZZ_` prefix.

Why:
GitHub Actions extracts every file in `modules/*.zip` in alphabetical order.
Earlier final patches beginning with `HeroLife_FINAL...` were extracted before
`HeroLife_Module_02...`, `HeroLife_Module_03...`, etc. Later module ZIPs could
therefore overwrite root files such as `settings.gradle.kts`,
`app/build.gradle.kts`, and `MainActivity.kt`.

This ZIP is deliberately alphabetically LAST.

It forces the final build to:
- include all 20 Gradle modules explicitly
- make :app depend on all feature modules
- make :app depend on :feature:integration
- replace the old Module 01 MainActivity placeholder
- build the final navigation/app shell

Do NOT rename this file so that it sorts before HeroLife_Module_*.zip.
Do NOT extract it manually.
Upload it directly into `modules/`.
