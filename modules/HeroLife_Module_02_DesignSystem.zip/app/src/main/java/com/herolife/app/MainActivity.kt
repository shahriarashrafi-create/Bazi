package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifePrimaryButton
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.core.designsystem.HeroLifeTheme
import com.herolife.core.designsystem.HeroLifeXpBar
import com.herolife.core.model.GameWallet
import com.herolife.core.model.PlayerProgress

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HeroLifeTheme { HomeScreen() } }
    }
}

@Composable
private fun HomeScreen() {
    val player = PlayerProgress(level = 1, xp = 25, xpToNextLevel = 100)
    val wallet = GameWallet(gold = 120, diamonds = 1)

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text(text = "HeroLife", style = MaterialTheme.typography.displaySmall)
            Text(text = "قهرمان زندگی خودت باش", style = MaterialTheme.typography.bodyLarge, color = HeroLifeColors.TextSecondary)

            HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
                Text(text = "سطح ${player.level}", style = MaterialTheme.typography.titleLarge)
                HeroLifeXpBar(progress = player.xp.toFloat() / player.xpToNextLevel.toFloat())
                Text(text = "${player.xp} / ${player.xpToNextLevel} XP", style = MaterialTheme.typography.bodyMedium, color = HeroLifeColors.TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HeroLifeStatChip(label = "طلا", value = "🪙 ${wallet.gold}", accent = HeroLifeColors.Gold, modifier = Modifier.weight(1f))
                    HeroLifeStatChip(label = "الماس", value = "💎 ${wallet.diamonds}", accent = HeroLifeColors.Crystal, modifier = Modifier.weight(1f))
                }
            }

            HeroLifePanel(modifier = Modifier.fillMaxWidth().height(210.dp)) {
                Text(text = "قهرمان شما", style = MaterialTheme.typography.headlineMedium)
                Text(text = "سیستم انتخاب و شخصی‌سازی Hero در ماژول 05 فعال می‌شود.", style = MaterialTheme.typography.bodyMedium, color = HeroLifeColors.TextSecondary)
                Spacer(modifier = Modifier.weight(1f))
                Text(text = "Design System 02/20 فعال است", color = HeroLifeColors.Crystal, fontWeight = FontWeight.Bold)
            }

            HeroLifePrimaryButton(text = "⚔ شروع بازی", onClick = {}, modifier = Modifier.fillMaxWidth())
        }
    }
}
