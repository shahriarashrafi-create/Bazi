package com.herolife.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val HeroLifeDarkScheme = darkColorScheme(
    primary = HeroLifeColors.Gold,
    onPrimary = HeroLifeColors.Night,
    primaryContainer = HeroLifeColors.SurfaceRaised,
    onPrimaryContainer = HeroLifeColors.GoldSoft,
    secondary = HeroLifeColors.Crystal,
    onSecondary = HeroLifeColors.Night,
    background = HeroLifeColors.Night,
    onBackground = HeroLifeColors.TextPrimary,
    surface = HeroLifeColors.Surface,
    onSurface = HeroLifeColors.TextPrimary,
    surfaceVariant = HeroLifeColors.SurfaceRaised,
    onSurfaceVariant = HeroLifeColors.TextSecondary,
    outline = HeroLifeColors.Divider,
    error = HeroLifeColors.Danger
)

@Composable
fun HeroLifeTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = HeroLifeDarkScheme,
            typography = heroLifeTypography(),
            content = content
        )
    }
}
