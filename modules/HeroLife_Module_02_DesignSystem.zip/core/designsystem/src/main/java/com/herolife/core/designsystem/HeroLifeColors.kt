package com.herolife.core.designsystem

import androidx.compose.ui.graphics.Color

object HeroLifeColors {
    val Night = Color(0xFF07111F)
    val DeepNavy = Color(0xFF0B1728)
    val Surface = Color(0xFF102035)
    val SurfaceRaised = Color(0xFF172A42)
    val Gold = Color(0xFFD8AF56)
    val GoldSoft = Color(0xFFF0CF82)
    val Crystal = Color(0xFF56C7FF)
    val CrystalSoft = Color(0xFFA8E3FF)
    val TextPrimary = Color(0xFFF6F8FB)
    val TextSecondary = Color(0xFF9EB2C8)
    val Divider = Color(0xFF233A55)
    val Success = Color(0xFF61D69C)
    val Warning = Color(0xFFFFC857)
    val Danger = Color(0xFFFF6B6B)
}
