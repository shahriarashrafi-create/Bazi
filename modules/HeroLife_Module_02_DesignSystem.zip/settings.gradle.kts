pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}

rootProject.name = "HeroLife"
include(":app")
include(":core:model")

fun includeMarkedChildren(parent: String) {
    val parentDir = file(parent)
    if (!parentDir.exists()) return
    parentDir.listFiles()
        ?.filter { it.isDirectory && File(it, "herolife-module.marker").exists() }
        ?.sortedBy { it.name }
        ?.forEach { moduleDir ->
            val projectPath = ":" + parent.replace("/", ":") + ":" + moduleDir.name
            include(projectPath)
            project(projectPath).projectDir = moduleDir
            println("HeroLife auto-module: $projectPath")
        }
}

includeMarkedChildren("core")
includeMarkedChildren("feature")
