# Module 02/20 — Design System

این ZIP ماژول مستقل `:core:designsystem` را اضافه می‌کند.

- Dark Navy / Gold / Crystal theme
- RTL-first
- Typography پایه
- Panel, Primary Button, Stat Chip, XP Bar
- Auto-discovery برای ماژول‌های مستقل بعدی

بعد از Upload این ZIP داخل `modules/`، GitHub Actions آن را قبل از Build در ریشه پروژه Extract می‌کند.
