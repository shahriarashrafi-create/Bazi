# HeroLife TRUE DEEP SYNC

This patch is deliberately named `ZZZZ_...` so it extracts after every
previous module and after the earlier `ZZZ_` master sync.

Unlike the earlier app-wiring patch, this MainActivity imports and renders
the real feature-module APIs.

Directly connected:
- Module 03 ProfileCard
- Module 05 HeroSystemScreen
- Module 06 TaskManagerScreen + ManagedTask
- Module 07 MatchEngineScreen + MatchState
- Module 08 MobaMapScreen + MovementEngine + manual joystick
- Module 09 MinionEncounterPanel + MinionTaskBinding
- Module 10 ObjectiveEngine + ObjectivesHud
- Module 11 CombatVfxScene + VfxDirector
- Module 12 AudioSettingsPanel + AnnouncerBanner
- Module 13 EconomyDashboard + EconomyWallet
- Module 14 AchievementTabs + AchievementCard + catalog
- Module 15 CrmDashboard + ProspectCard + NextActionsCard
- Module 16 TeamDashboard + BranchLeaderboard + LeaderAnalyticsCard
- Module 17 EventsOverview + EventCard
- Module 18 TimeUsageDashboard + DayPlanner
- Module 19 VisionDashboard + VisionGoalCard + EmpireDashboard
- Module 20 remains in the app dependency graph

The battle uses actual map movement, actual encounter UI, actual tower/core
objective damage, actual VFX layer, actual announcer banners and the real
30-minute match model.

Upload without extracting and DO NOT rename the `ZZZZ_` prefix.
