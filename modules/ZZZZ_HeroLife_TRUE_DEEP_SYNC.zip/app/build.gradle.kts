plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.herolife.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.herolife.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "1.0.1-deep-sync"
    }

    buildFeatures { compose = true }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":core:model"))
    implementation(project(":core:designsystem"))
    implementation(project(":feature:profile"))
    implementation(project(":feature:home"))
    implementation(project(":feature:hero"))
    implementation(project(":feature:tasks"))
    implementation(project(":feature:match"))
    implementation(project(":feature:map"))
    implementation(project(":feature:minions"))
    implementation(project(":feature:objectives"))
    implementation(project(":feature:vfx"))
    implementation(project(":feature:audio"))
    implementation(project(":feature:economy"))
    implementation(project(":feature:achievements"))
    implementation(project(":feature:crm"))
    implementation(project(":feature:team"))
    implementation(project(":feature:events"))
    implementation(project(":feature:timesheet"))
    implementation(project(":feature:vision"))
    implementation(project(":feature:integration"))

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
