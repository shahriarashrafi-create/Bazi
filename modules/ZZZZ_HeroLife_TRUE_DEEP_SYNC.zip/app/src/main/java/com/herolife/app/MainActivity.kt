package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herolife.core.designsystem.*
import com.herolife.core.model.GameLane
import com.herolife.core.model.TaskPriority
import com.herolife.feature.achievements.domain.AchievementCatalog
import com.herolife.feature.achievements.model.*
import com.herolife.feature.achievements.ui.AchievementCard
import com.herolife.feature.achievements.ui.AchievementTabs
import com.herolife.feature.audio.domain.AnnouncerDirector
import com.herolife.feature.audio.model.AudioSettings
import com.herolife.feature.audio.ui.AnnouncerBanner
import com.herolife.feature.audio.ui.AudioSettingsPanel
import com.herolife.feature.crm.domain.CrmAnalytics
import com.herolife.feature.crm.model.*
import com.herolife.feature.crm.ui.CrmDashboard
import com.herolife.feature.crm.ui.NextActionsCard
import com.herolife.feature.crm.ui.ProspectCard
import com.herolife.feature.economy.model.EconomyWallet
import com.herolife.feature.economy.ui.EconomyDashboard
import com.herolife.feature.events.domain.EventAnalytics
import com.herolife.feature.events.model.*
import com.herolife.feature.events.ui.EventCard
import com.herolife.feature.events.ui.EventsOverview
import com.herolife.feature.hero.ui.HeroSystemScreen
import com.herolife.feature.map.domain.MovementEngine
import com.herolife.feature.map.model.*
import com.herolife.feature.map.ui.MobaMapScreen
import com.herolife.feature.match.model.*
import com.herolife.feature.match.ui.MatchEngineScreen
import com.herolife.feature.minions.model.MinionTaskBinding
import com.herolife.feature.minions.ui.MinionEncounterPanel
import com.herolife.feature.objectives.domain.ObjectiveEngine
import com.herolife.feature.objectives.domain.ObjectiveFactory
import com.herolife.feature.objectives.model.MatchOutcome
import com.herolife.feature.objectives.ui.ObjectivesHud
import com.herolife.feature.profile.model.PlayerProfile
import com.herolife.feature.profile.ui.ProfileCard
import com.herolife.feature.tasks.model.*
import com.herolife.feature.tasks.ui.TaskManagerScreen
import com.herolife.feature.team.domain.BranchAnalyticsEngine
import com.herolife.feature.team.domain.LeaderAnalyticsEngine
import com.herolife.feature.team.domain.TeamMomentumEngine
import com.herolife.feature.team.model.*
import com.herolife.feature.team.ui.BranchLeaderboard
import com.herolife.feature.team.ui.LeaderAnalyticsCard
import com.herolife.feature.team.ui.TeamDashboard
import com.herolife.feature.timesheet.domain.PlanBuilder
import com.herolife.feature.timesheet.domain.TimeUsageEngine
import com.herolife.feature.timesheet.model.*
import com.herolife.feature.timesheet.ui.DayPlanner
import com.herolife.feature.timesheet.ui.TimeUsageDashboard
import com.herolife.feature.vfx.domain.VfxDirector
import com.herolife.feature.vfx.model.CameraShakeState
import com.herolife.feature.vfx.model.VfxEvent
import com.herolife.feature.vfx.ui.CombatVfxScene
import com.herolife.feature.vision.domain.EmpireGrowthEngine
import com.herolife.feature.vision.domain.VisionAnalytics
import com.herolife.feature.vision.model.*
import com.herolife.feature.vision.ui.EmpireDashboard
import com.herolife.feature.vision.ui.FutureVisionCard
import com.herolife.feature.vision.ui.VisionDashboard
import com.herolife.feature.vision.ui.VisionGoalCard
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl
            ) {
                HeroLifeTheme {
                    DeepSyncedHeroLife()
                }
            }
        }
    }
}

private enum class RootScreen {
    HOME, TASKS, TEAM, TIME, CRM, HERO, ACHIEVEMENTS, EVENTS, ECONOMY, VISION, AUDIO, GAME
}

@Composable
private fun DeepSyncedHeroLife() {
    var screen by remember { mutableStateOf(RootScreen.HOME) }
    var wallet by remember { mutableStateOf(EconomyWallet(xp = 25, gold = 120, diamonds = 1)) }

    val tasks = remember {
        mutableStateListOf(
            ManagedTask(
                id = "task_1",
                title = "ارتباط‌سازی با ۳ نفر",
                description = "سه ارتباط باکیفیت برای توسعه شبکه",
                priority = TaskPriority.CRITICAL,
                lane = GameLane.NETWORKING,
                estimatedMinutes = 12,
                xpReward = 15,
                goldReward = 8,
                sortOrder = 1
            ),
            ManagedTask(
                id = "task_2",
                title = "فالوآپ مخاطب گرم",
                priority = TaskPriority.HIGH,
                lane = GameLane.NETWORKING,
                estimatedMinutes = 8,
                xpReward = 12,
                goldReward = 7,
                sortOrder = 2
            ),
            ManagedTask(
                id = "task_3",
                title = "۲۰ دقیقه مطالعه",
                priority = TaskPriority.MEDIUM,
                lane = GameLane.PERSONAL_GROWTH,
                estimatedMinutes = 20,
                xpReward = 18,
                goldReward = 8,
                sortOrder = 3
            ),
            ManagedTask(
                id = "task_4",
                title = "کار شخصی مهم",
                priority = TaskPriority.HIGH,
                lane = GameLane.PERSONAL,
                estimatedMinutes = 15,
                xpReward = 15,
                goldReward = 7,
                sortOrder = 4
            )
        )
    }

    Scaffold(
        containerColor = HeroLifeColors.Void,
        bottomBar = {
            if (screen != RootScreen.GAME) {
                DeepBottomBar(screen) { screen = it }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (screen) {
                RootScreen.HOME -> DeepHome(
                    wallet = wallet,
                    activeTasks = tasks.count { it.isActive },
                    onStartGame = { screen = RootScreen.GAME },
                    onHero = { screen = RootScreen.HERO },
                    onAchievements = { screen = RootScreen.ACHIEVEMENTS },
                    onEvents = { screen = RootScreen.EVENTS },
                    onEconomy = { screen = RootScreen.ECONOMY },
                    onVision = { screen = RootScreen.VISION },
                    onAudio = { screen = RootScreen.AUDIO }
                )

                RootScreen.TASKS -> {
                    TaskManagerScreen(
                        tasks = tasks,
                        onAddTask = {
                            val n = tasks.size + 1
                            tasks += ManagedTask(
                                id = "task_$n",
                                title = "کار جدید $n",
                                priority = TaskPriority.MEDIUM,
                                lane = GameLane.PERSONAL,
                                estimatedMinutes = 10,
                                sortOrder = n
                            )
                        }
                    )
                }

                RootScreen.TEAM -> DeepTeam()
                RootScreen.TIME -> DeepTimeSheet()
                RootScreen.CRM -> DeepCrm()
                RootScreen.HERO -> ScrollPage { HeroSystemScreen(gold = wallet.gold) }
                RootScreen.ACHIEVEMENTS -> DeepAchievements()
                RootScreen.EVENTS -> DeepEvents()
                RootScreen.ECONOMY -> ScrollPage { EconomyDashboard(wallet = wallet) }
                RootScreen.VISION -> DeepVision(wallet.xp)
                RootScreen.AUDIO -> DeepAudio()
                RootScreen.GAME -> DeepBattle(
                    tasks = tasks,
                    wallet = wallet,
                    onWalletChanged = { wallet = it },
                    onExit = { screen = RootScreen.HOME }
                )
            }
        }
    }
}

@Composable
private fun DeepBottomBar(
    selected: RootScreen,
    onSelect: (RootScreen) -> Unit
) {
    NavigationBar(containerColor = HeroLifeColors.DeepNavy) {
        val items = listOf(
            RootScreen.HOME to ("◆" to "خانه"),
            RootScreen.TASKS to ("✓" to "کارها"),
            RootScreen.TEAM to ("♜" to "آمار تیم"),
            RootScreen.TIME to ("◷" to "برنامه زمانی"),
            RootScreen.CRM to ("◎" to "شبکه‌سازی")
        )

        items.forEach { item ->
            val route = item.first
            NavigationBarItem(
                selected = selected == route,
                onClick = { onSelect(route) },
                icon = { Text(item.second.first) },
                label = { Text(item.second.second, fontSize = 10.sp) }
            )
        }
    }
}

@Composable
private fun ScrollPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
private fun DeepHome(
    wallet: EconomyWallet,
    activeTasks: Int,
    onStartGame: () -> Unit,
    onHero: () -> Unit,
    onAchievements: () -> Unit,
    onEvents: () -> Unit,
    onEconomy: () -> Unit,
    onVision: () -> Unit,
    onAudio: () -> Unit
) {
    ScrollPage {
        Text(
            "HeroLife",
            style = MaterialTheme.typography.headlineLarge,
            color = HeroLifeColors.TextPrimary
        )
        Text(
            "امروز یک قدم جلوتر برو.",
            color = HeroLifeColors.TextSecondary
        )

        ProfileCard(
            profile = PlayerProfile(
                id = "player",
                displayName = "بازیکن",
                heroTitle = "جنگنده",
                level = 1,
                xp = wallet.xp.toInt().coerceAtMost(99),
                xpToNextLevel = 100,
                gold = wallet.gold,
                diamonds = wallet.diamonds
            )
        )

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            HeroLifeSectionHeader(
                title = "قهرمان شما",
                subtitle = "سیستم واقعی Hero و فروشگاه ظاهر"
            )
            Text(
                "کارهای فعال: $activeTasks",
                color = HeroLifeColors.Crystal
            )
            HeroLifePrimaryButton(
                text = "شخصی‌سازی قهرمان",
                onClick = onHero,
                modifier = Modifier.fillMaxWidth()
            )
        }

        HeroLifePrimaryButton(
            text = "⚔ شروع بازی ۳۰ دقیقه‌ای",
            onClick = onStartGame,
            modifier = Modifier.fillMaxWidth()
        )

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            HeroLifeSectionHeader(
                title = "مرکز فرمان",
                subtitle = "ماژول‌های واقعی ۱۳ تا ۱۹"
            )
            HomeLink("🏆 افتخارات و رکوردها", onAchievements)
            HomeLink("📅 رویدادها و Event Director", onEvents)
            HomeLink("💰 اقتصاد و پاداش", onEconomy)
            HomeLink("🏰 Future Vision و Empire", onVision)
            HomeLink("🔊 تنظیمات صدا و Announcer", onAudio)
        }

        Text(
            "TRUE DEEP SYNC • feature modules connected directly",
            color = HeroLifeColors.Success,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun HomeLink(
    label: String,
    action: () -> Unit
) {
    OutlinedButton(
        onClick = action,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(label)
    }
}

@Composable
private fun DeepTeam() {
    val members = remember {
        listOf(
            TeamMember(
                id = "l1",
                fullName = "لیدر آلفا",
                parentId = null,
                branchId = "a",
                role = MemberRole.LEADER,
                personalSales = 120_000,
                teamSales = 520_000,
                activityScore = 88,
                newContacts = 24,
                invitations = 13,
                presentations = 8,
                followUps = 21,
                newMembers = 3
            ),
            TeamMember(
                id = "a2",
                fullName = "عضو آلفا",
                parentId = "l1",
                branchId = "a",
                role = MemberRole.ACTIVE_MEMBER,
                personalSales = 60_000,
                teamSales = 160_000,
                activityScore = 70,
                newMembers = 1
            ),
            TeamMember(
                id = "l2",
                fullName = "لیدر بتا",
                parentId = null,
                branchId = "b",
                role = MemberRole.LEADER,
                personalSales = 90_000,
                teamSales = 390_000,
                activityScore = 74,
                newMembers = 2
            )
        )
    }

    val branches = remember {
        listOf(
            TeamBranch("a", "شاخه آلفا", "l1", targetSales = 700_000),
            TeamBranch("b", "شاخه بتا", "l2", targetSales = 600_000)
        )
    }

    ScrollPage {
        TeamDashboard(
            snapshot = TeamMomentumEngine.snapshot(members)
        )

        BranchLeaderboard(
            branches = BranchAnalyticsEngine.rank(
                branches = branches,
                members = members
            )
        )

        LeaderAnalyticsEngine.rankLeaders(members).forEach {
            LeaderAnalyticsCard(metrics = it)
        }
    }
}

@Composable
private fun DeepCrm() {
    val now = remember { System.currentTimeMillis() }

    val prospects = remember {
        listOf(
            Prospect(
                id = "p1",
                fullName = "مخاطب گرم",
                stage = ProspectStage.FOLLOW_UP,
                temperature = ProspectTemperature.HOT,
                referrerName = "معرف نمونه",
                advisorName = "مشاور",
                notes = "فالوآپ امروز",
                createdAtMillis = now,
                updatedAtMillis = now
            ),
            Prospect(
                id = "p2",
                fullName = "مخاطب دعوت‌شده",
                stage = ProspectStage.INVITED,
                temperature = ProspectTemperature.WARM,
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )
    }

    val interactions = remember {
        listOf(
            NetworkingInteraction(
                id = "i1",
                prospectId = "p1",
                type = NetworkingActionType.BUSINESS_PRESENTATION,
                result = InteractionResult.POSITIVE,
                occurredAtMillis = now
            )
        )
    }

    val actions = remember {
        listOf(
            NextAction(
                id = "n1",
                prospectId = "p1",
                title = "فالوآپ نتیجه معرفی",
                type = NetworkingActionType.FOLLOW_UP,
                dueAtMillis = now + 86_400_000L,
                priority = FollowUpPriority.HIGH
            ),
            NextAction(
                id = "n2",
                prospectId = "p1",
                title = "دعوت به جلسه بعدی",
                type = NetworkingActionType.INVITATION,
                dueAtMillis = now + 172_800_000L
            )
        )
    }

    ScrollPage {
        CrmDashboard(
            snapshot = CrmAnalytics.snapshot(
                prospects = prospects,
                interactions = interactions,
                pendingFollowUps = actions.count { !it.done }
            )
        )
        prospects.forEach { ProspectCard(prospect = it) }
        NextActionsCard(actions = actions)
    }
}

@Composable
private fun DeepTimeSheet() {
    val now = remember { System.currentTimeMillis() }
    val dayStart = remember { now - (now % 86_400_000L) }

    val blocks = remember {
        listOf(
            TimeBlock(
                id = "t1",
                title = "شبکه‌سازی",
                startAtMillis = dayStart + 9 * 3_600_000L,
                endAtMillis = dayStart + 10 * 3_600_000L,
                category = TimeBlockCategory.NETWORKING,
                priority = TimeBlockPriority.HIGH,
                completed = true
            ),
            TimeBlock(
                id = "t2",
                title = "رشد فردی",
                startAtMillis = dayStart + 11 * 3_600_000L,
                endAtMillis = dayStart + 11 * 3_600_000L + 30 * 60_000L,
                category = TimeBlockCategory.PERSONAL_GROWTH
            ),
            TimeBlock(
                id = "t3",
                title = "فالوآپ",
                startAtMillis = dayStart + 16 * 3_600_000L,
                endAtMillis = dayStart + 16 * 3_600_000L + 45 * 60_000L,
                category = TimeBlockCategory.NETWORKING
            )
        )
    }

    ScrollPage {
        TimeUsageDashboard(
            snapshot = TimeUsageEngine.daySnapshot(blocks)
        )
        DayPlanner(
            plan = PlanBuilder.day(
                dayStartMillis = dayStart,
                blocks = blocks
            )
        )
    }
}

@Composable
private fun DeepEvents() {
    val now = remember { System.currentTimeMillis() }

    val events = remember {
        listOf(
            TeamEvent(
                id = "e1",
                title = "ایونت ماه جاری",
                description = "هدف تیم برای رویداد اصلی",
                location = "تهران",
                startAtMillis = now - 5 * 86_400_000L,
                endAtMillis = now + 10 * 86_400_000L,
                leaderName = "لیدر اصلی",
                directorName = "Event Director",
                goalValue = 100,
                currentValue = 62,
                priority = EventPriority.HIGH,
                status = EventStatus.ACTIVE,
                createdAtMillis = now - 10 * 86_400_000L,
                updatedAtMillis = now
            ),
            TeamEvent(
                id = "e2",
                title = "جلسه لیدرها",
                location = "آنلاین",
                startAtMillis = now - 2 * 86_400_000L,
                endAtMillis = now + 4 * 86_400_000L,
                goalValue = 40,
                currentValue = 31,
                status = EventStatus.ACTIVE,
                createdAtMillis = now - 3 * 86_400_000L,
                updatedAtMillis = now
            )
        )
    }

    ScrollPage {
        EventsOverview(
            snapshot = EventAnalytics.snapshot(events, now)
        )
        events.forEach {
            EventCard(
                event = it,
                nowMillis = now
            )
        }
    }
}

@Composable
private fun DeepVision(lifetimeXp: Long) {
    val now = remember { System.currentTimeMillis() }

    val visions = remember {
        listOf(
            FutureVision(
                id = "v1",
                title = "درآمد هدف",
                description = "ساخت یک درآمد پایدار و قابل توسعه",
                category = VisionCategory.FINANCIAL,
                targetYear = 2027,
                createdAtMillis = now,
                updatedAtMillis = now
            ),
            FutureVision(
                id = "v2",
                title = "سبک زندگی",
                description = "زمان آزاد و آزادی مکانی بیشتر",
                category = VisionCategory.LIFESTYLE,
                targetYear = 2028,
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )
    }

    val goals = remember {
        listOf(
            VisionGoal("g1", "v1", "هدف مالی مرحله اول", 100, 42),
            VisionGoal("g2", "v2", "هدف سبک زندگی", 100, 25)
        )
    }

    ScrollPage {
        VisionDashboard(
            snapshot = VisionAnalytics.snapshot(
                visions = visions,
                goals = goals
            )
        )

        visions.forEach {
            FutureVisionCard(vision = it)
        }

        goals.forEach {
            VisionGoalCard(goal = it)
        }

        EmpireDashboard(
            progress = EmpireGrowthEngine.progress(
                EmpireState(
                    lifetimeXp = lifetimeXp,
                    completedGoals = 2,
                    completedMissions = 8,
                    consistencyDays = 35
                )
            )
        )
    }
}

@Composable
private fun DeepAchievements() {
    var period by remember { mutableStateOf(AchievementPeriod.ALL) }
    val definitions = remember { AchievementCatalog.defaults() }

    ScrollPage {
        Text(
            "افتخارات و رکوردها",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        AchievementTabs(
            selected = period,
            onSelected = { period = it }
        )

        definitions
            .filter { period == AchievementPeriod.ALL || it.period == period }
            .forEachIndexed { index, definition ->
                val current = when (definition.type) {
                    AchievementType.TASKS_COMPLETED -> if (index == 0) 2L else 12L
                    AchievementType.MATCHES_WON -> 3L
                    AchievementType.STREAK -> 4L
                    else -> 1L
                }.coerceAtMost(definition.target)

                AchievementCard(
                    state = AchievementCardState(
                        definition = definition,
                        progress = AchievementProgress(
                            achievementId = definition.id,
                            current = current,
                            unlocked = current >= definition.target
                        )
                    ),
                    onClaim = {}
                )
            }
    }
}

@Composable
private fun DeepAudio() {
    var settings by remember { mutableStateOf(AudioSettings()) }

    ScrollPage {
        AudioSettingsPanel(
            settings = settings,
            onSettingsChanged = { settings = it }
        )

        AnnouncerBanner(
            visible = true,
            line = AnnouncerDirector.fromKillCount(3)
        )
    }
}

@Composable
private fun DeepBattle(
    tasks: List<ManagedTask>,
    wallet: EconomyWallet,
    onWalletChanged: (EconomyWallet) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences(
            "herolife_match",
            android.content.Context.MODE_PRIVATE
        )
    }

    val duration = MATCH_DURATION_MILLIS
    var startedAt by remember {
        mutableLongStateOf(
            prefs.getLong("started_at", 0L).takeIf { it > 0L }
                ?: System.currentTimeMillis().also {
                    prefs.edit().putLong("started_at", it).apply()
                }
        )
    }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var mapState by remember {
        mutableStateOf(
            com.herolife.feature.map.controller.MapController.defaultInitialState()
        )
    }

    val bindings = remember(tasks) {
        tasks.take(4).mapIndexed { index, task ->
            val pos = listOf(
                WorldPoint(900f, 980f),
                WorldPoint(1050f, 800f),
                WorldPoint(1050f, 620f),
                WorldPoint(1300f, 800f)
            )[index]
            MinionTaskBinding.fromTask(
                minionId = "battle_minion_$index",
                task = task,
                worldPosition = pos
            )
        }.toMutableStateList()
    }

    var selectedIndex by remember { mutableIntStateOf(0) }
    var swapRemaining by remember { mutableIntStateOf(1) }
    var objectiveState by remember { mutableStateOf(ObjectiveFactory.create()) }
    val objectiveEngine = remember { ObjectiveEngine() }
    val vfxDirector = remember { VfxDirector() }
    val vfxEvents = remember { mutableStateListOf<VfxEvent>() }
    var shake by remember { mutableStateOf(CameraShakeState()) }
    var killStreak by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        var last = System.currentTimeMillis()
        while (true) {
            delay(16L)
            val current = System.currentTimeMillis()
            val dt = ((current - last).coerceAtMost(50L)).toFloat() / 1000f
            last = current
            now = current
            mapState = MovementEngine.tick(mapState, dt)
            vfxEvents.removeAll { it.isExpired(current) }
        }
    }

    val remaining = (duration - (now - startedAt)).coerceAtLeast(0L)
    val minutes = remaining / 60_000L
    val seconds = (remaining / 1000L) % 60L
    val timerText = "%02d:%02d".format(minutes, seconds)

    LaunchedEffect(remaining) {
        if (remaining == 0L && objectiveState.outcome == MatchOutcome.IN_PROGRESS) {
            objectiveState = objectiveEngine.evaluateTimeout(objectiveState)
            prefs.edit().remove("started_at").apply()
        }
    }

    val currentBinding = bindings.getOrNull(
        selectedIndex.coerceIn(0, (bindings.size - 1).coerceAtLeast(0))
    )

    val matchState = MatchState(
        matchId = "live",
        startedAtEpochMillis = startedAt,
        endsAtEpochMillis = startedAt + duration,
        status = when (objectiveState.outcome) {
            MatchOutcome.VICTORY -> MatchStatus.VICTORY
            MatchOutcome.DEFEAT -> MatchStatus.DEFEAT
            MatchOutcome.IN_PROGRESS -> MatchStatus.RUNNING
        },
        tasks = bindings.map {
            BattleTask(
                taskId = it.taskId,
                title = it.title,
                status = BattleTaskStatus.ACTIVE
            )
        },
        swapUsed = swapRemaining == 0,
        minionsDefeated = killStreak,
        towersDestroyed = if (objectiveState.enemyTower.destroyed) 1 else 0,
        earnedXp = (wallet.xp - 25L).coerceAtLeast(0L).toInt(),
        earnedGold = (wallet.gold - 120L).coerceAtLeast(0L).toInt(),
        earnedDiamonds = (wallet.diamonds - 1L).coerceAtLeast(0L).toInt()
    )

    Box(Modifier.fillMaxSize()) {
        CombatVfxScene(
            events = vfxEvents,
            camera = mapState.camera,
            shake = shake,
            nowMillis = now,
            battlefield = {
                MobaMapScreen(
                    state = mapState,
                    timerText = timerText,
                    levelText = "LV 1",
                    gold = wallet.gold,
                    diamonds = wallet.diamonds,
                    onJoystickChanged = { x, y, strength ->
                        mapState = MovementEngine.updateJoystick(
                            state = mapState,
                            direction = WorldPoint(x, y),
                            strength = strength
                        )
                    },
                    onJoystickReleased = {
                        mapState = MovementEngine.releaseJoystick(mapState)
                    }
                )
            }
        )

        ObjectivesHud(
            state = objectiveState,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 76.dp, end = 10.dp)
                .width(190.dp)
        )

        AnnouncerBanner(
            visible = killStreak >= 2,
            line = AnnouncerDirector.fromKillCount(killStreak),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 165.dp, start = 40.dp, end = 40.dp)
        )

        MinionEncounterPanel(
            visible = currentBinding != null &&
                objectiveState.outcome == MatchOutcome.IN_PROGRESS &&
                remaining > 0L,
            binding = currentBinding,
            swapRemaining = swapRemaining,
            onComplete = {
                val binding = currentBinding ?: return@MinionEncounterPanel
                val eventTime = System.currentTimeMillis()
                val result = objectiveEngine.onTaskCompleted(objectiveState)
                objectiveState = result.first

                val attack = vfxDirector.heroAttack(
                    position = mapState.hero.position,
                    nowMillis = eventTime
                )
                val defeated = vfxDirector.minionDefeated(
                    position = binding.worldPosition,
                    nowMillis = eventTime + 1L
                )
                vfxEvents += attack
                vfxEvents += defeated
                vfxEvents += vfxDirector.reward(
                    position = binding.worldPosition,
                    nowMillis = eventTime + 2L,
                    xp = binding.xpReward,
                    gold = binding.goldReward,
                    diamonds = binding.diamondReward
                )
                shake = vfxDirector.cameraShakeFor(defeated)

                onWalletChanged(
                    wallet.copy(
                        xp = wallet.xp + binding.xpReward,
                        gold = wallet.gold + binding.goldReward,
                        diamonds = wallet.diamonds + binding.diamondReward
                    )
                )
                killStreak += 1
                bindings.remove(binding)
                selectedIndex = 0
            },
            onLater = {
                objectiveState = objectiveEngine.onTaskLater(objectiveState).first
                if (bindings.isNotEmpty()) {
                    selectedIndex = (selectedIndex + 1) % bindings.size
                }
            },
            onSwap = {
                if (swapRemaining > 0 && bindings.size > 1) {
                    swapRemaining = 0
                    selectedIndex = (selectedIndex + 1) % bindings.size
                }
            },
            onRemoveFromMatch = {
                val binding = currentBinding ?: return@MinionEncounterPanel
                objectiveState = objectiveEngine.onTaskRemoved(objectiveState).first
                bindings.remove(binding)
                selectedIndex = 0
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
        )

        if (objectiveState.outcome != MatchOutcome.IN_PROGRESS || remaining == 0L) {
            HeroLifePanel(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(28.dp)
            ) {
                Text(
                    if (objectiveState.outcome == MatchOutcome.VICTORY) "VICTORY" else "DEFEAT",
                    style = MaterialTheme.typography.headlineLarge,
                    color = if (objectiveState.outcome == MatchOutcome.VICTORY) {
                        HeroLifeColors.GoldBright
                    } else {
                        HeroLifeColors.Danger
                    }
                )
                MatchEngineScreen(
                    state = matchState,
                    nowEpochMillis = now,
                    modifier = Modifier.height(220.dp)
                )
                HeroLifePrimaryButton(
                    text = "بازگشت به خانه",
                    onClick = {
                        prefs.edit().remove("started_at").apply()
                        startedAt = 0L
                        onExit()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            TextButton(
                onClick = onExit,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 58.dp, start = 8.dp)
            ) {
                Text("خروج", color = HeroLifeColors.TextPrimary)
            }
        }
    }
}
