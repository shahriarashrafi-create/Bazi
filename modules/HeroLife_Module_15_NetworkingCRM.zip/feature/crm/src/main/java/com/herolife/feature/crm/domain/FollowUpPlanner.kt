package com.herolife.feature.crm.domain

import com.herolife.feature.crm.model.FollowUpPriority
import com.herolife.feature.crm.model.NetworkingActionType
import com.herolife.feature.crm.model.NextAction
import com.herolife.feature.crm.model.ProspectStage

object FollowUpPlanner {

    fun suggestedActions(
        prospectId: String,
        stage: ProspectStage,
        nowMillis: Long
    ): List<NextAction> {
        val day = 24L * 60L * 60L * 1000L

        return when (stage) {
            ProspectStage.NEW -> listOf(
                action(
                    id = "${prospectId}_connect",
                    prospectId = prospectId,
                    title = "شروع ارتباط‌سازی",
                    type = NetworkingActionType.CONNECTION,
                    due = nowMillis,
                    priority = FollowUpPriority.HIGH
                ),
                action(
                    id = "${prospectId}_pre",
                    prospectId = prospectId,
                    title = "بررسی زمان مناسب پیش‌مشاوره",
                    type = NetworkingActionType.PRE_CONSULTATION,
                    due = nowMillis + day,
                    priority = FollowUpPriority.MEDIUM
                )
            )

            ProspectStage.CONNECTED,
            ProspectStage.PRE_CONSULTED -> listOf(
                action(
                    id = "${prospectId}_invite",
                    prospectId = prospectId,
                    title = "دعوت برای قدم بعدی",
                    type = NetworkingActionType.INVITATION,
                    due = nowMillis + day,
                    priority = FollowUpPriority.HIGH
                ),
                action(
                    id = "${prospectId}_follow_1",
                    prospectId = prospectId,
                    title = "فالوآپ بعد از دعوت",
                    type = NetworkingActionType.FOLLOW_UP,
                    due = nowMillis + day * 2,
                    priority = FollowUpPriority.MEDIUM
                )
            )

            ProspectStage.INVITED,
            ProspectStage.PRESENTED,
            ProspectStage.FOLLOW_UP,
            ProspectStage.DECISION -> listOf(
                action(
                    id = "${prospectId}_follow_main",
                    prospectId = prospectId,
                    title = "فالوآپ اصلی",
                    type = NetworkingActionType.FOLLOW_UP,
                    due = nowMillis + day,
                    priority = FollowUpPriority.HIGH
                ),
                action(
                    id = "${prospectId}_follow_second",
                    prospectId = prospectId,
                    title = "فالوآپ دوم",
                    type = NetworkingActionType.FOLLOW_UP,
                    due = nowMillis + day * 3,
                    priority = FollowUpPriority.MEDIUM
                )
            )

            ProspectStage.CUSTOMER,
            ProspectStage.TEAM_MEMBER,
            ProspectStage.NOT_NOW,
            ProspectStage.CLOSED -> emptyList()
        }
    }

    private fun action(
        id: String,
        prospectId: String,
        title: String,
        type: NetworkingActionType,
        due: Long,
        priority: FollowUpPriority
    ): NextAction =
        NextAction(
            id = id,
            prospectId = prospectId,
            title = title,
            type = type,
            dueAtMillis = due,
            priority = priority
        )
}
