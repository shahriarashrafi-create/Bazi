package com.herolife.feature.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.crm.model.NetworkingInteraction

@Composable
fun InteractionTimeline(
    interactions: List<NetworkingInteraction>,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "تاریخچه ارتباط",
            style = MaterialTheme.typography.titleLarge,
            color = HeroLifeColors.TextPrimary
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            interactions.forEach { item ->
                Text(
                    text = "${typeLabel(item.type.name)} • ${resultLabel(item.result.name)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = HeroLifeColors.Crystal
                )

                if (item.summary.isNotBlank()) {
                    Text(
                        text = item.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = HeroLifeColors.TextSecondary
                    )
                }
            }
        }
    }
}

private fun typeLabel(value: String): String =
    when (value) {
        "CONNECTION" -> "ارتباط‌سازی"
        "PRE_CONSULTATION" -> "پیش‌مشاوره"
        "INVITATION" -> "دعوت"
        "BUSINESS_PRESENTATION" -> "معرفی کار"
        else -> "فالوآپ"
    }

private fun resultLabel(value: String): String =
    when (value) {
        "POSITIVE" -> "مثبت"
        "NEGATIVE" -> "منفی"
        "NO_RESPONSE" -> "بدون پاسخ"
        "RESCHEDULED" -> "زمان جدید"
        "COMPLETED" -> "تکمیل"
        else -> "خنثی"
    }
