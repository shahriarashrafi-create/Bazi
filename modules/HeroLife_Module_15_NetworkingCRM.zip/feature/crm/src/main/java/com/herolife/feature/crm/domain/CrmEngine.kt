package com.herolife.feature.crm.domain

import com.herolife.feature.crm.model.InteractionResult
import com.herolife.feature.crm.model.NetworkingActionType
import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.NextAction
import com.herolife.feature.crm.model.Prospect
import com.herolife.feature.crm.model.ProspectStage
import com.herolife.feature.crm.model.ProspectTimeline

class CrmEngine(
    private val repository: ProspectRepository
) {

    fun upsertProspect(prospect: Prospect) {
        repository.saveProspect(prospect)
    }

    fun archiveProspect(id: String) {
        repository.archiveProspect(id)
    }

    fun deleteProspect(id: String) {
        repository.deleteProspect(id)
    }

    fun timeline(prospectId: String): ProspectTimeline? {
        val prospect =
            repository.prospectById(prospectId)
                ?: return null

        return ProspectTimeline(
            prospect = prospect,
            interactions = repository.interactionsFor(prospectId),
            nextActions = repository.nextActionsFor(prospectId)
        )
    }

    fun recordInteraction(
        interaction: NetworkingInteraction,
        nowMillis: Long
    ) {
        repository.addInteraction(interaction)

        val prospect =
            repository.prospectById(interaction.prospectId)
                ?: return

        val progressed =
            prospect.copy(
                stage = nextStage(
                    current = prospect.stage,
                    type = interaction.type,
                    result = interaction.result
                ),
                referrerName = interaction.referrerName.ifBlank {
                    prospect.referrerName
                },
                advisorName = interaction.advisorName.ifBlank {
                    prospect.advisorName
                },
                updatedAtMillis = nowMillis
            )

        repository.saveProspect(progressed)
    }

    fun saveNextAction(action: NextAction) {
        repository.saveNextAction(action)
    }

    fun completeNextAction(id: String, prospectId: String) {
        val action =
            repository.nextActionsFor(prospectId)
                .firstOrNull { it.id == id }
                ?: return

        repository.saveNextAction(
            action.copy(done = true)
        )
    }

    fun nextTwoActions(prospectId: String): List<NextAction> =
        repository.nextActionsFor(prospectId)
            .filterNot { it.done }
            .sortedWith(
                compareBy<NextAction> {
                    it.dueAtMillis ?: Long.MAX_VALUE
                }.thenByDescending {
                    it.priority.ordinal
                }
            )
            .take(2)

    private fun nextStage(
        current: ProspectStage,
        type: NetworkingActionType,
        result: InteractionResult
    ): ProspectStage {
        if (
            result == InteractionResult.NEGATIVE ||
            result == InteractionResult.NO_RESPONSE
        ) {
            return current
        }

        return when (type) {
            NetworkingActionType.CONNECTION ->
                ProspectStage.CONNECTED

            NetworkingActionType.PRE_CONSULTATION ->
                ProspectStage.PRE_CONSULTED

            NetworkingActionType.INVITATION ->
                ProspectStage.INVITED

            NetworkingActionType.BUSINESS_PRESENTATION ->
                ProspectStage.PRESENTED

            NetworkingActionType.FOLLOW_UP ->
                ProspectStage.FOLLOW_UP
        }
    }
}
