package com.herolife.feature.crm.domain

import com.herolife.feature.crm.model.InteractionResult
import com.herolife.feature.crm.model.NetworkingActionType
import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.Prospect
import com.herolife.feature.crm.model.ProspectStage

data class CrmSnapshot(
    val activeProspects: Int,
    val archivedProspects: Int,
    val hotProspects: Int,
    val followUpsPending: Int,
    val presentations: Int,
    val positiveResults: Int,
    val noResponses: Int,
    val stageCounts: Map<ProspectStage, Int>
)

object CrmAnalytics {

    fun snapshot(
        prospects: List<Prospect>,
        interactions: List<NetworkingInteraction>,
        pendingFollowUps: Int
    ): CrmSnapshot {
        val active =
            prospects.filterNot { it.archived }

        return CrmSnapshot(
            activeProspects = active.size,
            archivedProspects = prospects.count { it.archived },
            hotProspects = active.count {
                it.temperature.name == "HOT"
            },
            followUpsPending = pendingFollowUps,
            presentations = interactions.count {
                it.type == NetworkingActionType.BUSINESS_PRESENTATION
            },
            positiveResults = interactions.count {
                it.result == InteractionResult.POSITIVE ||
                    it.result == InteractionResult.COMPLETED
            },
            noResponses = interactions.count {
                it.result == InteractionResult.NO_RESPONSE
            },
            stageCounts = active
                .groupingBy { it.stage }
                .eachCount()
        )
    }
}
