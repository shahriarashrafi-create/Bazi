package com.herolife.feature.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.crm.model.NextAction

@Composable
fun NextActionsCard(
    actions: List<NextAction>,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "دو اقدام بعدی",
            style = MaterialTheme.typography.titleLarge,
            color = HeroLifeColors.GoldBright
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (actions.isEmpty()) {
                Text(
                    text = "اقدام بعدی ثبت نشده.",
                    color = HeroLifeColors.TextMuted
                )
            } else {
                actions.take(2).forEachIndexed { index, action ->
                    Text(
                        text = "${index + 1}. ${action.title}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (action.done) {
                            HeroLifeColors.Success
                        } else {
                            HeroLifeColors.TextPrimary
                        }
                    )
                }
            }
        }
    }
}
