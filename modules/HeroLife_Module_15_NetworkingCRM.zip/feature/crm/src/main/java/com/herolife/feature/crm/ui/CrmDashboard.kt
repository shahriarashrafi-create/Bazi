package com.herolife.feature.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.feature.crm.domain.CrmSnapshot

@Composable
fun CrmDashboard(
    snapshot: CrmSnapshot,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "مرکز شبکه‌سازی",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                label = "مخاطب فعال",
                value = snapshot.activeProspects.toString(),
                accent = HeroLifeColors.Crystal,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "مخاطب داغ",
                value = snapshot.hotProspects.toString(),
                accent = HeroLifeColors.Danger,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "فالوآپ باز",
                value = snapshot.followUpsPending.toString(),
                accent = HeroLifeColors.Gold,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "معرفی کار",
                value = snapshot.presentations.toString(),
                accent = HeroLifeColors.CrystalBright,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
