package com.herolife.feature.crm.model

enum class NetworkingActionType {
    CONNECTION,
    PRE_CONSULTATION,
    INVITATION,
    BUSINESS_PRESENTATION,
    FOLLOW_UP
}

enum class ProspectStage {
    NEW,
    CONNECTED,
    PRE_CONSULTED,
    INVITED,
    PRESENTED,
    FOLLOW_UP,
    DECISION,
    CUSTOMER,
    TEAM_MEMBER,
    NOT_NOW,
    CLOSED
}

enum class ProspectTemperature {
    COLD,
    WARM,
    HOT
}

enum class InteractionResult {
    POSITIVE,
    NEUTRAL,
    NEGATIVE,
    NO_RESPONSE,
    RESCHEDULED,
    COMPLETED
}

enum class FollowUpPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class Prospect(
    val id: String,
    val fullName: String,
    val phone: String = "",
    val socialHandle: String = "",
    val city: String = "",
    val occupation: String = "",
    val notes: String = "",
    val stage: ProspectStage = ProspectStage.NEW,
    val temperature: ProspectTemperature = ProspectTemperature.WARM,
    val referrerName: String = "",
    val advisorName: String = "",
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val archived: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(fullName.isNotBlank())
        require(createdAtMillis >= 0L)
        require(updatedAtMillis >= 0L)
    }
}

data class NetworkingInteraction(
    val id: String,
    val prospectId: String,
    val type: NetworkingActionType,
    val actorName: String = "",
    val referrerName: String = "",
    val advisorName: String = "",
    val result: InteractionResult,
    val summary: String = "",
    val occurredAtMillis: Long
) {
    init {
        require(id.isNotBlank())
        require(prospectId.isNotBlank())
        require(occurredAtMillis >= 0L)
    }
}

data class NextAction(
    val id: String,
    val prospectId: String,
    val title: String,
    val type: NetworkingActionType,
    val dueAtMillis: Long?,
    val priority: FollowUpPriority = FollowUpPriority.MEDIUM,
    val done: Boolean = false,
    val notes: String = ""
) {
    init {
        require(id.isNotBlank())
        require(prospectId.isNotBlank())
        require(title.isNotBlank())
        require(dueAtMillis == null || dueAtMillis >= 0L)
    }
}

data class ProspectTimeline(
    val prospect: Prospect,
    val interactions: List<NetworkingInteraction>,
    val nextActions: List<NextAction>
) {
    val pendingNextActions: List<NextAction>
        get() = nextActions
            .filterNot { it.done }
            .sortedWith(
                compareBy<NextAction> {
                    it.dueAtMillis ?: Long.MAX_VALUE
                }.thenByDescending {
                    priorityRank(it.priority)
                }
            )

    val firstNextAction: NextAction?
        get() = pendingNextActions.getOrNull(0)

    val secondNextAction: NextAction?
        get() = pendingNextActions.getOrNull(1)

    companion object {
        private fun priorityRank(
            priority: FollowUpPriority
        ): Int =
            when (priority) {
                FollowUpPriority.CRITICAL -> 4
                FollowUpPriority.HIGH -> 3
                FollowUpPriority.MEDIUM -> 2
                FollowUpPriority.LOW -> 1
            }
    }
}
