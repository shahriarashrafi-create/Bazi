package com.herolife.feature.crm.domain

import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.NextAction
import com.herolife.feature.crm.model.Prospect

interface ProspectRepository {
    fun prospects(): List<Prospect>
    fun prospectById(id: String): Prospect?
    fun saveProspect(prospect: Prospect)
    fun archiveProspect(id: String)
    fun deleteProspect(id: String)

    fun interactionsFor(prospectId: String): List<NetworkingInteraction>
    fun addInteraction(interaction: NetworkingInteraction)
    fun deleteInteraction(id: String)

    fun nextActionsFor(prospectId: String): List<NextAction>
    fun saveNextAction(action: NextAction)
    fun deleteNextAction(id: String)
}
