package com.herolife.feature.crm.domain

import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.NextAction
import com.herolife.feature.crm.model.Prospect

class InMemoryProspectRepository : ProspectRepository {

    private val prospects = linkedMapOf<String, Prospect>()
    private val interactions = linkedMapOf<String, NetworkingInteraction>()
    private val nextActions = linkedMapOf<String, NextAction>()

    override fun prospects(): List<Prospect> =
        prospects.values.toList()

    override fun prospectById(id: String): Prospect? =
        prospects[id]

    override fun saveProspect(prospect: Prospect) {
        prospects[prospect.id] = prospect
    }

    override fun archiveProspect(id: String) {
        val current = prospects[id] ?: return
        prospects[id] = current.copy(archived = true)
    }

    override fun deleteProspect(id: String) {
        prospects.remove(id)
        interactions.entries.removeAll { it.value.prospectId == id }
        nextActions.entries.removeAll { it.value.prospectId == id }
    }

    override fun interactionsFor(
        prospectId: String
    ): List<NetworkingInteraction> =
        interactions.values
            .filter { it.prospectId == prospectId }
            .sortedByDescending { it.occurredAtMillis }

    override fun addInteraction(interaction: NetworkingInteraction) {
        interactions[interaction.id] = interaction
    }

    override fun deleteInteraction(id: String) {
        interactions.remove(id)
    }

    override fun nextActionsFor(
        prospectId: String
    ): List<NextAction> =
        nextActions.values
            .filter { it.prospectId == prospectId }

    override fun saveNextAction(action: NextAction) {
        nextActions[action.id] = action
    }

    override fun deleteNextAction(id: String) {
        nextActions.remove(id)
    }
}
