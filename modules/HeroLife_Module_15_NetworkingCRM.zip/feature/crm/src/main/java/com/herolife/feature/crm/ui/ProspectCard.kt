package com.herolife.feature.crm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.crm.model.Prospect

@Composable
fun ProspectCard(
    prospect: Prospect,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = prospect.fullName,
                    style = MaterialTheme.typography.titleLarge,
                    color = HeroLifeColors.TextPrimary
                )

                Text(
                    text = stageLabel(prospect.stage.name),
                    style = MaterialTheme.typography.bodyMedium,
                    color = HeroLifeColors.Crystal
                )
            }

            Text(
                text = temperatureLabel(prospect.temperature.name),
                style = MaterialTheme.typography.labelLarge,
                color = when (prospect.temperature.name) {
                    "HOT" -> HeroLifeColors.Danger
                    "WARM" -> HeroLifeColors.Gold
                    else -> HeroLifeColors.TextMuted
                }
            )
        }

        if (prospect.referrerName.isNotBlank()) {
            Text(
                text = "معرف: ${prospect.referrerName}",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.TextSecondary
            )
        }

        if (prospect.advisorName.isNotBlank()) {
            Text(
                text = "مشاور: ${prospect.advisorName}",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.TextSecondary
            )
        }

        if (prospect.notes.isNotBlank()) {
            Text(
                text = prospect.notes,
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.TextMuted
            )
        }
    }
}

private fun stageLabel(stage: String): String =
    when (stage) {
        "NEW" -> "جدید"
        "CONNECTED" -> "ارتباط برقرار شد"
        "PRE_CONSULTED" -> "پیش‌مشاوره"
        "INVITED" -> "دعوت شده"
        "PRESENTED" -> "معرفی انجام شده"
        "FOLLOW_UP" -> "در فالوآپ"
        "DECISION" -> "در تصمیم"
        "CUSTOMER" -> "مشتری"
        "TEAM_MEMBER" -> "عضو تیم"
        "NOT_NOW" -> "فعلاً نه"
        else -> "بسته شده"
    }

private fun temperatureLabel(value: String): String =
    when (value) {
        "HOT" -> "داغ"
        "WARM" -> "گرم"
        else -> "سرد"
    }
