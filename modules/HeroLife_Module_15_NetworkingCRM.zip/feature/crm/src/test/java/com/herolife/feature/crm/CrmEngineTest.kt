package com.herolife.feature.crm

import com.herolife.feature.crm.domain.CrmEngine
import com.herolife.feature.crm.domain.InMemoryProspectRepository
import com.herolife.feature.crm.model.InteractionResult
import com.herolife.feature.crm.model.NetworkingActionType
import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.Prospect
import com.herolife.feature.crm.model.ProspectStage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CrmEngineTest {

    @Test
    fun positiveInvitationMovesStage() {
        val repository = InMemoryProspectRepository()
        val engine = CrmEngine(repository)

        engine.upsertProspect(
            Prospect(
                id = "p1",
                fullName = "Test",
                createdAtMillis = 1L,
                updatedAtMillis = 1L
            )
        )

        engine.recordInteraction(
            interaction = NetworkingInteraction(
                id = "i1",
                prospectId = "p1",
                type = NetworkingActionType.INVITATION,
                result = InteractionResult.POSITIVE,
                occurredAtMillis = 10L
            ),
            nowMillis = 10L
        )

        assertEquals(
            ProspectStage.INVITED,
            repository.prospectById("p1")?.stage
        )
    }

    @Test
    fun archiveKeepsProspectButMarksArchived() {
        val repository = InMemoryProspectRepository()
        val engine = CrmEngine(repository)

        engine.upsertProspect(
            Prospect(
                id = "p1",
                fullName = "Test",
                createdAtMillis = 1L,
                updatedAtMillis = 1L
            )
        )

        engine.archiveProspect("p1")

        assertTrue(
            repository.prospectById("p1")!!.archived
        )
    }
}
