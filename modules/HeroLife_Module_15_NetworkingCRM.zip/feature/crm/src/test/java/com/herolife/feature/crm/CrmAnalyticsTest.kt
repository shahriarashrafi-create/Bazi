package com.herolife.feature.crm

import com.herolife.feature.crm.domain.CrmAnalytics
import com.herolife.feature.crm.model.InteractionResult
import com.herolife.feature.crm.model.NetworkingActionType
import com.herolife.feature.crm.model.NetworkingInteraction
import com.herolife.feature.crm.model.Prospect
import com.herolife.feature.crm.model.ProspectTemperature
import org.junit.Assert.assertEquals
import org.junit.Test

class CrmAnalyticsTest {

    @Test
    fun snapshotCountsHotAndPresentations() {
        val prospects = listOf(
            Prospect(
                id = "1",
                fullName = "A",
                temperature = ProspectTemperature.HOT,
                createdAtMillis = 1L,
                updatedAtMillis = 1L
            )
        )

        val interactions = listOf(
            NetworkingInteraction(
                id = "i1",
                prospectId = "1",
                type = NetworkingActionType.BUSINESS_PRESENTATION,
                result = InteractionResult.POSITIVE,
                occurredAtMillis = 1L
            )
        )

        val snapshot =
            CrmAnalytics.snapshot(
                prospects = prospects,
                interactions = interactions,
                pendingFollowUps = 2
            )

        assertEquals(1, snapshot.hotProspects)
        assertEquals(1, snapshot.presentations)
        assertEquals(2, snapshot.followUpsPending)
    }
}
