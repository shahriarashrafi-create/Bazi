package com.herolife.feature.crm

import com.herolife.feature.crm.domain.FollowUpPlanner
import com.herolife.feature.crm.model.ProspectStage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FollowUpPlannerTest {

    @Test
    fun newProspectGetsTwoSuggestedActions() {
        val actions =
            FollowUpPlanner.suggestedActions(
                prospectId = "p1",
                stage = ProspectStage.NEW,
                nowMillis = 100L
            )

        assertEquals(2, actions.size)
    }

    @Test
    fun closedProspectGetsNoSuggestedActions() {
        val actions =
            FollowUpPlanner.suggestedActions(
                prospectId = "p1",
                stage = ProspectStage.CLOSED,
                nowMillis = 100L
            )

        assertTrue(actions.isEmpty())
    }
}
