# Module 15/20 — Networking CRM

Independent module: `:feature:crm`

## Implemented

- Prospect CRUD
- Archive support
- Permanent delete support
- Prospect stages
- Cold / Warm / Hot temperature
- Action types:
  - ارتباط‌سازی
  - پیش‌مشاوره
  - دعوت
  - معرفی کار
  - فالوآپ
- Actor / referrer
- Advisor
- Interaction result
- Notes
- Full interaction history
- Two next actions
- Follow-up priority
- Follow-up completion
- Suggested next actions
- Pipeline progression
- CRM analytics snapshot
- Active / archived counts
- Hot prospect count
- Presentation count
- Positive result count
- No-response count
- Stage distribution
- Dashboard UI
- Prospect card
- Interaction timeline
- Next-actions card
- In-memory repository
- Unit tests

## Architecture

The CRM core uses its own stable models and repository contract.
This keeps it independent from task/game modules and avoids fragile coupling.

A future persistence layer can implement `ProspectRepository`
with Room, SQLite, cloud sync, or a backend without changing the CRM domain layer.

## Next

Module 16 — Team Analytics
will add:
- network tree
- branches
- sales
- activity
- growth
- leader analytics
- branch comparison
- team momentum
