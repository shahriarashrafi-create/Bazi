package com.herolife.feature.tasks.domain

import com.herolife.feature.tasks.model.ManagedTask

object TaskSelector {

    fun prioritizedForBattle(
        tasks: List<ManagedTask>,
        limit: Int
    ): List<ManagedTask> {
        if (limit <= 0) return emptyList()

        return tasks
            .asSequence()
            .filter { it.isActive }
            .sortedWith(
                compareByDescending<ManagedTask> { priorityRank(it.priority) }
                    .thenBy { it.sortOrder }
                    .thenBy { it.estimatedMinutes }
            )
            .take(limit)
            .toList()
    }

    private fun priorityRank(priority: com.herolife.core.model.TaskPriority): Int =
        when (priority) {
            com.herolife.core.model.TaskPriority.CRITICAL -> 4
            com.herolife.core.model.TaskPriority.HIGH -> 3
            com.herolife.core.model.TaskPriority.MEDIUM -> 2
            com.herolife.core.model.TaskPriority.LOW -> 1
        }
}
