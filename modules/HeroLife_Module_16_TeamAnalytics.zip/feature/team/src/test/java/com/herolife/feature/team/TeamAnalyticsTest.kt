package com.herolife.feature.team
import com.herolife.feature.team.domain.*
import com.herolife.feature.team.model.*
import org.junit.Assert.*
import org.junit.Test

class TeamAnalyticsTest {
    private val members = listOf(
        TeamMember("root","Root",null,"b1",MemberRole.LEADER,100,500,80,newMembers=2),
        TeamMember("a","A","root","b1",personalSales=100,teamSales=250,activityScore=50),
        TeamMember("b","B","a","b1",personalSales=50,teamSales=100,activityScore=30)
    )

    @Test fun treeHasTwoDescendants() {
        val tree = NetworkTreeEngine.build(members, "root")!!
        assertEquals(2, NetworkTreeEngine.descendantsCount(tree))
    }

    @Test fun branchMetricsAggregate() {
        val m = BranchAnalyticsEngine.calculate(TeamBranch("b1","Main","root",1000), members)
        assertEquals(3, m.members)
        assertEquals(850L, m.teamSales)
        assertTrue(m.targetProgress > .8f)
    }

    @Test fun leaderScoreIsBounded() {
        val m = LeaderAnalyticsEngine.calculate(members.first(), members)
        assertTrue(m.leadershipScore in 0..100)
        assertEquals(2, m.teamSize)
    }

    @Test fun strongerSnapshotRises() {
        val previous = TeamGrowthSnapshot(3,2,100,50,0,ActivityTrend.STABLE)
        val current = TeamMomentumEngine.snapshot(members, previous)
        assertEquals(ActivityTrend.RISING, current.trend)
    }
}
