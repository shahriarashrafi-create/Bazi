package com.herolife.feature.team.domain
import com.herolife.feature.team.model.*
import kotlin.math.roundToInt

object LeaderAnalyticsEngine {
    fun calculate(member: TeamMember, members: List<TeamMember>): LeaderMetrics {
        val teamSize = descendants(member.id, members, emptySet())
        val direct = members.count { it.parentId == member.id && it.active }
        val salesPoints = when {
            member.teamSales >= 1_000_000 -> 20
            member.teamSales >= 500_000 -> 16
            member.teamSales >= 250_000 -> 12
            member.teamSales >= 100_000 -> 8
            else -> 4
        }
        val role = when (member.role) {
            MemberRole.SENIOR_LEADER -> 10
            MemberRole.LEADER -> 7
            MemberRole.ACTIVE_MEMBER -> 3
            MemberRole.MEMBER -> 0
        }
        val score = (member.activityScore.coerceAtMost(100) * .30f +
            member.newMembers.coerceAtMost(10) * 5f +
            direct.coerceAtMost(10) * 3f + salesPoints + role).roundToInt().coerceIn(0, 100)
        return LeaderMetrics(member.id, member.fullName, member.branchId, score,
            member.activityScore, member.personalSales, member.teamSales, teamSize, member.newMembers)
    }

    fun rankLeaders(members: List<TeamMember>) =
        members.filter { it.role == MemberRole.LEADER || it.role == MemberRole.SENIOR_LEADER }
            .map { calculate(it, members) }.sortedByDescending { it.leadershipScore }

    private fun descendants(parent: String, members: List<TeamMember>, visited: Set<String>): Int {
        if (parent in visited) return 0
        val children = members.filter { it.parentId == parent }
        val next = visited + parent
        return children.size + children.sumOf { descendants(it.id, members, next) }
    }
}
