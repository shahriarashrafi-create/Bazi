package com.herolife.feature.team.domain
import com.herolife.feature.team.model.TeamMember

data class TeamTreeNode(val member: TeamMember, val depth: Int, val children: List<TeamTreeNode>)

object NetworkTreeEngine {
    fun build(members: List<TeamMember>, rootId: String): TeamTreeNode? {
        val root = members.firstOrNull { it.id == rootId } ?: return null
        val children = members.groupBy { it.parentId }
        fun node(member: TeamMember, depth: Int, visited: Set<String>): TeamTreeNode {
            if (member.id in visited) return TeamTreeNode(member, depth, emptyList())
            val next = visited + member.id
            return TeamTreeNode(
                member, depth,
                children[member.id].orEmpty()
                    .filter { it.id !in visited }
                    .sortedByDescending { it.teamSales }
                    .map { node(it, depth + 1, next) }
            )
        }
        return node(root, 0, emptySet())
    }

    fun flatten(root: TeamTreeNode): List<TeamTreeNode> = buildList {
        fun visit(n: TeamTreeNode) { add(n); n.children.forEach(::visit) }
        visit(root)
    }

    fun descendantsCount(root: TeamTreeNode): Int = flatten(root).size - 1
}
