package com.herolife.feature.team.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.team.model.*

@Composable
fun TeamDashboard(snapshot: TeamGrowthSnapshot, modifier: Modifier = Modifier) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text("آمار تیم", style = MaterialTheme.typography.headlineMedium, color = HeroLifeColors.GoldBright)
        Text(
            when(snapshot.trend) {
                ActivityTrend.RISING -> "روند تیم: رو به رشد"
                ActivityTrend.STABLE -> "روند تیم: پایدار"
                ActivityTrend.FALLING -> "روند تیم: نیازمند توجه"
            },
            color = when(snapshot.trend) {
                ActivityTrend.RISING -> HeroLifeColors.Success
                ActivityTrend.STABLE -> HeroLifeColors.Crystal
                ActivityTrend.FALLING -> HeroLifeColors.Warning
            }
        )
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HeroLifeStatChip("اعضای کل", snapshot.totalMembers.toString(), HeroLifeColors.Crystal, Modifier.fillMaxWidth())
            HeroLifeStatChip("اعضای فعال", snapshot.activeMembers.toString(), HeroLifeColors.Success, Modifier.fillMaxWidth())
            HeroLifeStatChip("فروش", snapshot.totalSales.toString(), HeroLifeColors.Gold, Modifier.fillMaxWidth())
            HeroLifeStatChip("عضو جدید", snapshot.newMembers.toString(), HeroLifeColors.CrystalBright, Modifier.fillMaxWidth())
        }
    }
}
