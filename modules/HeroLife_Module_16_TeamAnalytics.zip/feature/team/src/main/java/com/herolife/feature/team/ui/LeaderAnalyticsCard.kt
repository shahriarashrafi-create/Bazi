package com.herolife.feature.team.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.*
import com.herolife.feature.team.model.LeaderMetrics

@Composable
fun LeaderAnalyticsCard(metrics: LeaderMetrics, modifier: Modifier = Modifier) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(metrics.fullName, style = MaterialTheme.typography.titleLarge, color = HeroLifeColors.TextPrimary)
            Text("${metrics.leadershipScore}/100", color = HeroLifeColors.GoldBright)
        }
        LinearProgressIndicator(
            progress = { metrics.leadershipScore / 100f },
            modifier = Modifier.fillMaxWidth(),
            color = HeroLifeColors.Gold,
            trackColor = HeroLifeColors.SurfaceHighlight
        )
        Text("اندازه تیم: ${metrics.teamSize}", color = HeroLifeColors.TextSecondary)
        Text("فعالیت: ${metrics.activityScore}", color = HeroLifeColors.Crystal)
        Text("فروش تیم: ${metrics.teamSales}", color = HeroLifeColors.Gold)
        Text("عضو جدید: ${metrics.newMembers}", color = HeroLifeColors.Success)
    }
}
