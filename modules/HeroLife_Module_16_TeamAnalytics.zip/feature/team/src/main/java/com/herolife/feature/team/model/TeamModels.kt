package com.herolife.feature.team.model

enum class MemberRole { MEMBER, ACTIVE_MEMBER, LEADER, SENIOR_LEADER }
enum class ActivityTrend { RISING, STABLE, FALLING }

data class TeamMember(
    val id: String,
    val fullName: String,
    val parentId: String?,
    val branchId: String,
    val role: MemberRole = MemberRole.MEMBER,
    val personalSales: Long = 0,
    val teamSales: Long = 0,
    val activityScore: Int = 0,
    val newContacts: Int = 0,
    val invitations: Int = 0,
    val presentations: Int = 0,
    val followUps: Int = 0,
    val newMembers: Int = 0,
    val active: Boolean = true
) {
    init {
        require(id.isNotBlank()); require(fullName.isNotBlank()); require(branchId.isNotBlank())
        require(personalSales >= 0); require(teamSales >= 0); require(activityScore >= 0)
        require(newContacts >= 0); require(invitations >= 0); require(presentations >= 0)
        require(followUps >= 0); require(newMembers >= 0)
    }
}

data class TeamBranch(
    val id: String,
    val name: String,
    val leaderId: String?,
    val targetSales: Long = 0
) {
    init { require(id.isNotBlank()); require(name.isNotBlank()); require(targetSales >= 0) }
}

data class BranchMetrics(
    val branchId: String,
    val branchName: String,
    val members: Int,
    val activeMembers: Int,
    val personalSales: Long,
    val teamSales: Long,
    val activityScore: Int,
    val newContacts: Int,
    val invitations: Int,
    val presentations: Int,
    val followUps: Int,
    val newMembers: Int,
    val targetSales: Long,
    val targetProgress: Float
)

data class LeaderMetrics(
    val memberId: String,
    val fullName: String,
    val branchId: String,
    val leadershipScore: Int,
    val activityScore: Int,
    val personalSales: Long,
    val teamSales: Long,
    val teamSize: Int,
    val newMembers: Int
)

data class TeamGrowthSnapshot(
    val totalMembers: Int,
    val activeMembers: Int,
    val totalSales: Long,
    val totalActivity: Int,
    val newMembers: Int,
    val trend: ActivityTrend
)
