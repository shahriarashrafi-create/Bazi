package com.herolife.feature.team.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.team.model.BranchMetrics

@Composable
fun BranchLeaderboard(branches: List<BranchMetrics>, modifier: Modifier = Modifier) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text("رتبه شاخه‌ها", style = MaterialTheme.typography.titleLarge, color = HeroLifeColors.TextPrimary)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            branches.forEachIndexed { index, branch ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${index + 1}. ${branch.branchName}", color = HeroLifeColors.TextPrimary)
                    Text(branch.teamSales.toString(), color = HeroLifeColors.GoldBright)
                }
                LinearProgressIndicator(
                    progress = { branch.targetProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = if (branch.targetProgress >= 1f) HeroLifeColors.Success else HeroLifeColors.Crystal,
                    trackColor = HeroLifeColors.SurfaceHighlight
                )
                Text("${branch.activeMembers}/${branch.members} فعال • ${branch.newMembers} عضو جدید",
                    style = MaterialTheme.typography.bodySmall, color = HeroLifeColors.TextMuted)
            }
        }
    }
}
