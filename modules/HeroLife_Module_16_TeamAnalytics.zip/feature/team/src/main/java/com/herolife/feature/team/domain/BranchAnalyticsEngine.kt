package com.herolife.feature.team.domain
import com.herolife.feature.team.model.*

object BranchAnalyticsEngine {
    fun calculate(branch: TeamBranch, members: List<TeamMember>): BranchMetrics {
        val m = members.filter { it.branchId == branch.id }
        val teamSales = m.sumOf { it.teamSales }
        val progress = if (branch.targetSales == 0L) 0f
            else (teamSales.toDouble() / branch.targetSales.toDouble()).toFloat().coerceIn(0f, 1.5f)
        return BranchMetrics(
            branch.id, branch.name, m.size, m.count { it.active },
            m.sumOf { it.personalSales }, teamSales, m.sumOf { it.activityScore },
            m.sumOf { it.newContacts }, m.sumOf { it.invitations }, m.sumOf { it.presentations },
            m.sumOf { it.followUps }, m.sumOf { it.newMembers }, branch.targetSales, progress
        )
    }

    fun rank(branches: List<TeamBranch>, members: List<TeamMember>): List<BranchMetrics> =
        branches.map { calculate(it, members) }
            .sortedWith(compareByDescending<BranchMetrics> { it.teamSales }
                .thenByDescending { it.activityScore }.thenByDescending { it.newMembers })
}
