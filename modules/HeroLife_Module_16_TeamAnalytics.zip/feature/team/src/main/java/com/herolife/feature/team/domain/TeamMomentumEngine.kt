package com.herolife.feature.team.domain
import com.herolife.feature.team.model.*

object TeamMomentumEngine {
    fun snapshot(members: List<TeamMember>, previous: TeamGrowthSnapshot? = null): TeamGrowthSnapshot {
        val active = members.count { it.active }
        val activity = members.sumOf { it.activityScore }
        val newMembers = members.sumOf { it.newMembers }
        val sales = members.sumOf { it.personalSales + it.teamSales }
        val currentScore = activity + active * 10 + newMembers * 20
        val trend = if (previous == null) ActivityTrend.STABLE else {
            val previousScore = previous.totalActivity + previous.activeMembers * 10 + previous.newMembers * 20
            when {
                currentScore > previousScore * 1.08 -> ActivityTrend.RISING
                currentScore < previousScore * 0.92 -> ActivityTrend.FALLING
                else -> ActivityTrend.STABLE
            }
        }
        return TeamGrowthSnapshot(members.size, active, sales, activity, newMembers, trend)
    }
}
