# Module 16/20 — Team Analytics

Independent module: `:feature:team`

Implemented:
- network tree and hierarchy
- branches and branch ranking
- personal/team sales
- activity, contacts, invitations, presentations, follow-ups
- active members and new-member growth
- branch targets and progress
- leader analytics with 0..100 leadership score
- descendant/team-size calculation
- team momentum: rising / stable / falling
- Team dashboard
- Branch leaderboard
- Leader analytics card
- pure Kotlin engines and tests

The module owns stable analytics models and intentionally avoids fragile
direct coupling to CRM storage. Integration can feed snapshots later.

Next: Module 17 — Events.
