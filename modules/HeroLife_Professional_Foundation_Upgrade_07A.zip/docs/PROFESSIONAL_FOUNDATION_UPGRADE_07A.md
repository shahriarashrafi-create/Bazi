# HeroLife — Professional Foundation Upgrade 07A

این بسته «ماژول شماره‌دار» نیست و شمارش 20 ماژول را تغییر نمی‌دهد.
هدف آن ارتقای زیرساخت بصری و کیفیت کد ماژول‌های 01 تا 07 است.

## اثر بسته

- APIهای قبلی Design System حفظ می‌شوند.
- Home، Profile، Hero، Tasks و Match بدون تغییر API از ظاهر حرفه‌ای‌تر بهره می‌برند.
- سیستم رنگ، Gradient، Glow، Panel، Button، Stat Chip، XP Bar و Section Header ارتقا پیدا می‌کند.
- Motion tokens و spacing/radius/elevation tokens اضافه می‌شوند.
- اجزای جدید برای HUD و کارت‌های بازی فراهم می‌شود.
- وابستگی Compose Animation به Design System افزوده می‌شود.

این بسته عمداً backward-compatible طراحی شده تا ZIPهای قبلی سالم بمانند.
