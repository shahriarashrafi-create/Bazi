package com.herolife.core.designsystem

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.ui.unit.dp

object HeroLifeSpacing {
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 20.dp
    val xl = 24.dp
    val xxl = 32.dp
}

object HeroLifeRadius {
    val small = 10.dp
    val medium = 16.dp
    val large = 22.dp
    val hero = 28.dp
    val pill = 999.dp
}

object HeroLifeElevation {
    val resting = 2.dp
    val raised = 8.dp
    val floating = 14.dp
}

object HeroLifeMotion {
    const val fast = 140
    const val standard = 240
    const val emphasized = 420

    val cinematicEase = CubicBezierEasing(
        a = 0.20f,
        b = 0.80f,
        c = 0.20f,
        d = 1.00f
    )

    fun <T> responsiveSpring() = spring<T>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMedium
    )
}
