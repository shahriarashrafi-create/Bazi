package com.herolife.core.designsystem

import androidx.compose.ui.graphics.Color

/**
 * Cinematic color system for HeroLife.
 *
 * Rules:
 * - Gold: progression, premium actions, victories.
 * - Crystal: information, XP, technology, networking.
 * - Green: successful real-world actions.
 * - Red: danger / pressure / defeat.
 * - Navy surfaces: keep the game cinematic and readable.
 */
object HeroLifeColors {
    val Void = Color(0xFF030811)
    val Night = Color(0xFF07111F)
    val DeepNavy = Color(0xFF0A1627)
    val Navy = Color(0xFF0E1D31)
    val Surface = Color(0xFF102238)
    val SurfaceRaised = Color(0xFF172D48)
    val SurfaceHighlight = Color(0xFF1D3858)

    val GoldDark = Color(0xFF8C6422)
    val Gold = Color(0xFFD8AF56)
    val GoldBright = Color(0xFFFFDA7A)
    val GoldSoft = Color(0xFFF3D89A)

    val CrystalDark = Color(0xFF157CA8)
    val Crystal = Color(0xFF56C7FF)
    val CrystalBright = Color(0xFF8FE0FF)
    val CrystalSoft = Color(0xFFBCEBFF)

    val TextPrimary = Color(0xFFF8FAFD)
    val TextSecondary = Color(0xFFA6B8CA)
    val TextMuted = Color(0xFF71859B)
    val Divider = Color(0xFF28435F)

    val Success = Color(0xFF5DDB9B)
    val SuccessDark = Color(0xFF20794E)
    val Warning = Color(0xFFFFC857)
    val Danger = Color(0xFFFF656F)
    val DangerDark = Color(0xFF8A2B35)

    val Overlay = Color(0xB3030811)
    val Transparent = Color(0x00000000)
}
