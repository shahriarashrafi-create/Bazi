package com.herolife.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HeroLifeBattleTopBar(
    timer: String,
    levelText: String,
    gold: Long,
    diamonds: Long,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(HeroLifeRadius.large)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        HeroLifeColors.Void.copy(alpha = 0.94f),
                        HeroLifeColors.DeepNavy.copy(alpha = 0.94f)
                    )
                )
            )
            .border(1.dp, HeroLifeColors.Divider, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeroLifeHudBadge(
                title = "سطح",
                value = levelText,
                accent = HeroLifeColors.Crystal
            )

            Text(
                text = timer,
                style = MaterialTheme.typography.headlineMedium,
                color = HeroLifeColors.GoldBright,
                fontWeight = FontWeight.Black
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            HeroLifeHudBadge(
                title = "طلا",
                value = "🪙 $gold",
                accent = HeroLifeColors.Gold
            )

            HeroLifeHudBadge(
                title = "الماس",
                value = "💎 $diamonds",
                accent = HeroLifeColors.Crystal
            )
        }
    }
}

@Composable
fun HeroLifePressureIndicator(
    label: String,
    pressure: Int,
    modifier: Modifier = Modifier
) {
    val safePressure = pressure.coerceIn(0, 100)
    val accent: Color = when {
        safePressure >= 70 -> HeroLifeColors.Danger
        safePressure >= 40 -> HeroLifeColors.Warning
        else -> HeroLifeColors.Success
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                text = "$safePressure%",
                style = MaterialTheme.typography.labelLarge,
                color = accent
            )
        }

        androidx.compose.material3.LinearProgressIndicator(
            progress = { safePressure / 100f },
            modifier = Modifier.fillMaxWidth(),
            color = accent,
            trackColor = HeroLifeColors.SurfaceHighlight
        )
    }
}
