package com.herolife.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val HeroLifeDarkScheme = darkColorScheme(
    primary = HeroLifeColors.Gold,
    onPrimary = HeroLifeColors.Void,
    primaryContainer = HeroLifeColors.GoldDark,
    onPrimaryContainer = HeroLifeColors.GoldSoft,

    secondary = HeroLifeColors.Crystal,
    onSecondary = HeroLifeColors.Void,
    secondaryContainer = HeroLifeColors.CrystalDark,
    onSecondaryContainer = HeroLifeColors.CrystalSoft,

    tertiary = HeroLifeColors.Success,
    onTertiary = HeroLifeColors.Void,

    background = HeroLifeColors.Night,
    onBackground = HeroLifeColors.TextPrimary,

    surface = HeroLifeColors.Surface,
    onSurface = HeroLifeColors.TextPrimary,

    surfaceVariant = HeroLifeColors.SurfaceRaised,
    onSurfaceVariant = HeroLifeColors.TextSecondary,

    outline = HeroLifeColors.Divider,
    outlineVariant = HeroLifeColors.SurfaceHighlight,

    error = HeroLifeColors.Danger,
    onError = HeroLifeColors.TextPrimary
)

@Composable
fun HeroLifeTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        MaterialTheme(
            colorScheme = HeroLifeDarkScheme,
            typography = heroLifeTypography(),
            content = content
        )
    }
}
