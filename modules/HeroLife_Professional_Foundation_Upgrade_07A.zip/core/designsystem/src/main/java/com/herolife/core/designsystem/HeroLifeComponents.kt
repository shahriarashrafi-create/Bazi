package com.herolife.core.designsystem

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun HeroLifePanel(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(HeroLifeRadius.large)

    Column(
        modifier = modifier
            .shadow(
                elevation = HeroLifeElevation.raised,
                shape = shape,
                ambientColor = HeroLifeColors.Void,
                spotColor = HeroLifeColors.CrystalDark.copy(alpha = 0.18f)
            )
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        HeroLifeColors.SurfaceRaised,
                        HeroLifeColors.Surface
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        HeroLifeColors.Gold.copy(alpha = 0.28f),
                        HeroLifeColors.Divider,
                        HeroLifeColors.Crystal.copy(alpha = 0.22f)
                    )
                ),
                shape = shape
            )
            .padding(HeroLifeSpacing.lg)
            .animateContentSize(),
        verticalArrangement = Arrangement.spacedBy(HeroLifeSpacing.sm),
        content = content
    )
}

@Composable
fun HeroLifePrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .heightIn(min = 60.dp)
            .shadow(
                elevation = HeroLifeElevation.raised,
                shape = RoundedCornerShape(HeroLifeRadius.medium),
                spotColor = HeroLifeColors.Gold.copy(alpha = 0.30f)
            ),
        shape = RoundedCornerShape(HeroLifeRadius.medium),
        colors = ButtonDefaults.buttonColors(
            containerColor = HeroLifeColors.Gold,
            contentColor = HeroLifeColors.Void,
            disabledContainerColor = HeroLifeColors.GoldDark.copy(alpha = 0.45f),
            disabledContentColor = HeroLifeColors.TextMuted
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HeroLifeStatChip(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(HeroLifeRadius.medium)

    Column(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.linearGradient(
                    listOf(
                        HeroLifeColors.DeepNavy,
                        accent.copy(alpha = 0.10f)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = accent.copy(alpha = 0.42f),
                shape = shape
            )
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = HeroLifeColors.TextSecondary,
            maxLines = 1
        )

        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = accent,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HeroLifeXpBar(
    progress: Float,
    modifier: Modifier = Modifier
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        label = "xpProgress"
    )

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        LinearProgressIndicator(
            progress = { animated },
            modifier = Modifier
                .fillMaxWidth()
                .height(9.dp)
                .clip(RoundedCornerShape(HeroLifeRadius.pill)),
            color = HeroLifeColors.Crystal,
            trackColor = HeroLifeColors.SurfaceHighlight
        )
    }
}

@Composable
fun HeroLifeSectionHeader(
    title: String,
    subtitle: String? = null,
    accent: Color = HeroLifeColors.Gold,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(HeroLifeSpacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 5.dp, height = 38.dp)
                .clip(RoundedCornerShape(HeroLifeRadius.pill))
                .background(accent)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = HeroLifeColors.TextPrimary
            )

            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = HeroLifeColors.TextSecondary
                )
            }
        }
    }
}

@Composable
fun HeroLifeHudBadge(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(HeroLifeRadius.pill)

    Row(
        modifier = modifier
            .clip(shape)
            .background(HeroLifeColors.Overlay)
            .border(1.dp, accent.copy(alpha = 0.45f), shape)
            .padding(horizontal = 13.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(accent)
        )

        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            color = HeroLifeColors.TextSecondary
        )

        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = accent
        )
    }
}

@Composable
fun HeroLifeCinematicFrame(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(HeroLifeRadius.hero)

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        HeroLifeColors.SurfaceHighlight,
                        HeroLifeColors.DeepNavy,
                        HeroLifeColors.Void
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        HeroLifeColors.Gold.copy(alpha = 0.48f),
                        HeroLifeColors.Crystal.copy(alpha = 0.30f),
                        HeroLifeColors.Divider
                    )
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun HeroLifeDivider(
    modifier: Modifier = Modifier
) {
    Spacer(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                brush = Brush.horizontalGradient(
                    listOf(
                        HeroLifeColors.Transparent,
                        HeroLifeColors.Divider,
                        HeroLifeColors.Transparent
                    )
                )
            )
    )
}
