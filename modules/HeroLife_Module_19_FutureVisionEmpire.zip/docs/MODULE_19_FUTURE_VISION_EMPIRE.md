# Module 19/20 — Future Vision & Empire

Independent module: `:feature:vision`

Implemented:
- Future Vision CRUD contract
- Year-by-year visions
- Financial / Lifestyle / Personal / Family categories
- Vision status
- Vision -> Goal -> Mission -> Action -> Reward chain
- Goal numeric progress
- Mission progress derived from completed actions
- Reward metadata and diamond cost
- Vision analytics
- Long-term Empire progression
- Empire tiers:
  Camp -> Outpost -> Village -> Town -> City -> Capital -> Kingdom -> Empire
- Deliberately slow months/years growth curve
- Lifetime XP, goals, missions and consistency feed development points
- Future Vision cards
- Goal progress UI
- Empire dashboard
- Canvas-based growing settlement visualization
- Unit tests

The empire curve is intentionally slow so short-term grinding cannot turn
the world into a full empire quickly.

Next: Module 20 — Final Integration & Release.
