package com.herolife.feature.vision.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.vision.model.EmpireTier

@Composable
fun EmpireCanvas(
    tier: EmpireTier,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        val groundY = size.height * 0.82f
        drawRect(
            color = HeroLifeColors.SurfaceHighlight,
            topLeft = Offset(0f, groundY),
            size = Size(size.width, size.height - groundY)
        )

        val count = when (tier) {
            EmpireTier.CAMP -> 1
            EmpireTier.OUTPOST -> 2
            EmpireTier.VILLAGE -> 3
            EmpireTier.TOWN -> 4
            EmpireTier.CITY -> 5
            EmpireTier.CAPITAL -> 6
            EmpireTier.KINGDOM -> 7
            EmpireTier.EMPIRE -> 8
        }

        val step = size.width / (count + 1f)

        repeat(count) { index ->
            val x = step * (index + 1)
            val h = (48.dp.toPx() + index * 7.dp.toPx()).coerceAtMost(size.height * .55f)
            val w = 30.dp.toPx()

            drawRect(
                color = if (index == count - 1) HeroLifeColors.GoldBright else HeroLifeColors.CrystalDark,
                topLeft = Offset(x - w / 2f, groundY - h),
                size = Size(w, h)
            )

            drawRect(
                color = HeroLifeColors.TextPrimary.copy(alpha = .55f),
                topLeft = Offset(x - w / 2f, groundY - h),
                size = Size(w, h),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        drawCircle(
            color = HeroLifeColors.GoldBright.copy(alpha = .20f),
            radius = 55.dp.toPx(),
            center = Offset(size.width * .78f, size.height * .25f)
        )
    }
}
