package com.herolife.feature.vision.domain

import com.herolife.feature.vision.model.*

class InMemoryVisionRepository : VisionRepository {
    private val visionMap = linkedMapOf<String, FutureVision>()
    private val goalMap = linkedMapOf<String, VisionGoal>()
    private val missionMap = linkedMapOf<String, VisionMission>()
    private val actionMap = linkedMapOf<String, VisionAction>()
    private val rewardMap = linkedMapOf<String, VisionReward>()

    override fun visions() = visionMap.values.toList()
    override fun saveVision(vision: FutureVision) { visionMap[vision.id] = vision }
    override fun deleteVision(id: String) {
        val goalIds = goalMap.values.filter { it.visionId == id }.map { it.id }.toSet()
        val missionIds = missionMap.values.filter { it.goalId in goalIds }.map { it.id }.toSet()
        visionMap.remove(id)
        goalMap.entries.removeAll { it.value.visionId == id }
        missionMap.entries.removeAll { it.value.goalId in goalIds }
        actionMap.entries.removeAll { it.value.missionId in missionIds }
        rewardMap.entries.removeAll { it.value.goalId in goalIds }
    }

    override fun goals(visionId: String) = goalMap.values.filter { it.visionId == visionId }
    override fun saveGoal(goal: VisionGoal) { goalMap[goal.id] = goal }
    override fun deleteGoal(id: String) {
        val missionIds = missionMap.values.filter { it.goalId == id }.map { it.id }.toSet()
        goalMap.remove(id)
        missionMap.entries.removeAll { it.value.goalId == id }
        actionMap.entries.removeAll { it.value.missionId in missionIds }
        rewardMap.entries.removeAll { it.value.goalId == id }
    }

    override fun missions() = missionMap.values.toList()
    override fun saveMission(mission: VisionMission) { missionMap[mission.id] = mission }
    override fun actions() = actionMap.values.toList()
    override fun saveAction(action: VisionAction) { actionMap[action.id] = action }
    override fun rewards() = rewardMap.values.toList()
    override fun saveReward(reward: VisionReward) { rewardMap[reward.id] = reward }
}
