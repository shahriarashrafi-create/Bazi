package com.herolife.feature.vision.domain

import com.herolife.feature.vision.model.*

data class VisionAnalyticsSnapshot(
    val totalVisions: Int,
    val activeVisions: Int,
    val achievedVisions: Int,
    val totalGoals: Int,
    val completedGoals: Int,
    val averageGoalProgress: Float,
    val categoryCounts: Map<VisionCategory, Int>
)

object VisionAnalytics {
    fun snapshot(
        visions: List<FutureVision>,
        goals: List<VisionGoal>
    ): VisionAnalyticsSnapshot {
        val average =
            if (goals.isEmpty()) 0f
            else goals.map { it.progress }.average().toFloat()

        return VisionAnalyticsSnapshot(
            totalVisions = visions.size,
            activeVisions = visions.count { it.status == VisionStatus.ACTIVE },
            achievedVisions = visions.count { it.status == VisionStatus.ACHIEVED },
            totalGoals = goals.size,
            completedGoals = goals.count { it.completed || it.progress >= 1f },
            averageGoalProgress = average.coerceIn(0f, 1f),
            categoryCounts = visions.groupingBy { it.category }.eachCount()
        )
    }
}
