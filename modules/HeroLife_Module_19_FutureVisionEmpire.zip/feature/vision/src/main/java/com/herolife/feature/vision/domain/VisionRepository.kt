package com.herolife.feature.vision.domain

import com.herolife.feature.vision.model.*

interface VisionRepository {
    fun visions(): List<FutureVision>
    fun saveVision(vision: FutureVision)
    fun deleteVision(id: String)

    fun goals(visionId: String): List<VisionGoal>
    fun saveGoal(goal: VisionGoal)
    fun deleteGoal(id: String)

    fun missions(): List<VisionMission>
    fun saveMission(mission: VisionMission)

    fun actions(): List<VisionAction>
    fun saveAction(action: VisionAction)

    fun rewards(): List<VisionReward>
    fun saveReward(reward: VisionReward)
}
