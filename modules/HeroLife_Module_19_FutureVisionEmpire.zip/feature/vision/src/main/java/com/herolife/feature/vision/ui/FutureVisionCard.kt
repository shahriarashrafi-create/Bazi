package com.herolife.feature.vision.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.vision.model.FutureVision

@Composable
fun FutureVisionCard(
    vision: FutureVision,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    vision.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = HeroLifeColors.TextPrimary
                )
                Text(
                    categoryLabel(vision.category.name),
                    color = HeroLifeColors.Crystal
                )
            }
            Text(
                vision.targetYear.toString(),
                style = MaterialTheme.typography.titleLarge,
                color = HeroLifeColors.GoldBright
            )
        }

        if (vision.description.isNotBlank()) {
            Text(
                vision.description,
                style = MaterialTheme.typography.bodyMedium,
                color = HeroLifeColors.TextSecondary
            )
        }
    }
}

private fun categoryLabel(value: String) = when (value) {
    "FINANCIAL" -> "مالی"
    "LIFESTYLE" -> "سبک زندگی"
    "PERSONAL" -> "شخصی"
    else -> "خانوادگی"
}
