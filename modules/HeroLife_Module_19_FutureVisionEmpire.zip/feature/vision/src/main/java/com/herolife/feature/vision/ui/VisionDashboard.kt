package com.herolife.feature.vision.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.vision.domain.VisionAnalyticsSnapshot

@Composable
fun VisionDashboard(
    snapshot: VisionAnalyticsSnapshot,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text(
            "Future Vision",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        LinearProgressIndicator(
            progress = { snapshot.averageGoalProgress },
            modifier = Modifier.fillMaxWidth(),
            color = HeroLifeColors.Crystal,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Column(
            Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                "چشم‌انداز فعال",
                snapshot.activeVisions.toString(),
                HeroLifeColors.Crystal,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "چشم‌انداز محقق‌شده",
                snapshot.achievedVisions.toString(),
                HeroLifeColors.Success,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "هدف تکمیل‌شده",
                "${snapshot.completedGoals}/${snapshot.totalGoals}",
                HeroLifeColors.Gold,
                Modifier.fillMaxWidth()
            )
        }
    }
}
