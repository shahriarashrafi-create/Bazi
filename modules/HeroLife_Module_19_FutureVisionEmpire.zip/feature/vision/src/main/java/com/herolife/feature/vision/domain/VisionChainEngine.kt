package com.herolife.feature.vision.domain

import com.herolife.feature.vision.model.*

class VisionChainEngine(
    private val repository: VisionRepository
) {
    fun chain(visionId: String): VisionChain? {
        val vision = repository.visions().firstOrNull { it.id == visionId } ?: return null
        val goals = repository.goals(visionId)
        val goalIds = goals.map { it.id }.toSet()
        val missions = repository.missions().filter { it.goalId in goalIds }
        val missionIds = missions.map { it.id }.toSet()

        return VisionChain(
            vision = vision,
            goals = goals,
            missions = missions,
            actions = repository.actions().filter { it.missionId in missionIds },
            rewards = repository.rewards().filter { it.goalId in goalIds }
        )
    }

    fun completeAction(
        actionId: String,
        nowMillis: Long
    ) {
        val action = repository.actions().firstOrNull { it.id == actionId } ?: return
        repository.saveAction(
            action.copy(
                completed = true,
                completedAtMillis = nowMillis
            )
        )
    }

    fun missionProgress(missionId: String): Float {
        val actions = repository.actions().filter { it.missionId == missionId }
        if (actions.isEmpty()) return 0f
        return actions.count { it.completed }.toFloat() / actions.size.toFloat()
    }

    fun refreshMission(missionId: String) {
        val mission = repository.missions().firstOrNull { it.id == missionId } ?: return
        val progress = missionProgress(missionId).coerceIn(0f, 1f)
        repository.saveMission(
            mission.copy(
                progress = progress,
                status = when {
                    progress >= 1f -> MissionStatus.COMPLETED
                    progress > 0f -> MissionStatus.ACTIVE
                    else -> mission.status
                }
            )
        )
    }
}
