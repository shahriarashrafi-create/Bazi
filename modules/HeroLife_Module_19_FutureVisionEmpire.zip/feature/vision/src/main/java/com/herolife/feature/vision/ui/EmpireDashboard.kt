package com.herolife.feature.vision.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.vision.model.EmpireProgress

@Composable
fun EmpireDashboard(
    progress: EmpireProgress,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Text(
            "امپراتوری من",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        EmpireCanvas(tier = progress.currentTier)

        Text(
            tierLabel(progress.currentTier.name),
            style = MaterialTheme.typography.titleLarge,
            color = HeroLifeColors.TextPrimary
        )

        LinearProgressIndicator(
            progress = { progress.progressToNext },
            modifier = Modifier.fillMaxWidth(),
            color = HeroLifeColors.Gold,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                "Development: ${progress.currentPoints}",
                color = HeroLifeColors.Crystal
            )
            progress.nextTier?.let {
                Text(
                    "مرحله بعد: ${tierLabel(it.name)}",
                    color = HeroLifeColors.TextSecondary
                )
            }
        }
    }
}

private fun tierLabel(value: String) = when (value) {
    "CAMP" -> "اردوگاه"
    "OUTPOST" -> "پایگاه"
    "VILLAGE" -> "روستا"
    "TOWN" -> "شهرک"
    "CITY" -> "شهر"
    "CAPITAL" -> "پایتخت"
    "KINGDOM" -> "پادشاهی"
    else -> "امپراتوری"
}
