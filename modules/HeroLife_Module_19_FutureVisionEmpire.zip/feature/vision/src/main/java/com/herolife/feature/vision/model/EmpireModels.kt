package com.herolife.feature.vision.model

enum class EmpireTier {
    CAMP,
    OUTPOST,
    VILLAGE,
    TOWN,
    CITY,
    CAPITAL,
    KINGDOM,
    EMPIRE
}

data class EmpireState(
    val lifetimeXp: Long = 0L,
    val completedGoals: Int = 0,
    val completedMissions: Int = 0,
    val consistencyDays: Int = 0,
    val tier: EmpireTier = EmpireTier.CAMP,
    val developmentPoints: Long = 0L
) {
    init {
        require(lifetimeXp >= 0L)
        require(completedGoals >= 0)
        require(completedMissions >= 0)
        require(consistencyDays >= 0)
        require(developmentPoints >= 0L)
    }
}

data class EmpireProgress(
    val currentTier: EmpireTier,
    val nextTier: EmpireTier?,
    val currentPoints: Long,
    val nextThreshold: Long?,
    val progressToNext: Float
)
