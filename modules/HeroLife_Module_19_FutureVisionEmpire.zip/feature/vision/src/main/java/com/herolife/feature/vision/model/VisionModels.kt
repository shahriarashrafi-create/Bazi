package com.herolife.feature.vision.model

enum class VisionCategory {
    FINANCIAL,
    LIFESTYLE,
    PERSONAL,
    FAMILY
}

enum class VisionStatus {
    IDEA,
    ACTIVE,
    ACHIEVED,
    ARCHIVED
}

enum class MissionStatus {
    PLANNED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}

data class FutureVision(
    val id: String,
    val title: String,
    val description: String = "",
    val category: VisionCategory,
    val targetYear: Int,
    val status: VisionStatus = VisionStatus.ACTIVE,
    val imageReference: String = "",
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    init {
        require(id.isNotBlank())
        require(title.isNotBlank())
        require(targetYear in 2020..2200)
        require(createdAtMillis >= 0L)
        require(updatedAtMillis >= 0L)
    }
}

data class VisionGoal(
    val id: String,
    val visionId: String,
    val title: String,
    val targetValue: Long = 100L,
    val currentValue: Long = 0L,
    val targetAtMillis: Long? = null,
    val completed: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(visionId.isNotBlank())
        require(title.isNotBlank())
        require(targetValue > 0L)
        require(currentValue >= 0L)
        require(targetAtMillis == null || targetAtMillis >= 0L)
    }

    val progress: Float
        get() = (
            currentValue.toDouble() /
                targetValue.toDouble()
            ).toFloat().coerceIn(0f, 1f)
}

data class VisionMission(
    val id: String,
    val goalId: String,
    val title: String,
    val status: MissionStatus = MissionStatus.PLANNED,
    val progress: Float = 0f
) {
    init {
        require(id.isNotBlank())
        require(goalId.isNotBlank())
        require(title.isNotBlank())
        require(progress in 0f..1f)
    }
}

data class VisionAction(
    val id: String,
    val missionId: String,
    val title: String,
    val completed: Boolean = false,
    val completedAtMillis: Long? = null
) {
    init {
        require(id.isNotBlank())
        require(missionId.isNotBlank())
        require(title.isNotBlank())
        require(completedAtMillis == null || completedAtMillis >= 0L)
    }
}

data class VisionReward(
    val id: String,
    val goalId: String,
    val title: String,
    val diamondCost: Int = 0,
    val unlocked: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(goalId.isNotBlank())
        require(title.isNotBlank())
        require(diamondCost >= 0)
    }
}

data class VisionChain(
    val vision: FutureVision,
    val goals: List<VisionGoal>,
    val missions: List<VisionMission>,
    val actions: List<VisionAction>,
    val rewards: List<VisionReward>
)
