package com.herolife.feature.vision.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.*
import com.herolife.feature.vision.model.VisionGoal

@Composable
fun VisionGoalCard(
    goal: VisionGoal,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(modifier = modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                goal.title,
                style = MaterialTheme.typography.titleMedium,
                color = HeroLifeColors.TextPrimary
            )
            Text(
                "${(goal.progress * 100).toInt()}%",
                color = if (goal.progress >= 1f) HeroLifeColors.Success else HeroLifeColors.Gold
            )
        }

        LinearProgressIndicator(
            progress = { goal.progress },
            modifier = Modifier.fillMaxWidth(),
            color = if (goal.progress >= 1f) HeroLifeColors.Success else HeroLifeColors.Crystal,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Text(
            "${goal.currentValue} / ${goal.targetValue}",
            color = HeroLifeColors.TextMuted
        )
    }
}
