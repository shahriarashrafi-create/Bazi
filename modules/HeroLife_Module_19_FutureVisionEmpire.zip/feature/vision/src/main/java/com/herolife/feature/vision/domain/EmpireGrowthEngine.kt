package com.herolife.feature.vision.domain

import com.herolife.feature.vision.model.*

object EmpireGrowthEngine {

    private val thresholds = linkedMapOf(
        EmpireTier.CAMP to 0L,
        EmpireTier.OUTPOST to 2_500L,
        EmpireTier.VILLAGE to 8_000L,
        EmpireTier.TOWN to 20_000L,
        EmpireTier.CITY to 50_000L,
        EmpireTier.CAPITAL to 120_000L,
        EmpireTier.KINGDOM to 300_000L,
        EmpireTier.EMPIRE to 750_000L
    )

    fun developmentPoints(
        lifetimeXp: Long,
        completedGoals: Int,
        completedMissions: Int,
        consistencyDays: Int
    ): Long {
        require(lifetimeXp >= 0L)
        require(completedGoals >= 0)
        require(completedMissions >= 0)
        require(consistencyDays >= 0)

        // Deliberately slow: empire growth is a long-term months/years system.
        return lifetimeXp / 20L +
            completedGoals * 500L +
            completedMissions * 120L +
            consistencyDays * 15L
    }

    fun evaluate(state: EmpireState): EmpireState {
        val points = developmentPoints(
            state.lifetimeXp,
            state.completedGoals,
            state.completedMissions,
            state.consistencyDays
        )

        val tier = thresholds.entries
            .lastOrNull { points >= it.value }
            ?.key ?: EmpireTier.CAMP

        return state.copy(
            tier = tier,
            developmentPoints = points
        )
    }

    fun progress(state: EmpireState): EmpireProgress {
        val evaluated = evaluate(state)
        val tiers = EmpireTier.entries
        val index = tiers.indexOf(evaluated.tier)
        val next = tiers.getOrNull(index + 1)
        val currentThreshold = thresholds[evaluated.tier] ?: 0L
        val nextThreshold = next?.let { thresholds[it] }

        val fraction =
            if (nextThreshold == null) {
                1f
            } else {
                val span = (nextThreshold - currentThreshold).coerceAtLeast(1L)
                val earned = (evaluated.developmentPoints - currentThreshold).coerceAtLeast(0L)
                (earned.toDouble() / span.toDouble()).toFloat().coerceIn(0f, 1f)
            }

        return EmpireProgress(
            currentTier = evaluated.tier,
            nextTier = next,
            currentPoints = evaluated.developmentPoints,
            nextThreshold = nextThreshold,
            progressToNext = fraction
        )
    }
}
