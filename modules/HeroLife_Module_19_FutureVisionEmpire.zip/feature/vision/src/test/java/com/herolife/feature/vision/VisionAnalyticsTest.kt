package com.herolife.feature.vision

import com.herolife.feature.vision.domain.VisionAnalytics
import com.herolife.feature.vision.model.*
import org.junit.Assert.*
import org.junit.Test

class VisionAnalyticsTest {

    @Test
    fun calculatesGoalProgress() {
        val visions = listOf(
            FutureVision(
                "v1", "Future", category = VisionCategory.LIFESTYLE,
                targetYear = 2030, createdAtMillis = 0, updatedAtMillis = 0
            )
        )
        val goals = listOf(
            VisionGoal("g1", "v1", "A", 100, 50),
            VisionGoal("g2", "v1", "B", 100, 100, completed = true)
        )

        val snapshot = VisionAnalytics.snapshot(visions, goals)

        assertEquals(2, snapshot.totalGoals)
        assertEquals(1, snapshot.completedGoals)
        assertTrue(snapshot.averageGoalProgress > .7f)
    }
}
