package com.herolife.feature.vision

import com.herolife.feature.vision.domain.EmpireGrowthEngine
import com.herolife.feature.vision.model.EmpireState
import com.herolife.feature.vision.model.EmpireTier
import org.junit.Assert.*
import org.junit.Test

class EmpireGrowthEngineTest {

    @Test
    fun newPlayerStartsAtCamp() {
        val result = EmpireGrowthEngine.evaluate(EmpireState())
        assertEquals(EmpireTier.CAMP, result.tier)
    }

    @Test
    fun progressIsAlwaysBounded() {
        val progress = EmpireGrowthEngine.progress(
            EmpireState(
                lifetimeXp = 100_000,
                completedGoals = 10,
                completedMissions = 20,
                consistencyDays = 100
            )
        )
        assertTrue(progress.progressToNext in 0f..1f)
    }

    @Test
    fun growthIsDeliberatelySlow() {
        val points = EmpireGrowthEngine.developmentPoints(
            lifetimeXp = 10_000,
            completedGoals = 1,
            completedMissions = 2,
            consistencyDays = 30
        )
        assertTrue(points < 2_500)
    }
}
