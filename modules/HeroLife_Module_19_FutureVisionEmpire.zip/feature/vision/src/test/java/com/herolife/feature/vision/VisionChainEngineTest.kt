package com.herolife.feature.vision

import com.herolife.feature.vision.domain.*
import com.herolife.feature.vision.model.*
import org.junit.Assert.*
import org.junit.Test

class VisionChainEngineTest {

    @Test
    fun actionCompletionUpdatesMissionProgress() {
        val repo = InMemoryVisionRepository()
        val engine = VisionChainEngine(repo)

        repo.saveVision(
            FutureVision(
                id = "v1",
                title = "Vision",
                category = VisionCategory.FINANCIAL,
                targetYear = 2030,
                createdAtMillis = 0,
                updatedAtMillis = 0
            )
        )
        repo.saveGoal(VisionGoal("g1", "v1", "Goal"))
        repo.saveMission(VisionMission("m1", "g1", "Mission"))
        repo.saveAction(VisionAction("a1", "m1", "Action 1"))
        repo.saveAction(VisionAction("a2", "m1", "Action 2"))

        engine.completeAction("a1", 100)
        engine.refreshMission("m1")

        assertEquals(.5f, engine.missionProgress("m1"), .001f)
        assertEquals(
            MissionStatus.ACTIVE,
            repo.missions().first().status
        )
    }
}
