package com.herolife.feature.vfx

import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.vfx.domain.ParticleFactory
import com.herolife.feature.vfx.domain.VfxDirector
import com.herolife.feature.vfx.model.VfxIntensity
import com.herolife.feature.vfx.model.VfxKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VfxDirectorTest {

    @Test
    fun rewardCreatesOnlyNeededEvents() {
        val director = VfxDirector()

        val events = director.reward(
            position = WorldPoint(10f, 10f),
            nowMillis = 1000L,
            xp = 10,
            gold = 5,
            diamonds = 0
        )

        assertEquals(2, events.size)
        assertTrue(events.any { it.kind == VfxKind.XP_GAIN })
        assertTrue(events.any { it.kind == VfxKind.GOLD_GAIN })
        assertFalse(events.any { it.kind == VfxKind.DIAMOND_GAIN })
    }

    @Test
    fun cinematicEventProducesStrongerShake() {
        val director = VfxDirector()

        val event = director.towerDestroyed(
            position = WorldPoint(0f, 0f),
            nowMillis = 500L
        )

        val shake = director.cameraShakeFor(event)

        assertTrue(shake.amplitudeX >= 10f)
        assertTrue(shake.durationMillis >= 300L)
    }

    @Test
    fun expiredVfxReportsExpired() {
        val director = VfxDirector()

        val event = director.heroAttack(
            position = WorldPoint(0f, 0f),
            nowMillis = 100L
        )

        assertFalse(event.isExpired(200L))
        assertTrue(event.isExpired(1000L))
    }

    @Test
    fun particleCountScalesWithIntensity() {
        val subtle = ParticleFactory.radialBurst(
            seed = 1,
            intensity = VfxIntensity.SUBTLE
        )

        val cinematic = ParticleFactory.radialBurst(
            seed = 1,
            intensity = VfxIntensity.CINEMATIC
        )

        assertTrue(cinematic.size > subtle.size)
    }
}
