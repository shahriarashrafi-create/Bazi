package com.herolife.feature.vfx

import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.vfx.domain.VfxDirector
import com.herolife.feature.vfx.domain.VfxTimeline
import com.herolife.feature.vfx.domain.VfxTimelineState
import org.junit.Assert.assertEquals
import org.junit.Test

class VfxTimelineTest {

    @Test
    fun pruneRemovesExpiredEvents() {
        val director = VfxDirector()
        val event = director.heroAttack(
            position = WorldPoint(0f, 0f),
            nowMillis = 0L
        )

        val state = VfxTimeline.add(
            state = VfxTimelineState(),
            events = listOf(event)
        )

        val pruned = VfxTimeline.prune(
            state = state,
            nowMillis = 10_000L
        )

        assertEquals(0, pruned.activeEvents.size)
    }
}
