package com.herolife.feature.vfx.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import com.herolife.feature.map.model.CameraState
import com.herolife.feature.vfx.domain.VfxDirector
import com.herolife.feature.vfx.model.CameraShakeState
import com.herolife.feature.vfx.model.VfxEvent

/**
 * High-level composable that layers:
 * - camera shake
 * - particles
 * - impact flash
 * - floating rewards
 *
 * It is renderer-agnostic: the underlying battlefield content is passed in.
 */
@Composable
fun CombatVfxScene(
    events: List<VfxEvent>,
    camera: CameraState,
    shake: CameraShakeState,
    nowMillis: Long,
    battlefield: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    val director = VfxDirector()
    val offset = director.cameraOffset(
        shake = shake,
        nowMillis = nowMillis
    )

    Box(
        modifier = modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = offset.first
                    translationY = offset.second
                }
        ) {
            battlefield()
        }

        CombatVfxLayer(
            events = events,
            camera = camera,
            nowMillis = nowMillis,
            modifier = Modifier.fillMaxSize()
        )

        FloatingRewardLayer(
            events = events,
            camera = camera,
            nowMillis = nowMillis,
            modifier = Modifier.fillMaxSize()
        )

        ImpactFlash(
            event = events.maxByOrNull { it.createdAtMillis },
            nowMillis = nowMillis,
            modifier = Modifier.fillMaxSize()
        )
    }
}
