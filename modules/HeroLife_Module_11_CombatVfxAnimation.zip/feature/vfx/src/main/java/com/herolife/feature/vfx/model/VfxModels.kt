package com.herolife.feature.vfx.model

import com.herolife.feature.map.model.WorldPoint

enum class VfxKind {
    HERO_ATTACK,
    MINION_HIT,
    MINION_DEFEATED,
    TOWER_HIT,
    TOWER_DESTROYED,
    CORE_HIT,
    XP_GAIN,
    GOLD_GAIN,
    DIAMOND_GAIN,
    VICTORY_BURST,
    DEFEAT_PULSE
}

enum class VfxIntensity {
    SUBTLE,
    MEDIUM,
    STRONG,
    CINEMATIC
}

data class VfxEvent(
    val id: String,
    val kind: VfxKind,
    val worldPosition: WorldPoint,
    val createdAtMillis: Long,
    val durationMillis: Long,
    val intensity: VfxIntensity = VfxIntensity.MEDIUM,
    val amount: Int? = null,
    val label: String? = null
) {
    init {
        require(id.isNotBlank())
        require(createdAtMillis >= 0)
        require(durationMillis > 0)
    }

    fun progress(nowMillis: Long): Float {
        val elapsed = (nowMillis - createdAtMillis).coerceAtLeast(0L)
        return (elapsed.toFloat() / durationMillis.toFloat()).coerceIn(0f, 1f)
    }

    fun isExpired(nowMillis: Long): Boolean =
        nowMillis >= createdAtMillis + durationMillis
}

data class Particle(
    val id: Int,
    val originX: Float,
    val originY: Float,
    val velocityX: Float,
    val velocityY: Float,
    val size: Float,
    val life: Float,
    val rotation: Float
)

data class CameraShakeState(
    val amplitudeX: Float = 0f,
    val amplitudeY: Float = 0f,
    val durationMillis: Long = 0L,
    val startedAtMillis: Long = 0L
) {
    fun active(nowMillis: Long): Boolean =
        durationMillis > 0L &&
            nowMillis < startedAtMillis + durationMillis
}

data class FloatingReward(
    val text: String,
    val worldPosition: WorldPoint,
    val createdAtMillis: Long,
    val durationMillis: Long = 1000L
)
