package com.herolife.feature.vfx.domain

import com.herolife.feature.map.model.WorldPoint
import com.herolife.feature.vfx.model.CameraShakeState
import com.herolife.feature.vfx.model.VfxEvent
import com.herolife.feature.vfx.model.VfxIntensity
import com.herolife.feature.vfx.model.VfxKind
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Central pure VFX orchestration.
 *
 * It converts gameplay events into deterministic visual events.
 * Rendering is deliberately kept outside this class.
 */
class VfxDirector {

    fun heroAttack(
        position: WorldPoint,
        nowMillis: Long
    ): VfxEvent =
        VfxEvent(
            id = "attack_$nowMillis",
            kind = VfxKind.HERO_ATTACK,
            worldPosition = position,
            createdAtMillis = nowMillis,
            durationMillis = 420L,
            intensity = VfxIntensity.MEDIUM
        )

    fun minionDefeated(
        position: WorldPoint,
        nowMillis: Long
    ): VfxEvent =
        VfxEvent(
            id = "minion_down_$nowMillis",
            kind = VfxKind.MINION_DEFEATED,
            worldPosition = position,
            createdAtMillis = nowMillis,
            durationMillis = 760L,
            intensity = VfxIntensity.STRONG
        )

    fun towerHit(
        position: WorldPoint,
        nowMillis: Long,
        damage: Int
    ): VfxEvent =
        VfxEvent(
            id = "tower_hit_$nowMillis",
            kind = VfxKind.TOWER_HIT,
            worldPosition = position,
            createdAtMillis = nowMillis,
            durationMillis = 520L,
            intensity = VfxIntensity.STRONG,
            amount = damage
        )

    fun towerDestroyed(
        position: WorldPoint,
        nowMillis: Long
    ): VfxEvent =
        VfxEvent(
            id = "tower_destroyed_$nowMillis",
            kind = VfxKind.TOWER_DESTROYED,
            worldPosition = position,
            createdAtMillis = nowMillis,
            durationMillis = 1400L,
            intensity = VfxIntensity.CINEMATIC
        )

    fun reward(
        position: WorldPoint,
        nowMillis: Long,
        xp: Int,
        gold: Int,
        diamonds: Int
    ): List<VfxEvent> {
        val events = mutableListOf<VfxEvent>()

        if (xp > 0) {
            events += VfxEvent(
                id = "xp_$nowMillis",
                kind = VfxKind.XP_GAIN,
                worldPosition = position,
                createdAtMillis = nowMillis,
                durationMillis = 1000L,
                intensity = VfxIntensity.MEDIUM,
                amount = xp,
                label = "+$xp XP"
            )
        }

        if (gold > 0) {
            events += VfxEvent(
                id = "gold_${nowMillis + 1L}",
                kind = VfxKind.GOLD_GAIN,
                worldPosition = position,
                createdAtMillis = nowMillis,
                durationMillis = 1100L,
                intensity = VfxIntensity.MEDIUM,
                amount = gold,
                label = "+$gold"
            )
        }

        if (diamonds > 0) {
            events += VfxEvent(
                id = "diamond_${nowMillis + 2L}",
                kind = VfxKind.DIAMOND_GAIN,
                worldPosition = position,
                createdAtMillis = nowMillis,
                durationMillis = 1400L,
                intensity = VfxIntensity.CINEMATIC,
                amount = diamonds,
                label = "+$diamonds 💎"
            )
        }

        return events
    }

    fun cameraShakeFor(
        event: VfxEvent
    ): CameraShakeState =
        when (event.intensity) {
            VfxIntensity.SUBTLE -> CameraShakeState(
                amplitudeX = 2f,
                amplitudeY = 1.5f,
                durationMillis = 120L,
                startedAtMillis = event.createdAtMillis
            )

            VfxIntensity.MEDIUM -> CameraShakeState(
                amplitudeX = 5f,
                amplitudeY = 3.5f,
                durationMillis = 180L,
                startedAtMillis = event.createdAtMillis
            )

            VfxIntensity.STRONG -> CameraShakeState(
                amplitudeX = 9f,
                amplitudeY = 7f,
                durationMillis = 260L,
                startedAtMillis = event.createdAtMillis
            )

            VfxIntensity.CINEMATIC -> CameraShakeState(
                amplitudeX = 14f,
                amplitudeY = 10f,
                durationMillis = 420L,
                startedAtMillis = event.createdAtMillis
            )
        }

    fun cameraOffset(
        shake: CameraShakeState,
        nowMillis: Long
    ): Pair<Float, Float> {
        if (!shake.active(nowMillis)) return 0f to 0f

        val elapsed = nowMillis - shake.startedAtMillis
        val progress = (elapsed.toFloat() / shake.durationMillis.toFloat())
            .coerceIn(0f, 1f)

        val decay = 1f - progress
        val phase = progress * 10f * PI.toFloat()

        val x = sin(phase) * shake.amplitudeX * decay
        val y = cos(phase * 1.37f) * shake.amplitudeY * decay

        return x to y
    }
}
