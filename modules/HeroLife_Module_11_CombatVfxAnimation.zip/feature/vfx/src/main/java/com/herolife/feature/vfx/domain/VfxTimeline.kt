package com.herolife.feature.vfx.domain

import com.herolife.feature.vfx.model.VfxEvent

data class VfxTimelineState(
    val activeEvents: List<VfxEvent> = emptyList()
)

object VfxTimeline {

    fun add(
        state: VfxTimelineState,
        events: List<VfxEvent>
    ): VfxTimelineState =
        state.copy(
            activeEvents = (state.activeEvents + events)
                .distinctBy { it.id }
        )

    fun prune(
        state: VfxTimelineState,
        nowMillis: Long
    ): VfxTimelineState =
        state.copy(
            activeEvents = state.activeEvents
                .filterNot { it.isExpired(nowMillis) }
        )
}
