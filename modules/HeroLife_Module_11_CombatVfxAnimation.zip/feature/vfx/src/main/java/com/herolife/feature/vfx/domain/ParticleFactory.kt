package com.herolife.feature.vfx.domain

import com.herolife.feature.vfx.model.Particle
import com.herolife.feature.vfx.model.VfxIntensity
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object ParticleFactory {

    fun radialBurst(
        seed: Int,
        intensity: VfxIntensity
    ): List<Particle> {
        val count = when (intensity) {
            VfxIntensity.SUBTLE -> 8
            VfxIntensity.MEDIUM -> 14
            VfxIntensity.STRONG -> 24
            VfxIntensity.CINEMATIC -> 38
        }

        val speed = when (intensity) {
            VfxIntensity.SUBTLE -> 70f
            VfxIntensity.MEDIUM -> 100f
            VfxIntensity.STRONG -> 145f
            VfxIntensity.CINEMATIC -> 200f
        }

        return List(count) { index ->
            val angle =
                ((index.toFloat() / count.toFloat()) * 2f * PI.toFloat()) +
                    ((seed % 17) * 0.013f)

            val variation =
                0.72f + ((index * 37 + seed).mod(23) / 23f) * 0.56f

            Particle(
                id = index,
                originX = 0f,
                originY = 0f,
                velocityX = cos(angle) * speed * variation,
                velocityY = sin(angle) * speed * variation,
                size = 3f + ((index + seed).mod(6)).toFloat(),
                life = 0.65f + ((index * 7 + seed).mod(25)) / 100f,
                rotation = angle
            )
        }
    }
}
