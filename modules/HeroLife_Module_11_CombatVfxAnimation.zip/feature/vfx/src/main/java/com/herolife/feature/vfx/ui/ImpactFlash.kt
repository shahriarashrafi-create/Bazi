package com.herolife.feature.vfx.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.vfx.model.VfxEvent
import com.herolife.feature.vfx.model.VfxIntensity

@Composable
fun ImpactFlash(
    event: VfxEvent?,
    nowMillis: Long,
    modifier: Modifier = Modifier
) {
    if (event == null) return

    val progress = event.progress(nowMillis)
    val baseAlpha = when (event.intensity) {
        VfxIntensity.SUBTLE -> 0.05f
        VfxIntensity.MEDIUM -> 0.08f
        VfxIntensity.STRONG -> 0.13f
        VfxIntensity.CINEMATIC -> 0.20f
    }

    val alpha =
        (baseAlpha * (1f - progress) * 2f)
            .coerceIn(0f, baseAlpha)

    if (alpha <= 0f) return

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                HeroLifeColors.TextPrimary.copy(alpha = alpha)
            )
    )
}
