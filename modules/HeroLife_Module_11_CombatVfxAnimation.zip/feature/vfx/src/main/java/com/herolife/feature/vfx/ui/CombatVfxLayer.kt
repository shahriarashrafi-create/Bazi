package com.herolife.feature.vfx.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.domain.MapCoordinateMapper
import com.herolife.feature.map.model.CameraState
import com.herolife.feature.vfx.domain.ParticleFactory
import com.herolife.feature.vfx.model.VfxEvent
import com.herolife.feature.vfx.model.VfxKind
import kotlin.math.max

@Composable
fun CombatVfxLayer(
    events: List<VfxEvent>,
    camera: CameraState,
    nowMillis: Long,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier.fillMaxSize()
    ) {
        val screenW = size.width
        val screenH = size.height

        events.forEach { event ->
            val progress = event.progress(nowMillis)
            val screen = MapCoordinateMapper.worldToScreen(
                point = event.worldPosition,
                camera = camera,
                screenWidth = screenW,
                screenHeight = screenH
            )

            val origin = Offset(screen.x, screen.y)

            when (event.kind) {
                VfxKind.HERO_ATTACK -> {
                    val radius = 28.dp.toPx() + 90.dp.toPx() * progress
                    drawCircle(
                        color = HeroLifeColors.GoldBright.copy(
                            alpha = 0.72f * (1f - progress)
                        ),
                        radius = radius,
                        center = origin,
                        style = Stroke(
                            width = max(
                                1.dp.toPx(),
                                7.dp.toPx() * (1f - progress)
                            )
                        )
                    )
                }

                VfxKind.MINION_HIT,
                VfxKind.MINION_DEFEATED,
                VfxKind.TOWER_HIT,
                VfxKind.TOWER_DESTROYED,
                VfxKind.CORE_HIT -> {
                    val particles = ParticleFactory.radialBurst(
                        seed = event.id.hashCode(),
                        intensity = event.intensity
                    )

                    particles.forEach { particle ->
                        val p = (progress / particle.life).coerceIn(0f, 1f)
                        val gravity = 160f
                        val px =
                            origin.x +
                                particle.velocityX * p

                        val py =
                            origin.y +
                                particle.velocityY * p +
                                gravity * p * p

                        val alpha = (1f - p).coerceIn(0f, 1f)

                        drawCircle(
                            color = eventColor(event.kind).copy(alpha = alpha),
                            radius = particle.size.dp.toPx(),
                            center = Offset(px, py)
                        )
                    }

                    val shockwaveRadius =
                        24.dp.toPx() + 120.dp.toPx() * progress

                    drawCircle(
                        color = eventColor(event.kind).copy(
                            alpha = 0.55f * (1f - progress)
                        ),
                        radius = shockwaveRadius,
                        center = origin,
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                VfxKind.XP_GAIN,
                VfxKind.GOLD_GAIN,
                VfxKind.DIAMOND_GAIN -> {
                    val radius =
                        12.dp.toPx() + 34.dp.toPx() * progress

                    drawCircle(
                        color = eventColor(event.kind).copy(
                            alpha = 0.58f * (1f - progress)
                        ),
                        radius = radius,
                        center = Offset(
                            origin.x,
                            origin.y - 70.dp.toPx() * progress
                        )
                    )
                }

                VfxKind.VICTORY_BURST -> {
                    val radius =
                        60.dp.toPx() + 220.dp.toPx() * progress

                    drawCircle(
                        color = HeroLifeColors.GoldBright.copy(
                            alpha = 0.48f * (1f - progress)
                        ),
                        radius = radius,
                        center = origin,
                        style = Stroke(width = 7.dp.toPx())
                    )
                }

                VfxKind.DEFEAT_PULSE -> {
                    val radius =
                        40.dp.toPx() + 150.dp.toPx() * progress

                    drawCircle(
                        color = HeroLifeColors.Danger.copy(
                            alpha = 0.45f * (1f - progress)
                        ),
                        radius = radius,
                        center = origin,
                        style = Stroke(width = 6.dp.toPx())
                    )
                }
            }
        }
    }
}

private fun eventColor(
    kind: VfxKind
): Color =
    when (kind) {
        VfxKind.HERO_ATTACK -> HeroLifeColors.GoldBright
        VfxKind.MINION_HIT -> HeroLifeColors.Warning
        VfxKind.MINION_DEFEATED -> HeroLifeColors.Success
        VfxKind.TOWER_HIT -> HeroLifeColors.Danger
        VfxKind.TOWER_DESTROYED -> HeroLifeColors.Gold
        VfxKind.CORE_HIT -> HeroLifeColors.Danger
        VfxKind.XP_GAIN -> HeroLifeColors.Crystal
        VfxKind.GOLD_GAIN -> HeroLifeColors.Gold
        VfxKind.DIAMOND_GAIN -> HeroLifeColors.CrystalBright
        VfxKind.VICTORY_BURST -> HeroLifeColors.GoldBright
        VfxKind.DEFEAT_PULSE -> HeroLifeColors.Danger
    }
