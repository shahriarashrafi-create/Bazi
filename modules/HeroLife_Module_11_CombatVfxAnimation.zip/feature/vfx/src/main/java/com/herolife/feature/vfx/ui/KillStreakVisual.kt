package com.herolife.feature.vfx.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeRadius

enum class KillStreakVisualType(
    val title: String,
    val subtitle: String
) {
    DOUBLE_KILL(
        title = "DOUBLE KILL",
        subtitle = "دو مانع پشت سر هم کنار رفت."
    ),
    TRIPLE_KILL(
        title = "TRIPLE KILL",
        subtitle = "ریتمت را حفظ کن."
    ),
    UNSTOPPABLE(
        title = "UNSTOPPABLE",
        subtitle = "هیچ چیز جلوی حرکتت را نمی‌گیرد."
    ),
    DOMINATING(
        title = "DOMINATING",
        subtitle = "میدان در اختیار توست."
    ),
    LEGENDARY(
        title = "LEGENDARY",
        subtitle = "امروز داری افسانه می‌سازی."
    )
}

@Composable
fun KillStreakVisual(
    visible: Boolean,
    streak: KillStreakVisualType?,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible && streak != null,
        enter = fadeIn() + scaleIn(initialScale = 0.84f),
        exit = fadeOut() + scaleOut(targetScale = 1.08f)
    ) {
        if (streak != null) {
            val shape = RoundedCornerShape(HeroLifeRadius.hero)

            Column(
                modifier = modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                HeroLifeColors.Transparent,
                                HeroLifeColors.GoldDark.copy(alpha = 0.72f),
                                HeroLifeColors.DeepNavy.copy(alpha = 0.94f),
                                HeroLifeColors.GoldDark.copy(alpha = 0.72f),
                                HeroLifeColors.Transparent
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = HeroLifeColors.Gold.copy(alpha = 0.48f),
                        shape = shape
                    )
                    .padding(
                        horizontal = 20.dp,
                        vertical = 14.dp
                    ),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = streak.title,
                    style = MaterialTheme.typography.headlineLarge,
                    color = HeroLifeColors.GoldBright,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = streak.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = HeroLifeColors.TextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
