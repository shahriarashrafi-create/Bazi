package com.herolife.feature.vfx.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.text.font.FontWeight
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.domain.MapCoordinateMapper
import com.herolife.feature.map.model.CameraState
import com.herolife.feature.vfx.model.VfxEvent
import com.herolife.feature.vfx.model.VfxKind
import kotlin.math.roundToInt

@Composable
fun FloatingRewardLayer(
    events: List<VfxEvent>,
    camera: CameraState,
    nowMillis: Long,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize()
    ) {
        events
            .filter {
                it.kind == VfxKind.XP_GAIN ||
                    it.kind == VfxKind.GOLD_GAIN ||
                    it.kind == VfxKind.DIAMOND_GAIN
            }
            .forEach { event ->
                val progress = event.progress(nowMillis)
                val alpha = (1f - progress).coerceIn(0f, 1f)

                FloatingPosition(
                    xWorld = event.worldPosition.x,
                    yWorld = event.worldPosition.y,
                    camera = camera,
                    progress = progress
                ) {
                    Text(
                        text = event.label.orEmpty(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = when (event.kind) {
                            VfxKind.XP_GAIN -> HeroLifeColors.Crystal
                            VfxKind.GOLD_GAIN -> HeroLifeColors.GoldBright
                            VfxKind.DIAMOND_GAIN -> HeroLifeColors.CrystalBright
                            else -> HeroLifeColors.TextPrimary
                        },
                        modifier = Modifier.graphicsLayer {
                            this.alpha = alpha
                            scaleX = 0.92f + 0.08f * (1f - progress)
                            scaleY = scaleX
                        }
                    )
                }
            }
    }
}

@Composable
private fun FloatingPosition(
    xWorld: Float,
    yWorld: Float,
    camera: CameraState,
    progress: Float,
    content: @Composable () -> Unit
) {
    Layout(
        content = content
    ) { measurables, constraints ->
        val measurable = measurables.first()
        val placeable = measurable.measure(constraints)

        val screen = MapCoordinateMapper.worldToScreen(
            point = com.herolife.feature.map.model.WorldPoint(
                xWorld,
                yWorld
            ),
            camera = camera,
            screenWidth = constraints.maxWidth.toFloat(),
            screenHeight = constraints.maxHeight.toFloat()
        )

        layout(
            width = constraints.maxWidth,
            height = constraints.maxHeight
        ) {
            val x =
                (screen.x - placeable.width / 2f)
                    .roundToInt()

            val y =
                (screen.y -
                    110f * progress -
                    placeable.height / 2f)
                    .roundToInt()

            placeable.placeRelative(
                x = x,
                y = y
            )
        }
    }
}
