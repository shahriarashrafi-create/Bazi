# Module 11/20 — Combat VFX & Animation

Independent module: `:feature:vfx`

## Implemented

- Hero attack shockwave
- Minion hit / defeat particle burst
- Tower hit effect
- Tower destruction cinematic burst
- Core hit effect contract
- XP / Gold / Diamond floating reward effects
- Camera shake system
- Intensity levels
- Impact screen flash
- Deterministic particle generation
- VFX timeline
- Floating reward labels
- Kill streak visual banners
- DOUBLE KILL
- TRIPLE KILL
- UNSTOPPABLE
- DOMINATING
- LEGENDARY
- High-level CombatVfxScene composition
- Unit tests

## Architecture

`VfxDirector` and `ParticleFactory` are pure Kotlin.
Compose is only responsible for rendering.

That separation keeps future upgrades possible:
- OpenGL/Surface renderer
- custom shader renderer
- richer particle engine
- authored sprite sheets
- skeletal hero animation

without rewriting gameplay logic.

## Product direction

This module intentionally improves visual feel without introducing copyrighted game assets.
The goal is a cinematic MOBA-inspired experience with HeroLife's own visual identity.

## Next

Module 12 — Sound & Female Announcer
will connect:
- footsteps
- ambience
- encounter
- task completion
- attacks
- tower impact/destruction
- coin / XP / diamond sounds
- low-time tension
- victory / defeat music
- female kill-streak announcer
