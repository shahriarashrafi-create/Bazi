# Module 06/20 — Task Manager

Independent module: `:feature:tasks`

## Core responsibilities
- Task CRUD contract
- Active / archive state
- Priority
- Battle lane
- Estimated duration
- Difficulty
- XP / Gold / Diamond metadata
- Max occurrences per session
- Repeat configuration
- Allowed weekdays
- Time window
- Minimum repeat gap
- Reordering
- Priority-based Battle selector
- Compose task manager screen
- Unit tests

## Product rule
Deleting a task from a Battle later will not mean permanently deleting it from Task Library.
This module deliberately keeps Task Library state separate from the future Match Engine.

## Safe deletion
`archive()` is the normal history-safe action.
`deletePermanently()` exists as an explicit low-level repository operation.
