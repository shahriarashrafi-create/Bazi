package com.herolife.feature.tasks.data

import com.herolife.feature.tasks.model.ManagedTask

interface TaskRepository {
    fun getAll(): List<ManagedTask>
    fun getActive(): List<ManagedTask>
    fun findById(id: String): ManagedTask?
    fun upsert(task: ManagedTask)
    fun archive(id: String)
    fun deletePermanently(id: String)
    fun reorder(taskIdsInOrder: List<String>)
}
