package com.herolife.feature.tasks.domain

import com.herolife.feature.tasks.model.ManagedTask

object TaskSelector {

    fun prioritizedForBattle(
        tasks: List<ManagedTask>,
        limit: Int
    ): List<ManagedTask> {
        if (limit <= 0) return emptyList()

        return tasks
            .asSequence()
            .filter { it.isActive }
            .sortedWith(
                compareByDescending<ManagedTask> { it.priority.weight }
                    .thenBy { it.sortOrder }
                    .thenBy { it.estimatedMinutes }
            )
            .take(limit)
            .toList()
    }
}
