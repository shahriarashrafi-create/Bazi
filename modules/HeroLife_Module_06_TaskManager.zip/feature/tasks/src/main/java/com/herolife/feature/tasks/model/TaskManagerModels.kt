package com.herolife.feature.tasks.model

import com.herolife.core.model.GameLane
import com.herolife.core.model.TaskPriority

enum class TaskDifficulty {
    EASY,
    NORMAL,
    HARD
}

enum class RepeatType {
    NONE,
    DAILY,
    WEEKLY,
    CUSTOM
}

data class TaskSchedule(
    val repeatType: RepeatType = RepeatType.NONE,
    val allowedWeekDays: Set<Int> = emptySet(),
    val startMinuteOfDay: Int? = null,
    val endMinuteOfDay: Int? = null,
    val minimumRepeatGapMinutes: Int = 0
) {
    init {
        require(allowedWeekDays.all { it in 1..7 })
        require(startMinuteOfDay == null || startMinuteOfDay in 0..1439)
        require(endMinuteOfDay == null || endMinuteOfDay in 0..1439)
        require(minimumRepeatGapMinutes >= 0)
    }
}

data class ManagedTask(
    val id: String,
    val title: String,
    val description: String = "",
    val category: String = "عمومی",
    val isActive: Boolean = true,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val lane: GameLane = GameLane.PERSONAL,
    val estimatedMinutes: Int = 5,
    val difficulty: TaskDifficulty = TaskDifficulty.NORMAL,
    val xpReward: Int = 10,
    val goldReward: Int = 5,
    val diamondReward: Int = 0,
    val maxOccurrencesPerSession: Int = 1,
    val schedule: TaskSchedule = TaskSchedule(),
    val sortOrder: Int = 0
) {
    init {
        require(id.isNotBlank())
        require(title.isNotBlank())
        require(estimatedMinutes > 0)
        require(xpReward >= 0)
        require(goldReward >= 0)
        require(diamondReward >= 0)
        require(maxOccurrencesPerSession > 0)
    }
}
