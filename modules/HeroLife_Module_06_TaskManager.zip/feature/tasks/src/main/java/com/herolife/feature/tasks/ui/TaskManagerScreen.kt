package com.herolife.feature.tasks.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifePrimaryButton
import com.herolife.feature.tasks.model.ManagedTask

@Composable
fun TaskManagerScreen(
    tasks: List<ManagedTask>,
    onAddTask: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "کارها",
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            text = "کارهای این بخش منبع Minionهای بازی هستند.",
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextSecondary
        )

        HeroLifePrimaryButton(
            text = "+ افزودن کار جدید",
            onClick = onAddTask,
            modifier = Modifier.fillMaxWidth()
        )

        if (tasks.isEmpty()) {
            HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "هنوز کاری ثبت نشده.",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "اولین کار را اضافه کن تا بعداً وارد Battle شود.",
                    color = HeroLifeColors.TextSecondary
                )
            }
        } else {
            tasks.sortedBy { it.sortOrder }.forEach { task ->
                TaskCard(task = task)
            }
        }
    }
}

@Composable
private fun TaskCard(task: ManagedTask) {
    HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = task.title,
            style = MaterialTheme.typography.titleLarge
        )

        if (task.description.isNotBlank()) {
            Text(
                text = task.description,
                style = MaterialTheme.typography.bodyMedium,
                color = HeroLifeColors.TextSecondary
            )
        }

        Text(
            text = "اولویت: ${task.priority.name} | مسیر: ${task.lane.name}",
            color = HeroLifeColors.Crystal
        )

        Text(
            text = "زمان: ${task.estimatedMinutes} دقیقه | XP: ${task.xpReward} | 🪙 ${task.goldReward}",
            color = HeroLifeColors.Gold
        )

        Text(
            text = if (task.isActive) "فعال" else "آرشیو شده",
            color = if (task.isActive) HeroLifeColors.Success else HeroLifeColors.TextSecondary
        )
    }
}
