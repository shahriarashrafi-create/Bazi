package com.herolife.feature.tasks.data

import com.herolife.feature.tasks.model.ManagedTask

class InMemoryTaskRepository(
    initial: List<ManagedTask> = emptyList()
) : TaskRepository {

    private val items = linkedMapOf<String, ManagedTask>().apply {
        initial.sortedBy { it.sortOrder }.forEach { put(it.id, it) }
    }

    override fun getAll(): List<ManagedTask> =
        items.values.sortedBy { it.sortOrder }

    override fun getActive(): List<ManagedTask> =
        getAll().filter { it.isActive }

    override fun findById(id: String): ManagedTask? = items[id]

    override fun upsert(task: ManagedTask) {
        items[task.id] = task
    }

    override fun archive(id: String) {
        val current = items[id] ?: return
        items[id] = current.copy(isActive = false)
    }

    override fun deletePermanently(id: String) {
        items.remove(id)
    }

    override fun reorder(taskIdsInOrder: List<String>) {
        taskIdsInOrder.forEachIndexed { index, id ->
            val current = items[id] ?: return@forEachIndexed
            items[id] = current.copy(sortOrder = index)
        }
    }
}
