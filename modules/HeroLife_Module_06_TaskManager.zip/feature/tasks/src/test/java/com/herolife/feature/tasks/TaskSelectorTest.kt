package com.herolife.feature.tasks

import com.herolife.core.model.GameLane
import com.herolife.core.model.TaskPriority
import com.herolife.feature.tasks.domain.TaskSelector
import com.herolife.feature.tasks.model.ManagedTask
import org.junit.Assert.assertEquals
import org.junit.Test

class TaskSelectorTest {

    @Test
    fun higherPriorityComesFirst() {
        val low = ManagedTask(
            id = "low",
            title = "Low",
            priority = TaskPriority.LOW,
            lane = GameLane.PERSONAL
        )

        val critical = ManagedTask(
            id = "critical",
            title = "Critical",
            priority = TaskPriority.CRITICAL,
            lane = GameLane.NETWORKING
        )

        val selected = TaskSelector.prioritizedForBattle(
            tasks = listOf(low, critical),
            limit = 2
        )

        assertEquals("critical", selected.first().id)
    }

    @Test
    fun inactiveTaskIsIgnored() {
        val task = ManagedTask(
            id = "archived",
            title = "Archived",
            isActive = false
        )

        val selected = TaskSelector.prioritizedForBattle(
            tasks = listOf(task),
            limit = 5
        )

        assertEquals(0, selected.size)
    }
}
