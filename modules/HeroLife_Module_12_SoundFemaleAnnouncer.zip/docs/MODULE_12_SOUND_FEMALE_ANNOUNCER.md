# Module 12/20 — Sound & Female Announcer

Independent module: `:feature:audio`

## Implemented architecture

- Separate audio buses:
  - Music
  - SFX
  - Announcer
- Independent volume controls
- Enable/disable each bus
- Music cues
- Battle ambience
- Low-time tension
- Victory / Defeat music contracts
- Footsteps
- Encounter SFX
- Task-completion SFX
- Attack / impact
- Minion death
- XP / Gold / Diamond cues
- Tower hit / destruction
- Player tower warning
- Female announcer cue system
- DOUBLE KILL
- TRIPLE KILL
- UNSTOPPABLE
- DOMINATING
- LEGENDARY
- Five-minute warning
- One-minute warning
- Priority-based announcer queue
- Priority-based SFX queue
- Android SoundPool engine
- Audio settings UI
- Announcer visual banner
- Unit tests

## Important asset note

This module does not bundle copyrighted audio, third-party game sounds, or generated voice files.

It provides a professional runtime architecture and resource registry.
Real female-announcer recordings can later be placed under `res/raw`
and registered without changing gameplay code.

## Sound design target

The intended final sound identity is:
- deep cinematic battle ambience
- clear but restrained UI clicks
- realistic footsteps
- stronger low-frequency tower impacts
- distinct crystal sound for Diamond
- energetic female Persian announcer
- rising tension during the final minutes
- powerful but short Victory / Defeat themes

## Next

Module 13 — Rewards Economy & Balance
will formalize:
- XP progression
- Gold economy
- Diamond rarity
- anti-inflation rules
- reward caps
- streak rewards
- achievement rewards
- balance profiles
