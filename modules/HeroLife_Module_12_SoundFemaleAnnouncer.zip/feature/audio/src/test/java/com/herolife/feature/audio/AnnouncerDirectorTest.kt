package com.herolife.feature.audio

import com.herolife.feature.audio.domain.AnnouncerDirector
import com.herolife.feature.audio.model.AnnouncerCue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnouncerDirectorTest {

    @Test
    fun twoKillsProducesDoubleKill() {
        val line = AnnouncerDirector.fromKillCount(2)

        assertEquals(
            AnnouncerCue.DOUBLE_KILL,
            line?.cue
        )
    }

    @Test
    fun eightKillsProducesLegendary() {
        val line = AnnouncerDirector.fromKillCount(8)

        assertEquals(
            AnnouncerCue.LEGENDARY,
            line?.cue
        )
    }

    @Test
    fun oneKillProducesNoAnnouncement() {
        assertNull(
            AnnouncerDirector.fromKillCount(1)
        )
    }

    @Test
    fun oneMinuteWarningExists() {
        val line = AnnouncerDirector.forRemainingMillis(
            60_000L
        )

        assertEquals(
            AnnouncerCue.ONE_MINUTE_LEFT,
            line?.cue
        )
    }

    @Test
    fun legendaryHasHigherPriorityThanDoubleKill() {
        val legendary =
            AnnouncerDirector.fromKillCount(8)

        val double =
            AnnouncerDirector.fromKillCount(2)

        assertTrue(
            legendary!!.priority >
                double!!.priority
        )
    }
}
