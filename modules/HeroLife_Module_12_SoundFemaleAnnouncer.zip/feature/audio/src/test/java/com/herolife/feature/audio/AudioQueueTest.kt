package com.herolife.feature.audio

import com.herolife.feature.audio.domain.AudioDirector
import com.herolife.feature.audio.domain.AudioQueue
import com.herolife.feature.audio.domain.AudioQueueState
import com.herolife.feature.audio.model.MusicCue
import com.herolife.feature.audio.model.SfxCue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class AudioQueueTest {

    @Test
    fun higherPriorityMusicReplacesLowerPriorityMusic() {
        var state = AudioQueueState()

        state = AudioQueue.submit(
            state,
            AudioDirector.music(
                MusicCue.BATTLE_AMBIENCE
            )
        )

        state = AudioQueue.submit(
            state,
            AudioDirector.music(
                cue = MusicCue.VICTORY_THEME,
                loop = false
            )
        )

        assertEquals(
            MusicCue.VICTORY_THEME.name,
            state.music?.cueName
        )
    }

    @Test
    fun sfxQueueReturnsHighestPriorityFirst() {
        var state = AudioQueueState()

        state = AudioQueue.submit(
            state,
            AudioDirector.sfx(
                SfxCue.FOOTSTEP
            )
        )

        state = AudioQueue.submit(
            state,
            AudioDirector.sfx(
                SfxCue.TOWER_DESTROYED
            )
        )

        val result = AudioQueue.consumeSfx(state)

        assertNotNull(result.second)
        assertEquals(
            SfxCue.TOWER_DESTROYED.name,
            result.second?.cueName
        )
    }
}
