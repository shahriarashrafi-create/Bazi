package com.herolife.feature.audio.domain

import com.herolife.feature.audio.model.AudioBus
import com.herolife.feature.audio.model.AudioEvent

data class AudioQueueState(
    val music: AudioEvent? = null,
    val sfx: List<AudioEvent> = emptyList(),
    val announcer: AudioEvent? = null
)

object AudioQueue {

    fun submit(
        state: AudioQueueState,
        event: AudioEvent
    ): AudioQueueState =
        when (event.bus) {
            AudioBus.MUSIC -> {
                if (
                    state.music == null ||
                    event.priority >= state.music.priority
                ) {
                    state.copy(music = event)
                } else {
                    state
                }
            }

            AudioBus.SFX -> {
                state.copy(
                    sfx = (state.sfx + event)
                        .sortedByDescending { it.priority }
                        .take(8)
                )
            }

            AudioBus.ANNOUNCER -> {
                if (
                    state.announcer == null ||
                    event.priority >= state.announcer.priority
                ) {
                    state.copy(announcer = event)
                } else {
                    state
                }
            }
        }

    fun consumeSfx(
        state: AudioQueueState
    ): Pair<AudioQueueState, AudioEvent?> {
        val next = state.sfx.firstOrNull()

        return if (next == null) {
            state to null
        } else {
            state.copy(
                sfx = state.sfx.drop(1)
            ) to next
        }
    }

    fun clearAnnouncer(
        state: AudioQueueState
    ): AudioQueueState =
        state.copy(announcer = null)
}
