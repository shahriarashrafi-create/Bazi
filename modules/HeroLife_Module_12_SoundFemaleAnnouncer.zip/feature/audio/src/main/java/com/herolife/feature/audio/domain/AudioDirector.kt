package com.herolife.feature.audio.domain

import com.herolife.feature.audio.model.AnnouncerLine
import com.herolife.feature.audio.model.AudioBus
import com.herolife.feature.audio.model.AudioEvent
import com.herolife.feature.audio.model.MusicCue
import com.herolife.feature.audio.model.SfxCue
import com.herolife.feature.vfx.model.VfxKind

/**
 * Converts gameplay and VFX events into audio intents.
 *
 * This layer contains zero Android audio APIs.
 * That keeps it deterministic and testable.
 */
object AudioDirector {

    fun music(
        cue: MusicCue,
        loop: Boolean = true
    ): AudioEvent =
        AudioEvent(
            bus = AudioBus.MUSIC,
            cueName = cue.name,
            priority = when (cue) {
                MusicCue.HOME_AMBIENCE -> 10
                MusicCue.BATTLE_AMBIENCE -> 20
                MusicCue.LOW_TIME_TENSION -> 40
                MusicCue.VICTORY_THEME -> 100
                MusicCue.DEFEAT_THEME -> 100
            },
            loop = loop,
            fadeInMillis = 500L,
            fadeOutMillis = 450L
        )

    fun sfx(
        cue: SfxCue
    ): AudioEvent =
        AudioEvent(
            bus = AudioBus.SFX,
            cueName = cue.name,
            priority = sfxPriority(cue),
            loop = cue == SfxCue.FOOTSTEP
        )

    fun announcer(
        line: AnnouncerLine
    ): AudioEvent =
        AudioEvent(
            bus = AudioBus.ANNOUNCER,
            cueName = line.cue.name,
            priority = line.priority,
            loop = false,
            fadeInMillis = 30L,
            fadeOutMillis = 80L
        )

    fun fromVfxKind(
        kind: VfxKind
    ): List<AudioEvent> =
        when (kind) {
            VfxKind.HERO_ATTACK -> listOf(
                sfx(SfxCue.HERO_ATTACK)
            )

            VfxKind.MINION_HIT -> listOf(
                sfx(SfxCue.HIT_IMPACT)
            )

            VfxKind.MINION_DEFEATED -> listOf(
                sfx(SfxCue.MINION_DEFEATED)
            )

            VfxKind.TOWER_HIT -> listOf(
                sfx(SfxCue.TOWER_HIT)
            )

            VfxKind.TOWER_DESTROYED -> listOf(
                sfx(SfxCue.TOWER_DESTROYED)
            )

            VfxKind.CORE_HIT -> listOf(
                sfx(SfxCue.HIT_IMPACT)
            )

            VfxKind.XP_GAIN -> listOf(
                sfx(SfxCue.XP_GAIN)
            )

            VfxKind.GOLD_GAIN -> listOf(
                sfx(SfxCue.GOLD_GAIN)
            )

            VfxKind.DIAMOND_GAIN -> listOf(
                sfx(SfxCue.DIAMOND_GAIN)
            )

            VfxKind.VICTORY_BURST -> listOf(
                music(
                    cue = MusicCue.VICTORY_THEME,
                    loop = false
                )
            )

            VfxKind.DEFEAT_PULSE -> listOf(
                music(
                    cue = MusicCue.DEFEAT_THEME,
                    loop = false
                )
            )
        }

    private fun sfxPriority(
        cue: SfxCue
    ): Int =
        when (cue) {
            SfxCue.FOOTSTEP -> 5
            SfxCue.UI_TAP -> 10
            SfxCue.UI_PANEL_OPEN -> 15
            SfxCue.MINION_ENCOUNTER -> 20
            SfxCue.TASK_COMPLETE -> 50
            SfxCue.HERO_ATTACK -> 30
            SfxCue.HIT_IMPACT -> 35
            SfxCue.MINION_DEFEATED -> 55
            SfxCue.XP_GAIN -> 25
            SfxCue.GOLD_GAIN -> 25
            SfxCue.DIAMOND_GAIN -> 90
            SfxCue.TOWER_HIT -> 50
            SfxCue.TOWER_DESTROYED -> 85
            SfxCue.PLAYER_TOWER_WARNING -> 95
            SfxCue.MATCH_START -> 70
            SfxCue.MATCH_END -> 70
        }
}
