package com.herolife.feature.audio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeSectionHeader
import com.herolife.feature.audio.model.AudioSettings

@Composable
fun AudioSettingsPanel(
    settings: AudioSettings,
    onSettingsChanged: (AudioSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        HeroLifeSectionHeader(
            title = "صدا",
            subtitle = "موسیقی، افکت‌ها و Announcer"
        )

        AudioToggleRow(
            label = "موسیقی",
            enabled = settings.musicEnabled,
            onEnabledChanged = {
                onSettingsChanged(
                    settings.copy(
                        musicEnabled = it
                    )
                )
            }
        )

        Slider(
            value = settings.musicVolume,
            onValueChange = {
                onSettingsChanged(
                    settings.copy(
                        musicVolume = it
                    )
                )
            },
            enabled = settings.musicEnabled
        )

        AudioToggleRow(
            label = "افکت‌های صوتی",
            enabled = settings.sfxEnabled,
            onEnabledChanged = {
                onSettingsChanged(
                    settings.copy(
                        sfxEnabled = it
                    )
                )
            }
        )

        Slider(
            value = settings.sfxVolume,
            onValueChange = {
                onSettingsChanged(
                    settings.copy(
                        sfxVolume = it
                    )
                )
            },
            enabled = settings.sfxEnabled
        )

        AudioToggleRow(
            label = "صدای Announcer",
            enabled = settings.announcerEnabled,
            onEnabledChanged = {
                onSettingsChanged(
                    settings.copy(
                        announcerEnabled = it
                    )
                )
            }
        )

        Slider(
            value = settings.announcerVolume,
            onValueChange = {
                onSettingsChanged(
                    settings.copy(
                        announcerVolume = it
                    )
                )
            },
            enabled = settings.announcerEnabled
        )

        Text(
            text = "صدای زن حرفه‌ای در مرحله Asset Integration به فایل‌های صوتی واقعی متصل می‌شود.",
            style = MaterialTheme.typography.bodySmall,
            color = HeroLifeColors.TextMuted
        )
    }
}

@Composable
private fun AudioToggleRow(
    label: String,
    enabled: Boolean,
    onEnabledChanged: (Boolean) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium
        )

        Switch(
            checked = enabled,
            onCheckedChange = onEnabledChanged
        )
    }
}
