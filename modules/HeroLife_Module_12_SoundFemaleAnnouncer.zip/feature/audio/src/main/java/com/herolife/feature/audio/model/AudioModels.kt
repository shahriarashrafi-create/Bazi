package com.herolife.feature.audio.model

enum class AudioBus {
    MUSIC,
    SFX,
    ANNOUNCER
}

enum class MusicCue {
    HOME_AMBIENCE,
    BATTLE_AMBIENCE,
    LOW_TIME_TENSION,
    VICTORY_THEME,
    DEFEAT_THEME
}

enum class SfxCue {
    UI_TAP,
    UI_PANEL_OPEN,
    FOOTSTEP,
    MINION_ENCOUNTER,
    TASK_COMPLETE,
    HERO_ATTACK,
    HIT_IMPACT,
    MINION_DEFEATED,
    XP_GAIN,
    GOLD_GAIN,
    DIAMOND_GAIN,
    TOWER_HIT,
    TOWER_DESTROYED,
    PLAYER_TOWER_WARNING,
    MATCH_START,
    MATCH_END
}

enum class AnnouncerCue(
    val englishTitle: String,
    val persianSubtitle: String
) {
    DOUBLE_KILL(
        englishTitle = "DOUBLE KILL",
        persianSubtitle = "دو مانع پشت سر هم کنار رفت."
    ),
    TRIPLE_KILL(
        englishTitle = "TRIPLE KILL",
        persianSubtitle = "ریتمت را حفظ کن."
    ),
    UNSTOPPABLE(
        englishTitle = "UNSTOPPABLE",
        persianSubtitle = "هیچ چیز جلوی حرکتت را نمی‌گیرد."
    ),
    DOMINATING(
        englishTitle = "DOMINATING",
        persianSubtitle = "میدان در اختیار توست."
    ),
    LEGENDARY(
        englishTitle = "LEGENDARY",
        persianSubtitle = "امروز داری افسانه می‌سازی."
    ),
    VICTORY(
        englishTitle = "VICTORY",
        persianSubtitle = "این میدان را بردی."
    ),
    DEFEAT(
        englishTitle = "DEFEAT",
        persianSubtitle = "نبرد بعدی را قوی‌تر شروع کن."
    ),
    FIVE_MINUTES_LEFT(
        englishTitle = "FIVE MINUTES",
        persianSubtitle = "پنج دقیقه تا پایان نبرد باقی مانده."
    ),
    ONE_MINUTE_LEFT(
        englishTitle = "ONE MINUTE",
        persianSubtitle = "یک دقیقه تا پایان نبرد."
    )
}

data class AudioSettings(
    val musicEnabled: Boolean = true,
    val sfxEnabled: Boolean = true,
    val announcerEnabled: Boolean = true,
    val musicVolume: Float = 0.72f,
    val sfxVolume: Float = 0.88f,
    val announcerVolume: Float = 1.0f
) {
    init {
        require(musicVolume in 0f..1f)
        require(sfxVolume in 0f..1f)
        require(announcerVolume in 0f..1f)
    }

    fun volumeFor(bus: AudioBus): Float =
        when (bus) {
            AudioBus.MUSIC -> if (musicEnabled) musicVolume else 0f
            AudioBus.SFX -> if (sfxEnabled) sfxVolume else 0f
            AudioBus.ANNOUNCER -> if (announcerEnabled) announcerVolume else 0f
        }
}

data class AudioEvent(
    val bus: AudioBus,
    val cueName: String,
    val priority: Int = 0,
    val loop: Boolean = false,
    val fadeInMillis: Long = 0L,
    val fadeOutMillis: Long = 0L
) {
    init {
        require(cueName.isNotBlank())
        require(priority >= 0)
        require(fadeInMillis >= 0)
        require(fadeOutMillis >= 0)
    }
}

data class AnnouncerLine(
    val cue: AnnouncerCue,
    val title: String,
    val subtitle: String,
    val priority: Int
)
