package com.herolife.feature.audio.domain

import com.herolife.feature.audio.model.AnnouncerCue
import com.herolife.feature.audio.model.AnnouncerLine

object AnnouncerDirector {

    fun fromKillCount(
        consecutiveKills: Int
    ): AnnouncerLine? =
        when {
            consecutiveKills >= 8 -> line(
                AnnouncerCue.LEGENDARY,
                priority = 100
            )

            consecutiveKills >= 6 -> line(
                AnnouncerCue.DOMINATING,
                priority = 90
            )

            consecutiveKills >= 4 -> line(
                AnnouncerCue.UNSTOPPABLE,
                priority = 80
            )

            consecutiveKills == 3 -> line(
                AnnouncerCue.TRIPLE_KILL,
                priority = 70
            )

            consecutiveKills == 2 -> line(
                AnnouncerCue.DOUBLE_KILL,
                priority = 60
            )

            else -> null
        }

    fun forVictory(): AnnouncerLine =
        line(
            AnnouncerCue.VICTORY,
            priority = 120
        )

    fun forDefeat(): AnnouncerLine =
        line(
            AnnouncerCue.DEFEAT,
            priority = 120
        )

    fun forRemainingMillis(
        remainingMillis: Long
    ): AnnouncerLine? =
        when {
            remainingMillis in 59_000L..61_000L -> line(
                AnnouncerCue.ONE_MINUTE_LEFT,
                priority = 95
            )

            remainingMillis in 299_000L..301_000L -> line(
                AnnouncerCue.FIVE_MINUTES_LEFT,
                priority = 85
            )

            else -> null
        }

    private fun line(
        cue: AnnouncerCue,
        priority: Int
    ): AnnouncerLine =
        AnnouncerLine(
            cue = cue,
            title = cue.englishTitle,
            subtitle = cue.persianSubtitle,
            priority = priority
        )
}
