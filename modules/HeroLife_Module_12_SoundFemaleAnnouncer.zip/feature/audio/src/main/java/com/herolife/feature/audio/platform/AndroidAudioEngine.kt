package com.herolife.feature.audio.platform

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.herolife.feature.audio.model.AudioBus
import com.herolife.feature.audio.model.AudioEvent
import com.herolife.feature.audio.model.AudioSettings

/**
 * Android runtime audio engine.
 *
 * This module intentionally does not bundle copyrighted or generated voice/audio assets.
 * Real files can be added later under res/raw and registered through `registerSound`.
 */
class AndroidAudioEngine(
    context: Context,
    private var settings: AudioSettings = AudioSettings()
) {
    private val appContext = context.applicationContext

    private val soundPool: SoundPool =
        SoundPool.Builder()
            .setMaxStreams(12)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()

    private val soundIds = mutableMapOf<String, Int>()

    fun registerSound(
        cueName: String,
        rawResourceId: Int
    ) {
        require(cueName.isNotBlank())
        require(rawResourceId != 0)

        val soundId = soundPool.load(
            appContext,
            rawResourceId,
            1
        )

        soundIds[cueName] = soundId
    }

    fun updateSettings(
        newSettings: AudioSettings
    ) {
        settings = newSettings
    }

    fun play(
        event: AudioEvent
    ): Boolean {
        val soundId = soundIds[event.cueName]
            ?: return false

        val volume = settings.volumeFor(event.bus)

        if (volume <= 0f) {
            return false
        }

        soundPool.play(
            soundId,
            volume,
            volume,
            event.priority.coerceIn(0, 100),
            if (event.loop) -1 else 0,
            1.0f
        )

        return true
    }

    fun release() {
        soundPool.release()
        soundIds.clear()
    }
}
