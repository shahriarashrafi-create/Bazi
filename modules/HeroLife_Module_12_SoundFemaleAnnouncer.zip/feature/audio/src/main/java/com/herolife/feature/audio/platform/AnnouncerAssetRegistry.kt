package com.herolife.feature.audio.platform

import com.herolife.feature.audio.model.AnnouncerCue

/**
 * Registry contract for future professionally-recorded female announcer assets.
 *
 * Values are Android raw resource IDs.
 * Zero means "asset not registered yet".
 */
data class AnnouncerAssetRegistry(
    val assets: Map<AnnouncerCue, Int> = emptyMap()
) {
    fun rawResourceFor(
        cue: AnnouncerCue
    ): Int =
        assets[cue] ?: 0

    fun hasAsset(
        cue: AnnouncerCue
    ): Boolean =
        rawResourceFor(cue) != 0
}
