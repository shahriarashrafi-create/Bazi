# Module 17/20 — Events

Independent module: `:feature:events`

Implemented:
- Event CRUD contract
- Archive / delete
- Event title / description / location
- Start / end dates
- Leader
- Event Director
- Goal value / current value
- Priority and status
- Progress states:
  - Reached
  - Should Reach
  - Close to Reaching
  - Behind
- Progress projection
- Remaining target
- Milestones
- Event leaders and responsibility
- Leader ranking
- Event Director summary
- Events analytics overview
- Event card UI
- Event Director dashboard UI
- Overview UI
- Pure Kotlin engines and tests

Next: Module 18 — Time Sheet.
