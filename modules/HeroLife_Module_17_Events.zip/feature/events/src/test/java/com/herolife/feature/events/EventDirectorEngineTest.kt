package com.herolife.feature.events

import com.herolife.feature.events.domain.EventDirectorEngine
import com.herolife.feature.events.domain.InMemoryEventRepository
import com.herolife.feature.events.model.EventLeader
import com.herolife.feature.events.model.EventMilestone
import com.herolife.feature.events.model.EventStatus
import com.herolife.feature.events.model.TeamEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class EventDirectorEngineTest {

    @Test
    fun buildsDirectorSummary() {
        val repo = InMemoryEventRepository()
        val engine = EventDirectorEngine(repo)

        repo.saveEvent(
            TeamEvent(
                id = "e1",
                title = "Event",
                startAtMillis = 0L,
                endAtMillis = 1000L,
                goalValue = 100,
                currentValue = 50,
                status = EventStatus.ACTIVE,
                createdAtMillis = 0L,
                updatedAtMillis = 0L
            )
        )

        repo.saveMilestone(
            EventMilestone(
                id = "m1",
                eventId = "e1",
                title = "Half",
                targetValue = 50,
                reachedValue = 50,
                dueAtMillis = 500L
            )
        )

        repo.saveLeader(
            EventLeader(
                id = "l1",
                eventId = "e1",
                fullName = "Leader",
                responsibility = "Branch",
                targetValue = 30,
                currentValue = 20
            )
        )

        val summary = engine.summary(
            "e1",
            500L
        )

        assertNotNull(summary)
        assertEquals(1, summary!!.completedMilestones)
        assertEquals(50L, summary.remainingValue)
    }
}
