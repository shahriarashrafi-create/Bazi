package com.herolife.feature.events

import com.herolife.feature.events.domain.EventAnalytics
import com.herolife.feature.events.model.EventStatus
import com.herolife.feature.events.model.TeamEvent
import org.junit.Assert.assertEquals
import org.junit.Test

class EventAnalyticsTest {

    @Test
    fun countsActiveAndReached() {
        val events = listOf(
            TeamEvent(
                id = "1",
                title = "A",
                startAtMillis = 0,
                endAtMillis = 1000,
                goalValue = 100,
                currentValue = 100,
                status = EventStatus.ACTIVE,
                createdAtMillis = 0,
                updatedAtMillis = 0
            )
        )

        val snapshot =
            EventAnalytics.snapshot(
                events,
                500
            )

        assertEquals(1, snapshot.activeEvents)
        assertEquals(1, snapshot.reachedGoals)
    }
}
