package com.herolife.feature.events

import com.herolife.feature.events.domain.EventProgressEngine
import com.herolife.feature.events.model.EventProgressState
import com.herolife.feature.events.model.EventStatus
import com.herolife.feature.events.model.TeamEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EventProgressEngineTest {

    private fun event(
        current: Long,
        goal: Long = 100L
    ) = TeamEvent(
        id = "e1",
        title = "Event",
        startAtMillis = 0L,
        endAtMillis = 1000L,
        goalValue = goal,
        currentValue = current,
        status = EventStatus.ACTIVE,
        createdAtMillis = 0L,
        updatedAtMillis = 0L
    )

    @Test
    fun reachedWhenGoalCompleted() {
        val state =
            EventProgressEngine.classify(
                event(100),
                500L
            )

        assertEquals(
            EventProgressState.REACHED,
            state
        )
    }

    @Test
    fun projectionNeverDropsBelowCurrent() {
        val projected =
            EventProgressEngine.projectedValueAtEnd(
                event(40),
                500L
            )

        assertTrue(projected >= 40L)
    }
}
