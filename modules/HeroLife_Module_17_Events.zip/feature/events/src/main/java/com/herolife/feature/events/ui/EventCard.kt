package com.herolife.feature.events.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.events.domain.EventProgressEngine
import com.herolife.feature.events.model.EventProgressState
import com.herolife.feature.events.model.TeamEvent

@Composable
fun EventCard(
    event: TeamEvent,
    nowMillis: Long,
    modifier: Modifier = Modifier
) {
    val state =
        EventProgressEngine.classify(
            event = event,
            nowMillis = nowMillis
        )

    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = HeroLifeColors.TextPrimary
                )

                if (event.location.isNotBlank()) {
                    Text(
                        text = event.location,
                        style = MaterialTheme.typography.bodySmall,
                        color = HeroLifeColors.TextSecondary
                    )
                }
            }

            Text(
                text = progressLabel(state),
                color = progressColor(state)
            )
        }

        LinearProgressIndicator(
            progress = {
                event.progressFraction.coerceIn(0f, 1f)
            },
            modifier = Modifier.fillMaxWidth(),
            color = progressColor(state),
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Text(
            text = "${event.currentValue} / ${event.goalValue}",
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.Crystal
        )

        if (event.leaderName.isNotBlank()) {
            Text(
                text = "رهبر: ${event.leaderName}",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.TextMuted
            )
        }

        if (event.directorName.isNotBlank()) {
            Text(
                text = "Event Director: ${event.directorName}",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.Gold
            )
        }
    }
}

private fun progressLabel(
    state: EventProgressState
): String =
    when (state) {
        EventProgressState.REACHED -> "رسیده"
        EventProgressState.SHOULD_REACH -> "باید برسد"
        EventProgressState.CLOSE_TO_REACHING -> "نزدیک رسیدن"
        EventProgressState.BEHIND -> "عقب‌تر از برنامه"
    }

private fun progressColor(
    state: EventProgressState
) =
    when (state) {
        EventProgressState.REACHED -> HeroLifeColors.Success
        EventProgressState.SHOULD_REACH -> HeroLifeColors.Crystal
        EventProgressState.CLOSE_TO_REACHING -> HeroLifeColors.Gold
        EventProgressState.BEHIND -> HeroLifeColors.Warning
    }
