package com.herolife.feature.events.domain

import com.herolife.feature.events.model.EventLeader
import com.herolife.feature.events.model.EventMilestone
import com.herolife.feature.events.model.TeamEvent

class InMemoryEventRepository : EventRepository {

    private val eventMap = linkedMapOf<String, TeamEvent>()
    private val milestoneMap = linkedMapOf<String, EventMilestone>()
    private val leaderMap = linkedMapOf<String, EventLeader>()

    override fun events(): List<TeamEvent> =
        eventMap.values.toList()

    override fun eventById(id: String): TeamEvent? =
        eventMap[id]

    override fun saveEvent(event: TeamEvent) {
        eventMap[event.id] = event
    }

    override fun archiveEvent(id: String) {
        val current = eventMap[id] ?: return
        eventMap[id] = current.copy(archived = true)
    }

    override fun deleteEvent(id: String) {
        eventMap.remove(id)
        milestoneMap.entries.removeAll { it.value.eventId == id }
        leaderMap.entries.removeAll { it.value.eventId == id }
    }

    override fun milestones(eventId: String): List<EventMilestone> =
        milestoneMap.values.filter { it.eventId == eventId }

    override fun saveMilestone(milestone: EventMilestone) {
        milestoneMap[milestone.id] = milestone
    }

    override fun deleteMilestone(id: String) {
        milestoneMap.remove(id)
    }

    override fun leaders(eventId: String): List<EventLeader> =
        leaderMap.values.filter { it.eventId == eventId }

    override fun saveLeader(leader: EventLeader) {
        leaderMap[leader.id] = leader
    }

    override fun deleteLeader(id: String) {
        leaderMap.remove(id)
    }
}
