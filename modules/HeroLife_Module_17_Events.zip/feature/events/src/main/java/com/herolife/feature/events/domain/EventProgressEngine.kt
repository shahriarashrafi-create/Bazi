package com.herolife.feature.events.domain

import com.herolife.feature.events.model.EventProgressState
import com.herolife.feature.events.model.TeamEvent

object EventProgressEngine {

    fun classify(
        event: TeamEvent,
        nowMillis: Long
    ): EventProgressState {
        if (event.currentValue >= event.goalValue) {
            return EventProgressState.REACHED
        }

        val totalDuration =
            ((event.endAtMillis ?: event.startAtMillis) - event.startAtMillis)
                .coerceAtLeast(1L)

        val elapsed =
            (nowMillis - event.startAtMillis)
                .coerceIn(0L, totalDuration)

        val timeProgress =
            elapsed.toDouble() / totalDuration.toDouble()

        val valueProgress =
            event.currentValue.toDouble() / event.goalValue.toDouble()

        val gap = valueProgress - timeProgress

        return when {
            valueProgress >= 0.85 ->
                EventProgressState.CLOSE_TO_REACHING

            gap >= -0.05 ->
                EventProgressState.SHOULD_REACH

            gap >= -0.18 ->
                EventProgressState.CLOSE_TO_REACHING

            else ->
                EventProgressState.BEHIND
        }
    }

    fun projectedValueAtEnd(
        event: TeamEvent,
        nowMillis: Long
    ): Long {
        val end = event.endAtMillis ?: return event.currentValue

        val elapsed =
            (nowMillis - event.startAtMillis)
                .coerceAtLeast(1L)

        val total =
            (end - event.startAtMillis)
                .coerceAtLeast(1L)

        if (nowMillis <= event.startAtMillis) {
            return event.currentValue
        }

        val rate =
            event.currentValue.toDouble() /
                elapsed.toDouble()

        return (rate * total.toDouble())
            .toLong()
            .coerceAtLeast(event.currentValue)
    }
}
