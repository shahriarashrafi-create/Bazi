package com.herolife.feature.events.model

enum class EventStatus {
    PLANNED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}

enum class EventProgressState {
    REACHED,
    SHOULD_REACH,
    CLOSE_TO_REACHING,
    BEHIND
}

enum class EventPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class TeamEvent(
    val id: String,
    val title: String,
    val description: String = "",
    val location: String = "",
    val startAtMillis: Long,
    val endAtMillis: Long?,
    val leaderName: String = "",
    val directorName: String = "",
    val goalValue: Long,
    val currentValue: Long = 0L,
    val priority: EventPriority = EventPriority.MEDIUM,
    val status: EventStatus = EventStatus.PLANNED,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val archived: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(title.isNotBlank())
        require(startAtMillis >= 0L)
        require(endAtMillis == null || endAtMillis >= startAtMillis)
        require(goalValue > 0L)
        require(currentValue >= 0L)
        require(createdAtMillis >= 0L)
        require(updatedAtMillis >= 0L)
    }

    val progressFraction: Float
        get() = (
            currentValue.toDouble() /
                goalValue.toDouble()
            )
            .toFloat()
            .coerceIn(0f, 1.5f)
}

data class EventMilestone(
    val id: String,
    val eventId: String,
    val title: String,
    val targetValue: Long,
    val reachedValue: Long = 0L,
    val dueAtMillis: Long?,
    val completed: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(eventId.isNotBlank())
        require(title.isNotBlank())
        require(targetValue > 0L)
        require(reachedValue >= 0L)
        require(dueAtMillis == null || dueAtMillis >= 0L)
    }
}

data class EventLeader(
    val id: String,
    val eventId: String,
    val fullName: String,
    val responsibility: String,
    val targetValue: Long = 0L,
    val currentValue: Long = 0L
) {
    init {
        require(id.isNotBlank())
        require(eventId.isNotBlank())
        require(fullName.isNotBlank())
        require(responsibility.isNotBlank())
        require(targetValue >= 0L)
        require(currentValue >= 0L)
    }
}

data class EventSnapshot(
    val event: TeamEvent,
    val milestones: List<EventMilestone>,
    val leaders: List<EventLeader>
)
