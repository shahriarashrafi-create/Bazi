package com.herolife.feature.events.domain

import com.herolife.feature.events.model.EventLeader
import com.herolife.feature.events.model.EventMilestone
import com.herolife.feature.events.model.TeamEvent

interface EventRepository {
    fun events(): List<TeamEvent>
    fun eventById(id: String): TeamEvent?
    fun saveEvent(event: TeamEvent)
    fun archiveEvent(id: String)
    fun deleteEvent(id: String)

    fun milestones(eventId: String): List<EventMilestone>
    fun saveMilestone(milestone: EventMilestone)
    fun deleteMilestone(id: String)

    fun leaders(eventId: String): List<EventLeader>
    fun saveLeader(leader: EventLeader)
    fun deleteLeader(id: String)
}
