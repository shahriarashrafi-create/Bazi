package com.herolife.feature.events.domain

import com.herolife.feature.events.model.EventLeader
import com.herolife.feature.events.model.EventMilestone
import com.herolife.feature.events.model.EventProgressState
import com.herolife.feature.events.model.EventSnapshot
import com.herolife.feature.events.model.TeamEvent

data class EventDirectorSummary(
    val progressState: EventProgressState,
    val projectedValue: Long,
    val remainingValue: Long,
    val completedMilestones: Int,
    val totalMilestones: Int,
    val topLeaders: List<EventLeader>
)

class EventDirectorEngine(
    private val repository: EventRepository
) {

    fun snapshot(eventId: String): EventSnapshot? {
        val event = repository.eventById(eventId) ?: return null
        return EventSnapshot(
            event = event,
            milestones = repository.milestones(eventId),
            leaders = repository.leaders(eventId)
        )
    }

    fun summary(
        eventId: String,
        nowMillis: Long
    ): EventDirectorSummary? {
        val snapshot = snapshot(eventId) ?: return null

        return EventDirectorSummary(
            progressState = EventProgressEngine.classify(
                snapshot.event,
                nowMillis
            ),
            projectedValue = EventProgressEngine.projectedValueAtEnd(
                snapshot.event,
                nowMillis
            ),
            remainingValue = (
                snapshot.event.goalValue -
                    snapshot.event.currentValue
                ).coerceAtLeast(0L),
            completedMilestones = snapshot.milestones.count {
                it.completed || it.reachedValue >= it.targetValue
            },
            totalMilestones = snapshot.milestones.size,
            topLeaders = snapshot.leaders
                .sortedWith(
                    compareByDescending<EventLeader> {
                        ratio(it)
                    }.thenByDescending {
                        it.currentValue
                    }
                )
                .take(5)
        )
    }

    fun addProgress(
        eventId: String,
        delta: Long,
        nowMillis: Long
    ) {
        require(delta >= 0L)

        val current =
            repository.eventById(eventId)
                ?: return

        repository.saveEvent(
            current.copy(
                currentValue = current.currentValue + delta,
                updatedAtMillis = nowMillis
            )
        )
    }

    fun saveMilestone(
        milestone: EventMilestone
    ) {
        repository.saveMilestone(milestone)
    }

    fun saveLeader(
        leader: EventLeader
    ) {
        repository.saveLeader(leader)
    }

    private fun ratio(
        leader: EventLeader
    ): Double =
        if (leader.targetValue <= 0L) {
            leader.currentValue.toDouble()
        } else {
            leader.currentValue.toDouble() /
                leader.targetValue.toDouble()
        }
}
