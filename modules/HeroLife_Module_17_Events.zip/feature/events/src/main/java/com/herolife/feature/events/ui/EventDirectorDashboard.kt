package com.herolife.feature.events.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.feature.events.domain.EventDirectorSummary

@Composable
fun EventDirectorDashboard(
    summary: EventDirectorSummary,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "Event Director",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                label = "پیش‌بینی پایان",
                value = summary.projectedValue.toString(),
                accent = HeroLifeColors.Crystal,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "باقی‌مانده",
                value = summary.remainingValue.toString(),
                accent = HeroLifeColors.Warning,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "Milestone",
                value = "${summary.completedMilestones}/${summary.totalMilestones}",
                accent = HeroLifeColors.Gold,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (summary.topLeaders.isNotEmpty()) {
            Text(
                text = "رهبران برتر",
                style = MaterialTheme.typography.titleMedium,
                color = HeroLifeColors.TextPrimary
            )

            summary.topLeaders.forEachIndexed { index, leader ->
                Text(
                    text = "${index + 1}. ${leader.fullName} • ${leader.currentValue}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = HeroLifeColors.TextSecondary
                )
            }
        }
    }
}
