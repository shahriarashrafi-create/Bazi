package com.herolife.feature.events.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.feature.events.domain.EventsAnalyticsSnapshot

@Composable
fun EventsOverview(
    snapshot: EventsAnalyticsSnapshot,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "رویدادها",
            style = MaterialTheme.typography.headlineMedium,
            color = HeroLifeColors.GoldBright
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                "فعال",
                snapshot.activeEvents.toString(),
                HeroLifeColors.Crystal,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "رسیده",
                snapshot.reachedGoals.toString(),
                HeroLifeColors.Success,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "باید برسد",
                snapshot.shouldReach.toString(),
                HeroLifeColors.CrystalBright,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "نزدیک رسیدن",
                snapshot.closeToReaching.toString(),
                HeroLifeColors.Gold,
                Modifier.fillMaxWidth()
            )
            HeroLifeStatChip(
                "نیازمند توجه",
                snapshot.behind.toString(),
                HeroLifeColors.Warning,
                Modifier.fillMaxWidth()
            )
        }
    }
}
