package com.herolife.feature.events.domain

import com.herolife.feature.events.model.EventProgressState
import com.herolife.feature.events.model.EventStatus
import com.herolife.feature.events.model.TeamEvent

data class EventsAnalyticsSnapshot(
    val totalEvents: Int,
    val activeEvents: Int,
    val reachedGoals: Int,
    val shouldReach: Int,
    val closeToReaching: Int,
    val behind: Int
)

object EventAnalytics {

    fun snapshot(
        events: List<TeamEvent>,
        nowMillis: Long
    ): EventsAnalyticsSnapshot {
        val active =
            events.filter {
                !it.archived &&
                    it.status != EventStatus.CANCELLED
            }

        val states =
            active.map {
                EventProgressEngine.classify(
                    event = it,
                    nowMillis = nowMillis
                )
            }

        return EventsAnalyticsSnapshot(
            totalEvents = active.size,
            activeEvents = active.count {
                it.status == EventStatus.ACTIVE
            },
            reachedGoals = states.count {
                it == EventProgressState.REACHED
            },
            shouldReach = states.count {
                it == EventProgressState.SHOULD_REACH
            },
            closeToReaching = states.count {
                it == EventProgressState.CLOSE_TO_REACHING
            },
            behind = states.count {
                it == EventProgressState.BEHIND
            }
        )
    }
}
