package com.herolife.feature.hero

import com.herolife.feature.hero.domain.HeroStore
import com.herolife.feature.hero.model.HeroDefinition
import com.herolife.feature.hero.model.HeroGender
import org.junit.Assert.*
import org.junit.Test

class HeroStoreTest {
    @Test
    fun purchaseDeductsGold() {
        val hero = HeroDefinition("h", "Hero", HeroGender.MALE, 300)
        val result = HeroStore.buyHero(hero, 500)
        assertTrue(result.success)
        assertEquals(200L, result.remainingGold)
    }

    @Test
    fun insufficientGoldDoesNotPurchase() {
        val hero = HeroDefinition("h", "Hero", HeroGender.MALE, 600)
        val result = HeroStore.buyHero(hero, 500)
        assertFalse(result.success)
        assertEquals(500L, result.remainingGold)
    }
}
