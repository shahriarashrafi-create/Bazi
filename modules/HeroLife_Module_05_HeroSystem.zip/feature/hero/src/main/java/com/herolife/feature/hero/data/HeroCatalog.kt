package com.herolife.feature.hero.data

import com.herolife.feature.hero.model.*

object HeroCatalog {
    val heroes = listOf(
        HeroDefinition("warrior_01", "جنگجوی جوان", HeroGender.MALE, 0, true),
        HeroDefinition("commander_01", "فرمانده", HeroGender.MALE, 750),
        HeroDefinition("lioness_01", "شیرزن", HeroGender.FEMALE, 750),
        HeroDefinition("leader_01", "پیشرو", HeroGender.FEMALE, 1200)
    )

    val titles = listOf(
        HeroTitle("fighter", "جنگنده", true),
        HeroTitle("commander", "فرمانده", false),
        HeroTitle("charismatic", "کاریزماتیک", false),
        HeroTitle("king", "سلطان", false),
        HeroTitle("pioneer", "پیشرو", false)
    )

    val cosmetics = listOf(
        HeroCosmetic("outfit_gold", "لباس طلایی", CosmeticSlot.OUTFIT, 300),
        HeroCosmetic("watch_elite", "ساعت ویژه", CosmeticSlot.WATCH, 180),
        HeroCosmetic("frame_crystal", "قاب کریستالی", CosmeticSlot.PROFILE_FRAME, 250),
        HeroCosmetic("entrance_gold", "ورود طلایی", CosmeticSlot.ENTRANCE_EFFECT, 400)
    )
}
