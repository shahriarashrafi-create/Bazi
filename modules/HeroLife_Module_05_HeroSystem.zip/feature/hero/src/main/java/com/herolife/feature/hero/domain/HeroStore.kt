package com.herolife.feature.hero.domain

import com.herolife.feature.hero.model.*

data class PurchaseResult(
    val success: Boolean,
    val remainingGold: Long,
    val message: String
)

object HeroStore {
    fun buyHero(hero: HeroDefinition, currentGold: Long): PurchaseResult {
        if (hero.unlocked) return PurchaseResult(true, currentGold, "قهرمان از قبل باز است")
        if (currentGold < hero.priceGold) return PurchaseResult(false, currentGold, "طلای کافی نداری")
        return PurchaseResult(true, currentGold - hero.priceGold, "قهرمان باز شد")
    }

    fun buyCosmetic(item: HeroCosmetic, currentGold: Long): PurchaseResult {
        if (item.owned) return PurchaseResult(true, currentGold, "آیتم از قبل خریداری شده")
        if (currentGold < item.priceGold) return PurchaseResult(false, currentGold, "طلای کافی نداری")
        return PurchaseResult(true, currentGold - item.priceGold, "آیتم خریداری شد")
    }
}
