package com.herolife.feature.hero.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.*
import com.herolife.feature.hero.data.HeroCatalog

@Composable
fun HeroSystemScreen(
    gold: Long,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("قهرمان من", style = MaterialTheme.typography.headlineMedium)

        HeroLifeStatChip(
            label = "موجودی",
            value = "🪙 $gold",
            accent = HeroLifeColors.Gold,
            modifier = Modifier.fillMaxWidth()
        )

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            Text("انتخاب قهرمان", style = MaterialTheme.typography.titleLarge)
            HeroCatalog.heroes.forEach { hero ->
                Text(
                    text = "${hero.displayName} — ${if (hero.unlocked) "باز" else "${hero.priceGold} طلا"}",
                    color = if (hero.unlocked) HeroLifeColors.Success else HeroLifeColors.TextPrimary
                )
            }
        }

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            Text("عنوان قهرمان", style = MaterialTheme.typography.titleLarge)
            Text(
                HeroCatalog.titles.joinToString("  •  ") { it.title },
                color = HeroLifeColors.Crystal
            )
        }

        HeroLifePanel(modifier = Modifier.fillMaxWidth()) {
            Text("شخصی‌سازی", style = MaterialTheme.typography.titleLarge)
            HeroCatalog.cosmetics.forEach { item ->
                Text("${item.name} — 🪙 ${item.priceGold}")
            }
        }

        Text(
            "ظاهر قهرمان و عنوان از هم مستقل هستند.",
            color = HeroLifeColors.TextSecondary,
            fontWeight = FontWeight.Bold
        )
    }
}
