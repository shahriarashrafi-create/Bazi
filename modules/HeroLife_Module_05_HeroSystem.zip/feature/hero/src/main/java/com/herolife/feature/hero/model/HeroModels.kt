package com.herolife.feature.hero.model

enum class HeroGender { MALE, FEMALE }

enum class CosmeticSlot {
    OUTFIT, WEAPON, WATCH, SHOES, CAPE, HAIR, ACCESSORY, PROFILE_FRAME, ENTRANCE_EFFECT, BACKGROUND
}

data class HeroDefinition(
    val id: String,
    val displayName: String,
    val gender: HeroGender,
    val priceGold: Long,
    val unlocked: Boolean = false
) {
    init {
        require(id.isNotBlank())
        require(displayName.isNotBlank())
        require(priceGold >= 0)
    }
}

data class HeroTitle(
    val id: String,
    val title: String,
    val unlocked: Boolean
)

data class HeroCosmetic(
    val id: String,
    val name: String,
    val slot: CosmeticSlot,
    val priceGold: Long,
    val owned: Boolean = false
) {
    init { require(priceGold >= 0) }
}

data class HeroLoadout(
    val heroId: String,
    val titleId: String,
    val equippedCosmetics: Map<CosmeticSlot, String> = emptyMap()
)
