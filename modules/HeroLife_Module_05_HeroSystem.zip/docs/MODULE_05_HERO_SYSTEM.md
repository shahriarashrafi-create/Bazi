# Module 05/20 — Hero System

Independent module: `:feature:hero`

Adds:
- Hero catalog
- Male/female hero definitions
- Separate hero appearance and hero title
- Gold-based hero purchases
- Cosmetic slots: outfit, weapon, watch, shoes, cape, hair, accessory, frame, entrance effect, background
- Loadout model
- Purchase domain logic
- Compose Hero screen
- Unit tests

No hero skills are introduced. Diamonds are not used for hero purchases.
