package com.herolife.feature.economy

import com.herolife.feature.economy.domain.RewardLimiter
import com.herolife.feature.economy.model.DailyEconomyUsage
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource
import com.herolife.feature.economy.model.WeeklyEconomyUsage
import org.junit.Assert.assertEquals
import org.junit.Test

class RewardLimiterTest {

    @Test
    fun dailyGoldCapIsEnforced() {
        val limiter = RewardLimiter()

        val result =
            limiter.limit(
                requested = RewardGrant(
                    source = RewardSource.ACHIEVEMENT,
                    gold = 100
                ),
                daily = DailyEconomyUsage(
                    earnedGold = 580
                ),
                weekly = WeeklyEconomyUsage()
            )

        assertEquals(20, result.gold)
    }

    @Test
    fun weeklyDiamondCapIsEnforced() {
        val limiter = RewardLimiter()

        val result =
            limiter.limit(
                requested = RewardGrant(
                    source = RewardSource.MILESTONE,
                    diamonds = 1
                ),
                daily = DailyEconomyUsage(),
                weekly = WeeklyEconomyUsage(
                    earnedDiamonds = 4
                )
            )

        assertEquals(0, result.diamonds)
    }
}
