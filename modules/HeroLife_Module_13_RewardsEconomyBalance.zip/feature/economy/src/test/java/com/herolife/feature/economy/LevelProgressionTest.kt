package com.herolife.feature.economy

import com.herolife.feature.economy.domain.LevelProgression
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LevelProgressionTest {

    @Test
    fun levelOneStartsAtZeroXp() {
        assertEquals(
            0L,
            LevelProgression.xpRequiredForLevel(1)
        )
    }

    @Test
    fun requiredXpAlwaysGrows() {
        val l10 =
            LevelProgression.xpRequiredForLevel(10)

        val l20 =
            LevelProgression.xpRequiredForLevel(20)

        assertTrue(l20 > l10)
    }

    @Test
    fun resolveProducesValidProgress() {
        val progress =
            LevelProgression.resolve(1500L)

        assertTrue(progress.level >= 1)
        assertTrue(
            progress.progressFraction in 0f..1f
        )
    }
}
