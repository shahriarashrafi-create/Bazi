package com.herolife.feature.economy

import com.herolife.feature.economy.domain.RewardCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RewardCalculatorTest {

    @Test
    fun longerTaskGetsMoreRewardButNotExtreme() {
        val calculator = RewardCalculator()

        val shortReward =
            calculator.taskReward(
                estimatedMinutes = 5,
                difficultyMultiplier = 1f
            )

        val longReward =
            calculator.taskReward(
                estimatedMinutes = 30,
                difficultyMultiplier = 1f
            )

        assertTrue(longReward.xp > shortReward.xp)
        assertTrue(longReward.gold > shortReward.gold)
        assertTrue(longReward.xp < shortReward.xp * 3)
    }

    @Test
    fun ordinaryTaskNeverGetsDiamond() {
        val calculator = RewardCalculator()

        val reward =
            calculator.taskReward(
                estimatedMinutes = 10,
                difficultyMultiplier = 1.3f
            )

        assertEquals(0, reward.diamonds)
    }

    @Test
    fun importantAchievementCanGrantOneDiamond() {
        val calculator = RewardCalculator()

        val reward =
            calculator.rareAchievement(
                significanceScore = 7
            )

        assertEquals(1, reward.diamonds)
    }
}
