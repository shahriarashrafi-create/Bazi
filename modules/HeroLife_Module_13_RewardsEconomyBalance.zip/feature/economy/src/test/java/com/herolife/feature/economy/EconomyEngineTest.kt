package com.herolife.feature.economy

import com.herolife.feature.economy.domain.EconomyEngine
import com.herolife.feature.economy.model.DailyEconomyUsage
import com.herolife.feature.economy.model.EconomyWallet
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource
import com.herolife.feature.economy.model.WeeklyEconomyUsage
import org.junit.Assert.assertEquals
import org.junit.Test

class EconomyEngineTest {

    @Test
    fun walletReceivesValidReward() {
        val engine = EconomyEngine()

        val result =
            engine.apply(
                wallet = EconomyWallet(),
                requested = RewardGrant(
                    source = RewardSource.ACHIEVEMENT,
                    xp = 100,
                    gold = 50,
                    diamonds = 1
                ),
                dailyUsage = DailyEconomyUsage(),
                weeklyUsage = WeeklyEconomyUsage()
            )

        assertEquals(100L, result.wallet.xp)
        assertEquals(50L, result.wallet.gold)
        assertEquals(1L, result.wallet.diamonds)
    }

    @Test(expected = IllegalArgumentException::class)
    fun ordinaryTaskCannotGrantDiamond() {
        val engine = EconomyEngine()

        engine.apply(
            wallet = EconomyWallet(),
            requested = RewardGrant(
                source = RewardSource.TASK_COMPLETE,
                diamonds = 1
            ),
            dailyUsage = DailyEconomyUsage(),
            weeklyUsage = WeeklyEconomyUsage()
        )
    }
}
