package com.herolife.feature.economy.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.economy.model.RewardGrant

@Composable
fun RewardReceiptCard(
    grant: RewardGrant,
    capped: Boolean,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = "پاداش دریافت شد",
            style = MaterialTheme.typography.titleLarge
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (grant.xp > 0) {
                Text(
                    text = "+${grant.xp} XP",
                    color = HeroLifeColors.Crystal
                )
            }

            if (grant.gold > 0) {
                Text(
                    text = "+${grant.gold} طلا",
                    color = HeroLifeColors.Gold
                )
            }

            if (grant.diamonds > 0) {
                Text(
                    text = "+${grant.diamonds} الماس",
                    color = HeroLifeColors.CrystalBright
                )
            }
        }

        if (grant.reason.isNotBlank()) {
            Text(
                text = grant.reason,
                style = MaterialTheme.typography.bodyMedium,
                color = HeroLifeColors.TextSecondary
            )
        }

        if (capped) {
            Text(
                text = "بخشی از پاداش به سقف اقتصادی روزانه/هفتگی رسید.",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.Warning
            )
        }
    }
}
