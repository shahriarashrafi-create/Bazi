package com.herolife.feature.economy.domain

import com.herolife.feature.economy.model.DailyEconomyUsage
import com.herolife.feature.economy.model.EconomyBalanceProfile
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.WeeklyEconomyUsage
import kotlin.math.min

class RewardLimiter(
    private val balance: EconomyBalanceProfile = EconomyBalanceProfile()
) {

    fun limit(
        requested: RewardGrant,
        daily: DailyEconomyUsage,
        weekly: WeeklyEconomyUsage
    ): RewardGrant {
        val xpRemaining =
            (balance.dailyXpCap - daily.earnedXp)
                .coerceAtLeast(0)

        val goldRemaining =
            (balance.dailyGoldCap - daily.earnedGold)
                .coerceAtLeast(0)

        val dailyDiamondRemaining =
            (balance.diamondDailyCap - daily.earnedDiamonds)
                .coerceAtLeast(0)

        val weeklyDiamondRemaining =
            (balance.diamondWeeklyCap - weekly.earnedDiamonds)
                .coerceAtLeast(0)

        val diamondRemaining =
            min(dailyDiamondRemaining, weeklyDiamondRemaining)

        return requested.copy(
            xp = min(requested.xp, xpRemaining),
            gold = min(requested.gold, goldRemaining),
            diamonds = min(requested.diamonds, diamondRemaining)
        )
    }
}
