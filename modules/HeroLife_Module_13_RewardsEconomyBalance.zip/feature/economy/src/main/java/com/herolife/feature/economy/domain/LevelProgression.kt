package com.herolife.feature.economy.domain

import kotlin.math.pow
import kotlin.math.roundToLong

data class LevelProgress(
    val level: Int,
    val totalXp: Long,
    val currentLevelXp: Long,
    val xpForNextLevel: Long,
    val progressFraction: Float
)

object LevelProgression {

    fun xpRequiredForLevel(level: Int): Long {
        require(level >= 1)

        if (level == 1) return 0L

        return (
            100.0 *
                (level - 1).toDouble().pow(1.42)
            ).roundToLong()
    }

    fun resolve(totalXp: Long): LevelProgress {
        require(totalXp >= 0L)

        var level = 1

        while (
            level < 500 &&
            xpRequiredForLevel(level + 1) <= totalXp
        ) {
            level += 1
        }

        val currentThreshold = xpRequiredForLevel(level)
        val nextThreshold = xpRequiredForLevel(level + 1)
        val currentLevelXp = totalXp - currentThreshold
        val needed =
            (nextThreshold - currentThreshold)
                .coerceAtLeast(1L)

        val fraction =
            (
                currentLevelXp.toDouble() /
                    needed.toDouble()
                )
                .toFloat()
                .coerceIn(0f, 1f)

        return LevelProgress(
            level = level,
            totalXp = totalXp,
            currentLevelXp = currentLevelXp,
            xpForNextLevel = needed,
            progressFraction = fraction
        )
    }
}
