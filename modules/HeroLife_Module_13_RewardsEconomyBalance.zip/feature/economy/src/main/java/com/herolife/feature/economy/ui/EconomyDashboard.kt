package com.herolife.feature.economy.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.core.designsystem.HeroLifeSectionHeader
import com.herolife.core.designsystem.HeroLifeStatChip
import com.herolife.core.designsystem.HeroLifeXpBar
import com.herolife.feature.economy.domain.LevelProgression
import com.herolife.feature.economy.model.EconomyWallet

@Composable
fun EconomyDashboard(
    wallet: EconomyWallet,
    modifier: Modifier = Modifier
) {
    val progress =
        LevelProgression.resolve(wallet.xp)

    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        HeroLifeSectionHeader(
            title = "اقتصاد HeroLife",
            subtitle = "XP برای رشد، طلا برای Hero، الماس برای پاداش واقعی"
        )

        Text(
            text = "سطح ${progress.level}",
            style = MaterialTheme.typography.headlineMedium
        )

        HeroLifeXpBar(
            progress = progress.progressFraction
        )

        Text(
            text = "${progress.currentLevelXp} / ${progress.xpForNextLevel} XP",
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextSecondary
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HeroLifeStatChip(
                label = "XP کل",
                value = wallet.xp.toString(),
                accent = HeroLifeColors.Crystal,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "طلا",
                value = "🪙 ${wallet.gold}",
                accent = HeroLifeColors.Gold,
                modifier = Modifier.fillMaxWidth()
            )

            HeroLifeStatChip(
                label = "الماس کمیاب",
                value = "💎 ${wallet.diamonds}",
                accent = HeroLifeColors.CrystalBright,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Text(
            text = "الماس از کارهای عادی و بردهای عادی تولید نمی‌شود.",
            style = MaterialTheme.typography.bodySmall,
            color = HeroLifeColors.TextMuted
        )
    }
}
