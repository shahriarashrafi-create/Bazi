package com.herolife.feature.economy.domain

import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource
import com.herolife.feature.match.model.MatchState

object MatchRewardBridge {

    fun fromMatchState(
        state: MatchState,
        victory: Boolean
    ): RewardGrant {
        val baseXp = state.earnedXp.coerceAtLeast(0)
        val baseGold = state.earnedGold.coerceAtLeast(0)

        val bonusXp = if (victory) 80 else 20
        val bonusGold = if (victory) 40 else 8

        return RewardGrant(
            source = if (victory) {
                RewardSource.MATCH_VICTORY
            } else {
                RewardSource.MATCH_DEFEAT
            },
            xp = baseXp + bonusXp,
            gold = baseGold + bonusGold,
            diamonds = 0,
            reason = if (victory) "پیروزی" else "تلاش"
        )
    }
}
