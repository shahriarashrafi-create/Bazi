package com.herolife.feature.economy.domain

import com.herolife.feature.economy.model.EconomyBalanceProfile
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource
import kotlin.math.roundToInt

class RewardCalculator(
    private val balance: EconomyBalanceProfile = EconomyBalanceProfile()
) {

    fun taskReward(
        estimatedMinutes: Int,
        difficultyMultiplier: Float,
        sourceReason: String = "تکمیل کار"
    ): RewardGrant {
        require(estimatedMinutes > 0)
        require(difficultyMultiplier > 0f)

        val durationFactor = when {
            estimatedMinutes <= 5 -> 1.0f
            estimatedMinutes <= 10 -> 1.18f
            estimatedMinutes <= 20 -> 1.38f
            estimatedMinutes <= 30 -> 1.55f
            else -> 1.70f
        }

        val safeDifficulty = difficultyMultiplier.coerceIn(0.75f, 1.75f)

        val xp = (
            balance.baseTaskXp *
                durationFactor *
                safeDifficulty
            ).roundToInt()
            .coerceAtLeast(1)

        val gold = (
            balance.baseTaskGold *
                durationFactor *
                safeDifficulty
            ).roundToInt()
            .coerceAtLeast(1)

        return RewardGrant(
            source = RewardSource.TASK_COMPLETE,
            xp = xp,
            gold = gold,
            diamonds = 0,
            reason = sourceReason
        )
    }

    fun matchResult(victory: Boolean): RewardGrant =
        if (victory) {
            RewardGrant(
                source = RewardSource.MATCH_VICTORY,
                xp = balance.matchVictoryXp,
                gold = balance.matchVictoryGold,
                diamonds = 0,
                reason = "پیروزی در نبرد ۳۰ دقیقه‌ای"
            )
        } else {
            RewardGrant(
                source = RewardSource.MATCH_DEFEAT,
                xp = balance.matchDefeatXp,
                gold = balance.matchDefeatGold,
                diamonds = 0,
                reason = "تلاش در نبرد ۳۰ دقیقه‌ای"
            )
        }

    fun streakBonus(consecutiveCompletions: Int): RewardGrant? {
        if (
            consecutiveCompletions <= 0 ||
            consecutiveCompletions % balance.streakBonusEvery != 0
        ) {
            return null
        }

        val tier =
            (consecutiveCompletions / balance.streakBonusEvery)
                .coerceAtMost(4)

        return RewardGrant(
            source = RewardSource.STREAK,
            xp = balance.streakBonusXp * tier,
            gold = balance.streakBonusGold * tier,
            diamonds = 0,
            reason = "پاداش زنجیره $consecutiveCompletions"
        )
    }

    fun personalRecord(): RewardGrant =
        RewardGrant(
            source = RewardSource.PERSONAL_RECORD,
            xp = balance.personalRecordXp,
            gold = balance.personalRecordGold,
            diamonds = 0,
            reason = "رکورد شخصی جدید"
        )

    fun rareAchievement(significanceScore: Int): RewardGrant {
        require(significanceScore >= 1)

        val diamond =
            if (
                significanceScore >=
                balance.rareDiamondAchievementThreshold
            ) {
                1
            } else {
                0
            }

        return RewardGrant(
            source = RewardSource.ACHIEVEMENT,
            xp = 60 + significanceScore * 15,
            gold = 25 + significanceScore * 8,
            diamonds = diamond,
            reason = "دستاورد مهم"
        )
    }

    fun milestone(major: Boolean): RewardGrant =
        RewardGrant(
            source = RewardSource.MILESTONE,
            xp = if (major) 250 else 100,
            gold = if (major) 120 else 45,
            diamonds = if (major) 1 else 0,
            reason = if (major) {
                "نقطه عطف بزرگ"
            } else {
                "نقطه عطف"
            }
        )
}
