package com.herolife.feature.economy.domain

import com.herolife.feature.economy.model.RewardSource

object DiamondPolicy {

    fun isDiamondEligible(source: RewardSource): Boolean =
        when (source) {
            RewardSource.ACHIEVEMENT,
            RewardSource.WEEKLY_GOAL,
            RewardSource.MONTHLY_GOAL,
            RewardSource.PERSONAL_RECORD,
            RewardSource.MILESTONE -> true

            RewardSource.TASK_COMPLETE,
            RewardSource.MATCH_VICTORY,
            RewardSource.MATCH_DEFEAT,
            RewardSource.STREAK,
            RewardSource.DAILY_GOAL -> false
        }

    fun validateSource(
        source: RewardSource,
        diamonds: Int
    ): Boolean =
        diamonds == 0 ||
            isDiamondEligible(source)
}
