package com.herolife.feature.economy.model

enum class RewardSource {
    TASK_COMPLETE,
    MATCH_VICTORY,
    MATCH_DEFEAT,
    STREAK,
    ACHIEVEMENT,
    DAILY_GOAL,
    WEEKLY_GOAL,
    MONTHLY_GOAL,
    PERSONAL_RECORD,
    MILESTONE
}

enum class RewardCurrency {
    XP,
    GOLD,
    DIAMOND
}

data class RewardGrant(
    val source: RewardSource,
    val xp: Int = 0,
    val gold: Int = 0,
    val diamonds: Int = 0,
    val reason: String = ""
) {
    init {
        require(xp >= 0)
        require(gold >= 0)
        require(diamonds >= 0)
    }

    val totalUnits: Int
        get() = xp + gold + diamonds
}

data class EconomyWallet(
    val xp: Long = 0L,
    val gold: Long = 0L,
    val diamonds: Long = 0L
) {
    init {
        require(xp >= 0L)
        require(gold >= 0L)
        require(diamonds >= 0L)
    }

    fun apply(grant: RewardGrant): EconomyWallet =
        copy(
            xp = xp + grant.xp,
            gold = gold + grant.gold,
            diamonds = diamonds + grant.diamonds
        )
}

data class EconomyBalanceProfile(
    val baseTaskXp: Int = 10,
    val baseTaskGold: Int = 5,
    val matchVictoryXp: Int = 80,
    val matchVictoryGold: Int = 40,
    val matchDefeatXp: Int = 20,
    val matchDefeatGold: Int = 8,
    val dailyXpCap: Int = 1200,
    val dailyGoldCap: Int = 600,
    val diamondDailyCap: Int = 1,
    val diamondWeeklyCap: Int = 4,
    val streakBonusEvery: Int = 3,
    val streakBonusXp: Int = 30,
    val streakBonusGold: Int = 15,
    val personalRecordXp: Int = 120,
    val personalRecordGold: Int = 60,
    val rareDiamondAchievementThreshold: Int = 5
) {
    init {
        require(baseTaskXp >= 0)
        require(baseTaskGold >= 0)
        require(matchVictoryXp >= 0)
        require(matchVictoryGold >= 0)
        require(matchDefeatXp >= 0)
        require(matchDefeatGold >= 0)
        require(dailyXpCap > 0)
        require(dailyGoldCap > 0)
        require(diamondDailyCap >= 0)
        require(diamondWeeklyCap >= diamondDailyCap)
        require(streakBonusEvery > 0)
        require(streakBonusXp >= 0)
        require(streakBonusGold >= 0)
        require(personalRecordXp >= 0)
        require(personalRecordGold >= 0)
        require(rareDiamondAchievementThreshold > 0)
    }
}

data class DailyEconomyUsage(
    val earnedXp: Int = 0,
    val earnedGold: Int = 0,
    val earnedDiamonds: Int = 0
) {
    init {
        require(earnedXp >= 0)
        require(earnedGold >= 0)
        require(earnedDiamonds >= 0)
    }
}

data class WeeklyEconomyUsage(
    val earnedDiamonds: Int = 0
) {
    init {
        require(earnedDiamonds >= 0)
    }
}
