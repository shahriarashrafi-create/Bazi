package com.herolife.feature.economy.domain

import com.herolife.feature.economy.model.DailyEconomyUsage
import com.herolife.feature.economy.model.EconomyBalanceProfile
import com.herolife.feature.economy.model.EconomyWallet
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.WeeklyEconomyUsage

data class EconomyApplyResult(
    val wallet: EconomyWallet,
    val granted: RewardGrant,
    val capped: Boolean
)

class EconomyEngine(
    balance: EconomyBalanceProfile = EconomyBalanceProfile()
) {
    private val limiter = RewardLimiter(balance)

    fun apply(
        wallet: EconomyWallet,
        requested: RewardGrant,
        dailyUsage: DailyEconomyUsage,
        weeklyUsage: WeeklyEconomyUsage
    ): EconomyApplyResult {
        require(
            DiamondPolicy.validateSource(
                requested.source,
                requested.diamonds
            )
        ) {
            "Diamond is not allowed for source ${requested.source}"
        }

        val limited = limiter.limit(
            requested = requested,
            daily = dailyUsage,
            weekly = weeklyUsage
        )

        val capped =
            limited.xp != requested.xp ||
                limited.gold != requested.gold ||
                limited.diamonds != requested.diamonds

        return EconomyApplyResult(
            wallet = wallet.apply(limited),
            granted = limited,
            capped = capped
        )
    }
}
