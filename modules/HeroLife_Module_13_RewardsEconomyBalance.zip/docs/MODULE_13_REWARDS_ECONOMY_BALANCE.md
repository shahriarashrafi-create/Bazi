# Module 13/20 — Rewards Economy & Balance

Independent module: `:feature:economy`

## Product rules implemented

- XP is progression-only and is never spent.
- Gold is the frequent in-game currency.
- Gold is intended for Hero purchase and Hero cosmetics.
- Diamond is rare and protected by strict policy.
- Ordinary tasks never directly grant Diamond.
- Ordinary match victory never directly grants Diamond.
- Diamond is reserved for important achievements, weekly/monthly goals, personal records, and long-term milestones.

## Economy systems

- Reward calculator
- Duration-based reward scaling
- Difficulty scaling
- Match victory / defeat reward
- Streak rewards
- Personal record rewards
- Achievement reward
- Milestone reward
- Daily XP cap
- Daily Gold cap
- Daily Diamond cap
- Weekly Diamond cap
- Anti-inflation limiter
- Diamond source validator
- Long-term Level progression curve
- Match reward bridge
- Wallet engine
- Reward receipt UI
- Economy dashboard UI
- Unit tests

## Balance philosophy

The economy should create motivation without turning the app into a grind.

XP:
Frequent, visible, never spendable.

Gold:
Frequent enough that cosmetics feel attainable but not instant.

Diamond:
Rare enough that a Diamond feels meaningful.

No Energy system is introduced.
No loot-box system is introduced.

## Future tuning

A later balance pass can tune constants without changing the module API.

Module 14 will add:
Achievements / Records / MVP / streak history.
