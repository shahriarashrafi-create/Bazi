# HeroLife FINAL App Wiring Patch

This patch replaces the old Module-01 placeholder `MainActivity.kt` with a
real app shell and functional navigation.

## What it fixes

- old `HomeScreen()` placeholder is removed
- old empty `onClick = {}` Start Game button is removed
- five bottom navigation destinations work
- Home / Tasks / Team / Time Sheet / CRM are interactive
- Hero / Achievements / Events / Economy / Future Vision are reachable
- Start Game opens a live 30-minute battle screen
- battle timer counts down
- task completion inside battle rewards XP/Gold
- task completion in Task screen rewards XP/Gold
- Hero title selection changes Home
- Empire preview is visible
- Module 20's registry is imported so the final app is wired through the
  final integration module, which itself depends on all completed feature
  modules.

## Upload

Upload this ZIP to `modules/` WITHOUT extracting it.

The existing module loader should extract the root-level `app/...` path and
overwrite the old placeholder `MainActivity.kt` before the Gradle build.
