package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.integration.domain.ModuleRegistry
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                HeroLifeTheme {
                    HeroLifeFinalApp()
                }
            }
        }
    }
}

@Composable
private fun HeroLifeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = HeroLifeColors.Gold,
            secondary = HeroLifeColors.Crystal,
            background = HeroLifeColors.Void,
            surface = HeroLifeColors.DeepNavy,
            onPrimary = HeroLifeColors.Void,
            onBackground = HeroLifeColors.TextPrimary,
            onSurface = HeroLifeColors.TextPrimary
        ),
        content = content
    )
}

private enum class Screen {
    HOME, TASKS, TEAM, TIME, CRM, HERO, ACHIEVEMENTS, EVENTS, ECONOMY, VISION, GAME
}

private data class LocalTask(val id: Int, val title: String, var done: Boolean = false)
private data class Prospect(val id: Int, val name: String, val stage: String)
private data class TimeItem(val id: Int, val title: String, val minutes: Int)
private data class EventItem(val id: Int, val title: String, val progress: Float)
private data class VisionItem(val id: Int, val title: String, val year: Int, val progress: Float)

@Composable
private fun HeroLifeFinalApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(25) }
    var gold by remember { mutableIntStateOf(120) }
    var diamonds by remember { mutableIntStateOf(1) }
    var heroTitle by remember { mutableStateOf("جنگنده") }

    val tasks = remember {
        mutableStateListOf(
            LocalTask(1, "ارتباط‌سازی با ۳ نفر"),
            LocalTask(2, "فالوآپ مخاطب گرم"),
            LocalTask(3, "۳۰ دقیقه رشد فردی"),
            LocalTask(4, "دعوت برای معرفی کار")
        )
    }
    val prospects = remember {
        mutableStateListOf(
            Prospect(1, "مخاطب نمونه ۱", "فالوآپ"),
            Prospect(2, "مخاطب نمونه ۲", "دعوت"),
            Prospect(3, "مخاطب نمونه ۳", "پیش‌مشاوره")
        )
    }
    val timeItems = remember {
        mutableStateListOf(
            TimeItem(1, "شبکه‌سازی", 60),
            TimeItem(2, "رشد فردی", 30),
            TimeItem(3, "فالوآپ", 45)
        )
    }
    val events = remember {
        mutableStateListOf(
            EventItem(1, "ایونت ماه جاری", .62f),
            EventItem(2, "جلسه لیدرها", .35f)
        )
    }
    val visions = remember {
        mutableStateListOf(
            VisionItem(1, "درآمد هدف", 2027, .42f),
            VisionItem(2, "سبک زندگی", 2028, .25f),
            VisionItem(3, "امپراتوری شخصی", 2030, .12f)
        )
    }

    Scaffold(
        containerColor = HeroLifeColors.Void,
        bottomBar = {
            if (screen != Screen.GAME) {
                FinalBottomBar(
                    selected = screen,
                    onSelect = { screen = it }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(HeroLifeColors.Void)
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    level, xp, gold, diamonds, heroTitle,
                    onStartGame = { screen = Screen.GAME },
                    onHero = { screen = Screen.HERO },
                    onAchievements = { screen = Screen.ACHIEVEMENTS },
                    onEvents = { screen = Screen.EVENTS },
                    onEconomy = { screen = Screen.ECONOMY },
                    onVision = { screen = Screen.VISION }
                )
                Screen.TASKS -> TasksScreen(
                    tasks = tasks,
                    onComplete = { task ->
                        val idx = tasks.indexOfFirst { it.id == task.id }
                        if (idx >= 0 && !tasks[idx].done) {
                            tasks[idx] = tasks[idx].copy(done = true)
                            xp += 10
                            gold += 5
                            if (xp >= 100) {
                                level += 1
                                xp -= 100
                            }
                        }
                    },
                    onAdd = {
                        tasks.add(LocalTask(tasks.size + 1, "کار جدید ${tasks.size + 1}"))
                    }
                )
                Screen.TEAM -> TeamScreen()
                Screen.TIME -> TimeSheetScreen(timeItems) {
                    timeItems.add(TimeItem(timeItems.size + 1, "بلوک جدید", 30))
                }
                Screen.CRM -> CrmScreen(prospects) {
                    prospects.add(Prospect(prospects.size + 1, "مخاطب جدید ${prospects.size + 1}", "ارتباط‌سازی"))
                }
                Screen.HERO -> HeroScreen(
                    selected = heroTitle,
                    gold = gold,
                    onSelect = { heroTitle = it },
                    onBack = { screen = Screen.HOME }
                )
                Screen.ACHIEVEMENTS -> AchievementsScreen(
                    doneTasks = tasks.count { it.done },
                    onBack = { screen = Screen.HOME }
                )
                Screen.EVENTS -> EventsScreen(events) { screen = Screen.HOME }
                Screen.ECONOMY -> EconomyScreen(xp, gold, diamonds) { screen = Screen.HOME }
                Screen.VISION -> VisionScreen(visions) { screen = Screen.HOME }
                Screen.GAME -> GameScreen(
                    tasks = tasks,
                    onTaskDone = { id ->
                        val idx = tasks.indexOfFirst { it.id == id }
                        if (idx >= 0 && !tasks[idx].done) {
                            tasks[idx] = tasks[idx].copy(done = true)
                            xp += 15
                            gold += 8
                        }
                    },
                    onExit = { screen = Screen.HOME }
                )
            }
        }
    }
}

@Composable
private fun FinalBottomBar(selected: Screen, onSelect: (Screen) -> Unit) {
    NavigationBar(containerColor = Color(0xFF08162A)) {
        val items = listOf(
            Triple(Screen.HOME, "◆", "خانه"),
            Triple(Screen.TASKS, "✓", "کارها"),
            Triple(Screen.TEAM, "♜", "آمار تیم"),
            Triple(Screen.TIME, "◷", "برنامه زمانی"),
            Triple(Screen.CRM, "◎", "شبکه‌سازی")
        )
        items.forEach { (route, icon, title) ->
            NavigationBarItem(
                selected = selected == route,
                onClick = { onSelect(route) },
                icon = {
                    Text(
                        icon,
                        color = if (selected == route) HeroLifeColors.CrystalBright else HeroLifeColors.TextMuted
                    )
                },
                label = {
                    Text(
                        title,
                        fontSize = 11.sp,
                        color = if (selected == route) HeroLifeColors.TextPrimary else HeroLifeColors.TextMuted
                    )
                }
            )
        }
    }
}

@Composable
private fun Page(title: String, subtitle: String = "", content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Black, color = HeroLifeColors.TextPrimary)
        if (subtitle.isNotBlank()) {
            Text(subtitle, color = HeroLifeColors.TextMuted)
        }
        content()
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF10243C),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x334DCBFF))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
private fun HomeScreen(
    level: Int,
    xp: Int,
    gold: Int,
    diamonds: Int,
    heroTitle: String,
    onStartGame: () -> Unit,
    onHero: () -> Unit,
    onAchievements: () -> Unit,
    onEvents: () -> Unit,
    onEconomy: () -> Unit,
    onVision: () -> Unit
) {
    Page("HeroLife", "امروز یک قدم جلوتر برو.") {
        Panel {
            Text("بازیکن", fontSize = 32.sp, color = HeroLifeColors.TextPrimary)
            Text(heroTitle, fontSize = 18.sp, color = HeroLifeColors.GoldBright)
            Text("سطح $level", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { (xp / 100f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
                color = HeroLifeColors.CrystalBright,
                trackColor = Color(0xFF1A3B60)
            )
            Text("XP $xp / 100", color = HeroLifeColors.TextMuted)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("طلا", "$gold 🪙", HeroLifeColors.GoldBright)
                Metric("الماس", "$diamonds 💎", HeroLifeColors.CrystalBright)
            }
        }

        Panel {
            Text("قهرمان شما", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            HeroPreview(heroTitle)
            Button(
                onClick = onHero,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF163A5A))
            ) { Text("شخصی‌سازی قهرمان") }
        }

        Button(
            onClick = onStartGame,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HeroLifeColors.Gold)
        ) {
            Text("⚔️ شروع بازی ۳۰ دقیقه‌ای", fontSize = 19.sp, fontWeight = FontWeight.Black, color = HeroLifeColors.Void)
        }

        Text("دسترسی سریع", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        QuickButton("🏆 افتخارات و رکوردها", onAchievements)
        QuickButton("📅 رویدادها و Event Director", onEvents)
        QuickButton("💰 اقتصاد و پاداش‌ها", onEconomy)
        QuickButton("🏰 چشم‌انداز آینده و امپراتوری", onVision)

        Text(
            "۲۰ ماژول فعال • ${ModuleRegistry.modules.size}/20",
            color = HeroLifeColors.Success,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun Metric(label: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF0A1B2F),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .45f))
    ) {
        Column(Modifier.padding(horizontal = 22.dp, vertical = 14.dp)) {
            Text(label, color = HeroLifeColors.TextMuted)
            Text(value, color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun QuickButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text) }
}

@Composable
private fun HeroPreview(title: String) {
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val cx = size.width / 2f
        val cy = size.height * .48f
        drawCircle(HeroLifeColors.GoldBright.copy(alpha = .10f), minOf(size.width, size.height) * .28f, Offset(cx, cy))
        drawCircle(HeroLifeColors.Crystal, 28.dp.toPx(), Offset(cx, cy - 35.dp.toPx()))
        drawRect(
            HeroLifeColors.CrystalDark,
            Offset(cx - 35.dp.toPx(), cy - 7.dp.toPx()),
            Size(70.dp.toPx(), 82.dp.toPx())
        )
        drawLine(HeroLifeColors.GoldBright, Offset(cx + 35.dp.toPx(), cy), Offset(cx + 75.dp.toPx(), cy - 55.dp.toPx()), 5.dp.toPx())
    }
    Text(title, modifier = Modifier.fillMaxWidth(), color = HeroLifeColors.GoldBright)
}

@Composable
private fun TasksScreen(tasks: List<LocalTask>, onComplete: (LocalTask) -> Unit, onAdd: () -> Unit) {
    Page("کارها", "کتابخانه کارها و اولویت‌های امروز") {
        tasks.forEach { task ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { onComplete(task) },
                color = if (task.done) Color(0xFF123529) else Color(0xFF10243C),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(task.title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (task.done) "✓ انجام شد" else "حیاتی • شبکه‌سازی • لمس برای انجام", color = if (task.done) HeroLifeColors.Success else HeroLifeColors.Gold)
                }
            }
        }
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("+ افزودن کار") }
    }
}

@Composable
private fun TeamScreen() {
    Page("آمار تیم", "رشد شاخه‌ها، فروش و مومنتوم") {
        Panel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("اعضای فعال", "18", HeroLifeColors.Crystal)
                Metric("رشد", "+12%", HeroLifeColors.Success)
            }
            Text("فروش تیم", color = HeroLifeColors.TextMuted)
            Text("1,240,000", fontSize = 28.sp, fontWeight = FontWeight.Black, color = HeroLifeColors.GoldBright)
            LinearProgressIndicator(progress = { .68f }, modifier = Modifier.fillMaxWidth())
        }
        Text("شاخه‌ها", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        listOf("شاخه آلفا" to .82f, "شاخه بتا" to .64f, "شاخه گاما" to .51f).forEach {
            Panel {
                Text(it.first, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { it.second }, modifier = Modifier.fillMaxWidth(), color = HeroLifeColors.Crystal)
            }
        }
    }
}

@Composable
private fun TimeSheetScreen(items: List<TimeItem>, onAdd: () -> Unit) {
    Page("برنامه زمانی", "Time Blocking روزانه و هفتگی") {
        items.forEachIndexed { index, item ->
            Panel {
                Text("${index + 1}. ${item.title}", fontWeight = FontWeight.Bold)
                Text("${item.minutes} دقیقه", color = HeroLifeColors.Crystal)
            }
        }
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("+ Time Block جدید") }
    }
}

@Composable
private fun CrmScreen(prospects: List<Prospect>, onAdd: () -> Unit) {
    Page("شبکه‌سازی", "CRM مخاطبین و دو اقدام بعدی") {
        prospects.forEach { prospect ->
            Panel {
                Text(prospect.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("مرحله: ${prospect.stage}", color = HeroLifeColors.GoldBright)
                Text("اقدام بعدی ۱: پیگیری", color = HeroLifeColors.TextSecondary)
                Text("اقدام بعدی ۲: دعوت مجدد", color = HeroLifeColors.TextSecondary)
            }
        }
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("+ مخاطب جدید") }
    }
}

@Composable
private fun HeroScreen(selected: String, gold: Int, onSelect: (String) -> Unit, onBack: () -> Unit) {
    val titles = listOf("جنگنده", "فرمانده", "کاریزماتیک", "سلطان", "پیشرو")
    Page("قهرمان", "ظاهر، عنوان و تجهیزات") {
        HeroPreview(selected)
        Text("طلای شما: $gold", color = HeroLifeColors.GoldBright)
        titles.forEach { title ->
            OutlinedButton(
                onClick = { onSelect(title) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (selected == title) "✓ $title" else title)
            }
        }
        QuickButton("بازگشت به خانه", onBack)
    }
}

@Composable
private fun AchievementsScreen(doneTasks: Int, onBack: () -> Unit) {
    Page("افتخارات", "روزانه • هفتگی • ماهانه • بلندمدت") {
        val rows = listOf(
            Triple("شروع قدرتمند", doneTasks / 3f, "۳ کار"),
            Triple("جنگنده هفته", .45f, "۵ برد"),
            Triple("سلطان ماه", .28f, "۲۰ برد"),
            Triple("هزار قدم", doneTasks / 1000f, "۱۰۰۰ کار")
        )
        rows.forEach { (name, progress, goal) ->
            Panel {
                Text(name, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { progress.coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth(), color = HeroLifeColors.Gold)
                Text(goal, color = HeroLifeColors.TextMuted)
            }
        }
        QuickButton("بازگشت", onBack)
    }
}

@Composable
private fun EventsScreen(events: List<EventItem>, onBack: () -> Unit) {
    Page("رویدادها", "Event Director و پیش‌بینی رسیدن به هدف") {
        events.forEach {
            Panel {
                Text(it.title, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { it.progress }, modifier = Modifier.fillMaxWidth(), color = HeroLifeColors.Crystal)
                Text("${(it.progress * 100).toInt()}% • نزدیک رسیدن", color = HeroLifeColors.GoldBright)
            }
        }
        QuickButton("بازگشت", onBack)
    }
}

@Composable
private fun EconomyScreen(xp: Int, gold: Int, diamonds: Int, onBack: () -> Unit) {
    Page("اقتصاد", "XP برای پیشرفت • Gold برای ظاهر • Diamond کمیاب") {
        Panel {
            Metric("XP", xp.toString(), HeroLifeColors.Crystal)
            Metric("Gold", gold.toString(), HeroLifeColors.GoldBright)
            Metric("Diamond", diamonds.toString(), HeroLifeColors.CrystalBright)
        }
        Panel {
            Text("فروشگاه پاداش واقعی", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("پاداش نمونه • 3 💎", color = HeroLifeColors.TextSecondary)
            Text("پاداش بزرگ • 10 💎", color = HeroLifeColors.TextSecondary)
        }
        QuickButton("بازگشت", onBack)
    }
}

@Composable
private fun VisionScreen(visions: List<VisionItem>, onBack: () -> Unit) {
    Page("چشم‌انداز آینده", "Vision → Goal → Mission → Action → Reward") {
        visions.forEach {
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(it.title, fontWeight = FontWeight.Bold)
                    Text(it.year.toString(), color = HeroLifeColors.GoldBright)
                }
                LinearProgressIndicator(progress = { it.progress }, modifier = Modifier.fillMaxWidth(), color = HeroLifeColors.Crystal)
            }
        }
        Text("امپراتوری", fontSize = 22.sp, fontWeight = FontWeight.Black)
        EmpirePreview()
        QuickButton("بازگشت", onBack)
    }
}

@Composable
private fun EmpirePreview() {
    Canvas(Modifier.fillMaxWidth().height(180.dp)) {
        val baseY = size.height * .85f
        drawRect(Color(0xFF18324A), Offset(0f, baseY), Size(size.width, size.height - baseY))
        repeat(5) { i ->
            val w = 35.dp.toPx()
            val h = (45 + i * 15).dp.toPx()
            val x = size.width * (.15f + i * .17f)
            drawRect(
                if (i == 4) HeroLifeColors.GoldBright else HeroLifeColors.CrystalDark,
                Offset(x, baseY - h),
                Size(w, h)
            )
        }
    }
}

@Composable
private fun GameScreen(tasks: List<LocalTask>, onTaskDone: (Int) -> Unit, onExit: () -> Unit) {
    var seconds by remember { mutableIntStateOf(30 * 60) }
    var selectedId by remember { mutableStateOf<Int?>(tasks.firstOrNull { !it.done }?.id) }

    LaunchedEffect(Unit) {
        while (seconds > 0) {
            kotlinx.coroutines.delay(1000)
            seconds -= 1
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF06101E))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "%02d:%02d".format(seconds / 60, seconds % 60),
                color = if (seconds <= 60) HeroLifeColors.Danger else HeroLifeColors.GoldBright,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Text("NETWORKING • GROWTH • PERSONAL", color = HeroLifeColors.Crystal, fontSize = 10.sp)
            TextButton(onClick = onExit) { Text("خروج") }
        }

        BattleMap(
            modifier = Modifier.fillMaxWidth().height(360.dp),
            minionCount = tasks.count { !it.done }
        )

        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Minion نزدیک", color = HeroLifeColors.GoldBright, fontWeight = FontWeight.Bold)
            val selected = tasks.firstOrNull { it.id == selectedId && !it.done }
                ?: tasks.firstOrNull { !it.done }

            if (selected == null) {
                Text("همه کارهای این نبرد انجام شده‌اند.", color = HeroLifeColors.Success)
            } else {
                Text(selected.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Button(onClick = {
                        onTaskDone(selected.id)
                        selectedId = tasks.firstOrNull { !it.done && it.id != selected.id }?.id
                    }) { Text("⚔ انجام") }
                    OutlinedButton(onClick = {}) { Text("بعداً") }
                    OutlinedButton(onClick = {}) { Text("تعویض") }
                }
            }
        }
    }
}

@Composable
private fun BattleMap(modifier: Modifier, minionCount: Int) {
    Canvas(modifier = modifier) {
        drawRect(Color(0xFF0B2232))
        val laneColors = listOf(
            HeroLifeColors.Crystal.copy(alpha=.42f),
            HeroLifeColors.Gold.copy(alpha=.33f),
            Color(0xFF5BCF8C).copy(alpha=.33f)
        )
        val ys = listOf(size.height*.25f, size.height*.50f, size.height*.75f)
        ys.forEachIndexed { index, y ->
            drawLine(laneColors[index], Offset(0f,y), Offset(size.width,y), 18.dp.toPx())
            drawLine(Color.White.copy(alpha=.12f), Offset(0f,y), Offset(size.width,y), 2.dp.toPx())
        }

        drawRect(HeroLifeColors.CrystalDark, Offset(18.dp.toPx(), size.height*.43f), Size(38.dp.toPx(), 70.dp.toPx()))
        drawRect(HeroLifeColors.DangerDark, Offset(size.width-56.dp.toPx(), size.height*.43f), Size(38.dp.toPx(), 70.dp.toPx()))

        val count = minionCount.coerceAtMost(8)
        repeat(count) { i ->
            val lane = i % 3
            val x = size.width * (.28f + (i % 4) * .12f)
            val y = ys[lane]
            drawCircle(HeroLifeColors.Danger, 9.dp.toPx(), Offset(x,y))
        }

        val hero = Offset(size.width*.18f, size.height*.50f)
        drawCircle(HeroLifeColors.CrystalBright.copy(alpha=.18f), 31.dp.toPx(), hero)
        drawCircle(HeroLifeColors.CrystalBright, 17.dp.toPx(), hero)
        drawCircle(HeroLifeColors.GoldBright, 4.dp.toPx(), Offset(hero.x+10.dp.toPx(), hero.y-7.dp.toPx()))

        val center = Offset(size.width*.83f, size.height*.16f)
        drawCircle(Color(0xFF06101E), 38.dp.toPx(), center)
        drawCircle(HeroLifeColors.Crystal.copy(alpha=.5f), 38.dp.toPx(), center, style=Stroke(1.dp.toPx()))
        repeat(3) { i ->
            val angle = i * 2.094
            val p = Offset(
                center.x + cos(angle).toFloat()*22.dp.toPx(),
                center.y + sin(angle).toFloat()*22.dp.toPx()
            )
            drawCircle(laneColors[i], 5.dp.toPx(), p)
        }
    }
}
