package com.herolife.feature.achievements.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.achievements.model.MatchMvpResult

@Composable
fun MvpResultCard(
    result: MatchMvpResult,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = if (result.isMvp) {
                "MVP"
            } else {
                "عملکرد Match"
            },
            style = MaterialTheme.typography.headlineLarge,
            color = if (result.isMvp) {
                HeroLifeColors.GoldBright
            } else {
                HeroLifeColors.Crystal
            },
            fontWeight = FontWeight.Black
        )

        Text(
            text = "${result.grade} • ${result.score}/100",
            style = MaterialTheme.typography.titleLarge,
            color = HeroLifeColors.TextPrimary
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            ScoreRow(
                "تکمیل کار",
                result.breakdown.completionScore
            )
            ScoreRow(
                "نتیجه نبرد",
                result.breakdown.victoryScore
            )
            ScoreRow(
                "Streak",
                result.breakdown.streakScore
            )
            ScoreRow(
                "سرعت شروع",
                result.breakdown.efficiencyScore
            )
            ScoreRow(
                "ثبات",
                result.breakdown.consistencyScore
            )
        }

        Text(
            text = result.summary,
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextSecondary
        )
    }
}

@Composable
private fun ScoreRow(
    title: String,
    value: Int
) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            color = HeroLifeColors.TextSecondary
        )

        Text(
            text = value.toString(),
            color = HeroLifeColors.Crystal
        )
    }
}
