package com.herolife.feature.achievements.domain

import com.herolife.feature.achievements.model.MatchMvpResult
import com.herolife.feature.achievements.model.MatchPerformanceSnapshot
import com.herolife.feature.achievements.model.MvpScoreBreakdown
import kotlin.math.roundToInt

object MvpEngine {

    fun evaluate(
        snapshot: MatchPerformanceSnapshot,
        matchDurationMillis: Long = 30L * 60L * 1000L
    ): MatchMvpResult {
        require(matchDurationMillis > 0L)

        val completionScore =
            (snapshot.completedTasks * 12)
                .coerceAtMost(48)

        val victoryScore =
            if (snapshot.victory) 18 else 4

        val streakScore =
            (snapshot.longestStreak * 3)
                .coerceAtMost(15)

        val efficiencyScore =
            snapshot.firstCompletionMillis?.let { first ->
                val ratio =
                    1f -
                        (
                            first.toFloat() /
                                matchDurationMillis.toFloat()
                            )
                            .coerceIn(0f, 1f)

                (ratio * 12f)
                    .roundToInt()
                    .coerceIn(0, 12)
            } ?: 0

        val consistencyScore =
            when {
                snapshot.completedTasks >= 6 -> 7
                snapshot.completedTasks >= 4 -> 5
                snapshot.completedTasks >= 2 -> 3
                else -> 1
            }

        val breakdown =
            MvpScoreBreakdown(
                completionScore = completionScore,
                victoryScore = victoryScore,
                streakScore = streakScore,
                efficiencyScore = efficiencyScore,
                consistencyScore = consistencyScore
            )

        val score =
            breakdown.total.coerceIn(0, 100)

        val grade =
            when {
                score >= 90 -> "S+"
                score >= 80 -> "S"
                score >= 70 -> "A"
                score >= 60 -> "B"
                score >= 45 -> "C"
                else -> "D"
            }

        return MatchMvpResult(
            isMvp = score >= 80,
            grade = grade,
            score = score,
            breakdown = breakdown,
            summary = summaryFor(
                score = score,
                victory = snapshot.victory
            )
        )
    }

    private fun summaryFor(
        score: Int,
        victory: Boolean
    ): String =
        when {
            score >= 90 ->
                "اجرای بسیار قدرتمند؛ این Match در سطح قهرمانی بود."

            score >= 80 ->
                "عملکرد MVP؛ هم ریتم داشتی هم خروجی."

            victory ->
                "برد خوب؛ با چند اجرای بیشتر می‌توانی MVP شوی."

            score >= 60 ->
                "عملکرد قابل اتکا؛ هنوز جا برای فشار نهایی هست."

            else ->
                "این Match بیشتر برای ساختن ریتم بود تا رکورد."
        }
}
