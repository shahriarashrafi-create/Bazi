package com.herolife.feature.achievements.domain

import com.herolife.feature.achievements.model.AchievementDefinition
import com.herolife.feature.achievements.model.AchievementProgress
import com.herolife.feature.achievements.model.AchievementType

data class AchievementMetricEvent(
    val type: AchievementType,
    val delta: Long,
    val absoluteValue: Long? = null,
    val occurredAtMillis: Long
) {
    init {
        require(delta >= 0L)
        require(absoluteValue == null || absoluteValue >= 0L)
        require(occurredAtMillis >= 0L)
    }
}

data class AchievementEvaluation(
    val progress: AchievementProgress,
    val newlyUnlocked: Boolean
)

object AchievementEngine {

    fun apply(
        definition: AchievementDefinition,
        progress: AchievementProgress,
        event: AchievementMetricEvent
    ): AchievementEvaluation {
        if (
            definition.type != event.type ||
            progress.claimed
        ) {
            return AchievementEvaluation(
                progress = progress,
                newlyUnlocked = false
            )
        }

        val nextValue =
            event.absoluteValue
                ?: (progress.current + event.delta)

        val clamped =
            nextValue.coerceAtMost(definition.target)

        val shouldUnlock =
            !progress.unlocked &&
                clamped >= definition.target

        val nextProgress =
            progress.copy(
                current = clamped,
                unlocked = progress.unlocked || shouldUnlock,
                unlockedAtMillis = if (shouldUnlock) {
                    event.occurredAtMillis
                } else {
                    progress.unlockedAtMillis
                }
            )

        return AchievementEvaluation(
            progress = nextProgress,
            newlyUnlocked = shouldUnlock
        )
    }

    fun claim(
        definition: AchievementDefinition,
        progress: AchievementProgress
    ): AchievementProgress {
        require(progress.achievementId == definition.id)
        require(progress.unlocked)

        return progress.copy(
            claimed = true
        )
    }
}
