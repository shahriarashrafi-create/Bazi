package com.herolife.feature.achievements.model

data class MvpScoreBreakdown(
    val completionScore: Int,
    val victoryScore: Int,
    val streakScore: Int,
    val efficiencyScore: Int,
    val consistencyScore: Int
) {
    val total: Int
        get() =
            completionScore +
                victoryScore +
                streakScore +
                efficiencyScore +
                consistencyScore
}

data class MatchMvpResult(
    val isMvp: Boolean,
    val grade: String,
    val score: Int,
    val breakdown: MvpScoreBreakdown,
    val summary: String
)
