package com.herolife.feature.achievements.domain

import com.herolife.feature.achievements.model.AchievementDefinition
import com.herolife.feature.achievements.model.AchievementPeriod
import com.herolife.feature.achievements.model.AchievementTier
import com.herolife.feature.achievements.model.AchievementType
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource

object AchievementCatalog {

    fun defaults(): List<AchievementDefinition> =
        listOf(
            AchievementDefinition(
                id = "daily_3_tasks",
                title = "شروع قدرتمند",
                description = "امروز ۳ کار را کامل کن.",
                period = AchievementPeriod.DAILY,
                type = AchievementType.TASKS_COMPLETED,
                target = 3L,
                tier = AchievementTier.BRONZE,
                reward = reward(
                    xp = 30,
                    gold = 15
                ),
                badgeKey = "badge_daily_three"
            ),
            AchievementDefinition(
                id = "daily_6_tasks",
                title = "روز مسلط",
                description = "امروز ۶ کار را کامل کن.",
                period = AchievementPeriod.DAILY,
                type = AchievementType.TASKS_COMPLETED,
                target = 6L,
                tier = AchievementTier.SILVER,
                reward = reward(
                    xp = 70,
                    gold = 35
                ),
                badgeKey = "badge_daily_six"
            ),
            AchievementDefinition(
                id = "weekly_5_wins",
                title = "فرمانده هفته",
                description = "در یک هفته ۵ نبرد را ببر.",
                period = AchievementPeriod.WEEKLY,
                type = AchievementType.MATCHES_WON,
                target = 5L,
                tier = AchievementTier.GOLD,
                reward = RewardGrant(
                    source = RewardSource.WEEKLY_GOAL,
                    xp = 220,
                    gold = 100,
                    diamonds = 1,
                    reason = "فرمانده هفته"
                ),
                badgeKey = "badge_weekly_commander",
                titleUnlock = "فرمانده"
            ),
            AchievementDefinition(
                id = "monthly_20_wins",
                title = "سلطان میدان",
                description = "در یک ماه ۲۰ نبرد را ببر.",
                period = AchievementPeriod.MONTHLY,
                type = AchievementType.MATCHES_WON,
                target = 20L,
                tier = AchievementTier.CRYSTAL,
                reward = RewardGrant(
                    source = RewardSource.MONTHLY_GOAL,
                    xp = 700,
                    gold = 320,
                    diamonds = 1,
                    reason = "سلطان میدان"
                ),
                badgeKey = "badge_monthly_ruler",
                titleUnlock = "سلطان"
            ),
            AchievementDefinition(
                id = "long_1000_tasks",
                title = "ماشین اجرا",
                description = "در مجموع ۱۰۰۰ کار را کامل کن.",
                period = AchievementPeriod.LONG_TERM,
                type = AchievementType.TASKS_COMPLETED,
                target = 1000L,
                tier = AchievementTier.LEGENDARY,
                reward = RewardGrant(
                    source = RewardSource.MILESTONE,
                    xp = 1500,
                    gold = 700,
                    diamonds = 1,
                    reason = "۱۰۰۰ اجرای واقعی"
                ),
                badgeKey = "badge_execution_1000",
                titleUnlock = "افسانه اجرا"
            ),
            AchievementDefinition(
                id = "long_streak_12",
                title = "توقف‌ناپذیر",
                description = "به زنجیره ۱۲ تکمیل واقعی برس.",
                period = AchievementPeriod.LONG_TERM,
                type = AchievementType.STREAK,
                target = 12L,
                tier = AchievementTier.CRYSTAL,
                reward = RewardGrant(
                    source = RewardSource.ACHIEVEMENT,
                    xp = 300,
                    gold = 140,
                    diamonds = 1,
                    reason = "Streak 12"
                ),
                badgeKey = "badge_unstoppable",
                titleUnlock = "توقف‌ناپذیر"
            )
        )

    private fun reward(
        xp: Int,
        gold: Int
    ): RewardGrant =
        RewardGrant(
            source = RewardSource.ACHIEVEMENT,
            xp = xp,
            gold = gold,
            diamonds = 0,
            reason = "دستاورد"
        )
}
