package com.herolife.feature.achievements.model

enum class RecordType {
    MOST_TASKS_IN_MATCH,
    MOST_XP_IN_MATCH,
    MOST_GOLD_IN_MATCH,
    LONGEST_STREAK,
    FASTEST_FIRST_COMPLETION,
    MOST_MATCH_WINS_IN_DAY,
    BEST_WEEK,
    BEST_MONTH
}

data class PersonalRecord(
    val type: RecordType,
    val value: Long,
    val achievedAtMillis: Long,
    val matchId: String? = null
) {
    init {
        require(value >= 0L)
        require(achievedAtMillis >= 0L)
    }
}

data class RecordUpdate(
    val record: PersonalRecord,
    val isNewRecord: Boolean,
    val previousValue: Long?
)

data class MatchPerformanceSnapshot(
    val matchId: String,
    val completedTasks: Int,
    val earnedXp: Int,
    val earnedGold: Int,
    val longestStreak: Int,
    val firstCompletionMillis: Long?,
    val victory: Boolean
) {
    init {
        require(matchId.isNotBlank())
        require(completedTasks >= 0)
        require(earnedXp >= 0)
        require(earnedGold >= 0)
        require(longestStreak >= 0)
        require(firstCompletionMillis == null || firstCompletionMillis >= 0L)
    }
}
