package com.herolife.feature.achievements.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifePanel
import com.herolife.feature.achievements.model.PersonalRecord

@Composable
fun RecordCard(
    record: PersonalRecord,
    modifier: Modifier = Modifier
) {
    HeroLifePanel(
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = titleFor(record),
                style = MaterialTheme.typography.titleMedium,
                color = HeroLifeColors.TextPrimary
            )

            Text(
                text = record.value.toString(),
                style = MaterialTheme.typography.titleLarge,
                color = HeroLifeColors.GoldBright
            )
        }
    }
}

private fun titleFor(
    record: PersonalRecord
): String =
    when (record.type.name) {
        "MOST_TASKS_IN_MATCH" -> "بیشترین کار در یک Match"
        "MOST_XP_IN_MATCH" -> "بیشترین XP در یک Match"
        "MOST_GOLD_IN_MATCH" -> "بیشترین Gold در یک Match"
        "LONGEST_STREAK" -> "بیشترین Streak"
        "FASTEST_FIRST_COMPLETION" -> "سریع‌ترین اولین تکمیل"
        "MOST_MATCH_WINS_IN_DAY" -> "بیشترین برد روزانه"
        "BEST_WEEK" -> "بهترین هفته"
        else -> "بهترین ماه"
    }
