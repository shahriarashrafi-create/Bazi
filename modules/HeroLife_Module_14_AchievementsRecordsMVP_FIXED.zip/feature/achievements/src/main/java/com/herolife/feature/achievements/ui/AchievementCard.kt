package com.herolife.feature.achievements.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeRadius
import com.herolife.feature.achievements.model.AchievementCardState
import com.herolife.feature.achievements.model.AchievementTier

@Composable
fun AchievementCard(
    state: AchievementCardState,
    onClaim: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent =
        tierColor(state.definition.tier)

    val shape =
        RoundedCornerShape(HeroLifeRadius.hero)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                HeroLifeColors.DeepNavy
            )
            .border(
                width = 1.dp,
                color = accent.copy(alpha = 0.55f),
                shape = shape
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = state.definition.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = HeroLifeColors.TextPrimary
            )

            Text(
                text = state.definition.tier.name,
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )
        }

        Text(
            text = state.definition.description,
            style = MaterialTheme.typography.bodyMedium,
            color = HeroLifeColors.TextSecondary
        )

        LinearProgressIndicator(
            progress = {
                state.progressFraction
            },
            modifier = Modifier.fillMaxWidth(),
            color = accent,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        Text(
            text =
                "${state.progress.current} / ${state.definition.target}",
            style = MaterialTheme.typography.bodySmall,
            color = HeroLifeColors.TextMuted
        )

        if (state.progress.unlocked && !state.progress.claimed) {
            Button(
                onClick = onClaim,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accent,
                    contentColor = HeroLifeColors.Void
                )
            ) {
                Text("دریافت پاداش")
            }
        }

        if (state.progress.claimed) {
            Text(
                text = "پاداش دریافت شد",
                color = HeroLifeColors.Success,
                style = MaterialTheme.typography.labelLarge
            )
        }

        state.definition.titleUnlock?.let { title ->
            Text(
                text = "عنوان قابل آزادسازی: $title",
                color = HeroLifeColors.Gold,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun tierColor(
    tier: AchievementTier
): Color =
    when (tier) {
        AchievementTier.BRONZE -> HeroLifeColors.Warning
        AchievementTier.SILVER -> HeroLifeColors.TextSecondary
        AchievementTier.GOLD -> HeroLifeColors.Gold
        AchievementTier.CRYSTAL -> HeroLifeColors.Crystal
        AchievementTier.LEGENDARY -> HeroLifeColors.GoldBright
    }
