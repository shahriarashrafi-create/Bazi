package com.herolife.feature.achievements.domain

import com.herolife.feature.achievements.model.MatchPerformanceSnapshot
import com.herolife.feature.achievements.model.PersonalRecord
import com.herolife.feature.achievements.model.RecordType
import com.herolife.feature.achievements.model.RecordUpdate

object RecordEngine {

    fun evaluateMatch(
        existing: Map<RecordType, PersonalRecord>,
        snapshot: MatchPerformanceSnapshot,
        achievedAtMillis: Long
    ): List<RecordUpdate> {
        val candidates =
            buildList {
                add(
                    candidate(
                        RecordType.MOST_TASKS_IN_MATCH,
                        snapshot.completedTasks.toLong(),
                        snapshot,
                        achievedAtMillis
                    )
                )
                add(
                    candidate(
                        RecordType.MOST_XP_IN_MATCH,
                        snapshot.earnedXp.toLong(),
                        snapshot,
                        achievedAtMillis
                    )
                )
                add(
                    candidate(
                        RecordType.MOST_GOLD_IN_MATCH,
                        snapshot.earnedGold.toLong(),
                        snapshot,
                        achievedAtMillis
                    )
                )
                add(
                    candidate(
                        RecordType.LONGEST_STREAK,
                        snapshot.longestStreak.toLong(),
                        snapshot,
                        achievedAtMillis
                    )
                )

                val first =
                    snapshot.firstCompletionMillis

                if (first != null) {
                    add(
                        candidate(
                            RecordType.FASTEST_FIRST_COMPLETION,
                            first,
                            snapshot,
                            achievedAtMillis
                        )
                    )
                }
            }

        return candidates.map { candidate ->
            val old = existing[candidate.type]
            val newRecord =
                when (candidate.type) {
                    RecordType.FASTEST_FIRST_COMPLETION -> {
                        old == null ||
                            candidate.value < old.value
                    }

                    else -> {
                        old == null ||
                            candidate.value > old.value
                    }
                }

            RecordUpdate(
                record = if (newRecord) candidate else old ?: candidate,
                isNewRecord = newRecord,
                previousValue = old?.value
            )
        }
    }

    private fun candidate(
        type: RecordType,
        value: Long,
        snapshot: MatchPerformanceSnapshot,
        achievedAtMillis: Long
    ): PersonalRecord =
        PersonalRecord(
            type = type,
            value = value,
            achievedAtMillis = achievedAtMillis,
            matchId = snapshot.matchId
        )
}
