package com.herolife.feature.achievements.model

import com.herolife.feature.economy.model.RewardGrant

enum class AchievementPeriod {
    ALL,
    DAILY,
    WEEKLY,
    MONTHLY,
    LONG_TERM
}

enum class AchievementType {
    TASKS_COMPLETED,
    MATCHES_PLAYED,
    MATCHES_WON,
    STREAK,
    XP_EARNED,
    GOLD_EARNED,
    NETWORKING_ACTIONS,
    PERSONAL_GROWTH,
    TIME_DISCIPLINE,
    PERFECT_MATCH,
    TOWER_PRESSURE,
    RECORD
}

enum class AchievementTier {
    BRONZE,
    SILVER,
    GOLD,
    CRYSTAL,
    LEGENDARY
}

data class AchievementDefinition(
    val id: String,
    val title: String,
    val description: String,
    val period: AchievementPeriod,
    val type: AchievementType,
    val target: Long,
    val tier: AchievementTier,
    val reward: RewardGrant,
    val badgeKey: String,
    val titleUnlock: String? = null
) {
    init {
        require(id.isNotBlank())
        require(title.isNotBlank())
        require(target > 0L)
        require(badgeKey.isNotBlank())
    }
}

data class AchievementProgress(
    val achievementId: String,
    val current: Long = 0L,
    val unlocked: Boolean = false,
    val claimed: Boolean = false,
    val unlockedAtMillis: Long? = null
) {
    init {
        require(achievementId.isNotBlank())
        require(current >= 0L)
    }
}

data class AchievementCardState(
    val definition: AchievementDefinition,
    val progress: AchievementProgress
) {
    val progressFraction: Float
        get() = (
            progress.current.toDouble() /
                definition.target.toDouble()
            )
            .toFloat()
            .coerceIn(0f, 1f)
}
