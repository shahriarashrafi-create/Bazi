package com.herolife.feature.achievements.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.feature.achievements.model.AchievementPeriod

@Composable
fun AchievementTabs(
    selected: AchievementPeriod,
    onSelected: (AchievementPeriod) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.horizontalScroll(
            rememberScrollState()
        ),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AchievementPeriod.values().forEach { period ->
            FilterChip(
                selected = selected == period,
                onClick = {
                    onSelected(period)
                },
                label = {
                    Text(
                        when (period) {
                            AchievementPeriod.ALL -> "همه"
                            AchievementPeriod.DAILY -> "روزانه"
                            AchievementPeriod.WEEKLY -> "هفتگی"
                            AchievementPeriod.MONTHLY -> "ماهانه"
                            AchievementPeriod.LONG_TERM -> "بلندمدت"
                        }
                    )
                }
            )
        }
    }
}
