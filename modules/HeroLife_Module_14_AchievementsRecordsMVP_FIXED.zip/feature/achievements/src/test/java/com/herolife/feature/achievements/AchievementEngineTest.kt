package com.herolife.feature.achievements

import com.herolife.feature.achievements.domain.AchievementEngine
import com.herolife.feature.achievements.domain.AchievementMetricEvent
import com.herolife.feature.achievements.model.AchievementDefinition
import com.herolife.feature.achievements.model.AchievementPeriod
import com.herolife.feature.achievements.model.AchievementProgress
import com.herolife.feature.achievements.model.AchievementTier
import com.herolife.feature.achievements.model.AchievementType
import com.herolife.feature.economy.model.RewardGrant
import com.herolife.feature.economy.model.RewardSource
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AchievementEngineTest {

    private val definition =
        AchievementDefinition(
            id = "a1",
            title = "Test",
            description = "",
            period = AchievementPeriod.DAILY,
            type = AchievementType.TASKS_COMPLETED,
            target = 3L,
            tier = AchievementTier.BRONZE,
            reward = RewardGrant(
                source = RewardSource.ACHIEVEMENT,
                xp = 10
            ),
            badgeKey = "badge"
        )

    @Test
    fun unlocksAtTarget() {
        val result =
            AchievementEngine.apply(
                definition = definition,
                progress = AchievementProgress(
                    achievementId = "a1",
                    current = 2
                ),
                event = AchievementMetricEvent(
                    type = AchievementType.TASKS_COMPLETED,
                    delta = 1,
                    occurredAtMillis = 100L
                )
            )

        assertTrue(result.progress.unlocked)
        assertTrue(result.newlyUnlocked)
    }

    @Test
    fun unrelatedMetricDoesNothing() {
        val result =
            AchievementEngine.apply(
                definition = definition,
                progress = AchievementProgress(
                    achievementId = "a1"
                ),
                event = AchievementMetricEvent(
                    type = AchievementType.GOLD_EARNED,
                    delta = 100,
                    occurredAtMillis = 100L
                )
            )

        assertFalse(result.progress.unlocked)
    }
}
