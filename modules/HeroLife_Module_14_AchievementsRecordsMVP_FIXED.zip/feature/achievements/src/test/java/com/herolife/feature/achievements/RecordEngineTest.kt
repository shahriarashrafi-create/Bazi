package com.herolife.feature.achievements

import com.herolife.feature.achievements.domain.RecordEngine
import com.herolife.feature.achievements.model.MatchPerformanceSnapshot
import com.herolife.feature.achievements.model.PersonalRecord
import com.herolife.feature.achievements.model.RecordType
import org.junit.Assert.assertTrue
import org.junit.Test

class RecordEngineTest {

    @Test
    fun higherTaskCountCreatesRecord() {
        val existing =
            mapOf(
                RecordType.MOST_TASKS_IN_MATCH to
                    PersonalRecord(
                        type = RecordType.MOST_TASKS_IN_MATCH,
                        value = 4,
                        achievedAtMillis = 1L
                    )
            )

        val updates =
            RecordEngine.evaluateMatch(
                existing = existing,
                snapshot = MatchPerformanceSnapshot(
                    matchId = "m1",
                    completedTasks = 6,
                    earnedXp = 100,
                    earnedGold = 50,
                    longestStreak = 3,
                    firstCompletionMillis = 60_000L,
                    victory = true
                ),
                achievedAtMillis = 2L
            )

        assertTrue(
            updates.first {
                it.record.type ==
                    RecordType.MOST_TASKS_IN_MATCH
            }.isNewRecord
        )
    }
}
