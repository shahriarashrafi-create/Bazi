package com.herolife.feature.achievements

import com.herolife.feature.achievements.domain.MvpEngine
import com.herolife.feature.achievements.model.MatchPerformanceSnapshot
import org.junit.Assert.assertTrue
import org.junit.Test

class MvpEngineTest {

    @Test
    fun strongMatchCanBecomeMvp() {
        val result =
            MvpEngine.evaluate(
                MatchPerformanceSnapshot(
                    matchId = "mvp",
                    completedTasks = 6,
                    earnedXp = 150,
                    earnedGold = 80,
                    longestStreak = 6,
                    firstCompletionMillis = 45_000L,
                    victory = true
                )
            )

        assertTrue(result.isMvp)
        assertTrue(result.score >= 80)
    }
}
