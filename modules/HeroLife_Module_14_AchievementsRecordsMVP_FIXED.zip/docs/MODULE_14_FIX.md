# Module 14 FIX

Fixed `AchievementRewardBridge.kt` import for `EconomyApplyResult`.

Module 13 declares `EconomyApplyResult` in `com.herolife.feature.economy.domain`, not `.model`.
