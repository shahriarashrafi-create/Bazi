# Module 14/20 — Achievements / Records / MVP

Independent module: `:feature:achievements`

## Implemented

- Achievement periods:
  - All
  - Daily
  - Weekly
  - Monthly
  - Long-term
- Achievement definitions
- Progress tracking
- Unlock state
- Claim state
- Reward bridge into Economy
- Badge contracts
- Title unlock contracts
- Bronze / Silver / Gold / Crystal / Legendary tiers
- Default achievement catalog
- Personal record system
- Match performance snapshots
- New-record detection
- Fastest-first-completion record
- MVP scoring
- MVP grade S+ / S / A / B / C / D
- MVP breakdown
- Achievement tabs
- Achievement card
- Record card
- MVP result card
- Unit tests

## Economy connection

Achievements can grant XP / Gold and, for sufficiently important goals, rare Diamond.

Reward claiming is routed through Module 13 EconomyEngine, so caps and Diamond policy still apply.

## Next

Module 15 — Networking CRM
will implement:
- prospect records
- networking action types
- actor/referrer
- advisor
- result
- follow-ups
- next two actions
- pipeline stages
- activity history
