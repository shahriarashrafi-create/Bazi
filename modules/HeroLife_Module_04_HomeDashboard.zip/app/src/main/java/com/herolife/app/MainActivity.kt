package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.herolife.core.designsystem.HeroLifeTheme
import com.herolife.feature.home.model.HomeDashboardState
import com.herolife.feature.home.ui.HomeDashboardScreen
import com.herolife.feature.profile.model.PlayerProfile

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HeroLifeTheme {
                HomeDashboardScreen(
                    state = HomeDashboardState(
                        profile = PlayerProfile(
                            id = "local-player",
                            displayName = "بازیکن",
                            heroTitle = "جنگنده",
                            level = 1,
                            xp = 25,
                            xpToNextLevel = 100,
                            gold = 120,
                            diamonds = 1
                        ),
                        activeTasks = 8,
                        completedToday = 3,
                        networkingActions = 5,
                        nextEventTitle = "ایونت بعدی تیم",
                        nextEventProgress = 40
                    ),
                    onStartGame = {
                        // Match Engine در Module 07 متصل می‌شود.
                    }
                )
            }
        }
    }
}
