package com.herolife.feature.home.model

import com.herolife.feature.profile.model.PlayerProfile

data class HomeDashboardState(
    val profile: PlayerProfile,
    val activeTasks: Int,
    val completedToday: Int,
    val networkingActions: Int,
    val nextEventTitle: String,
    val nextEventProgress: Int
) {
    init {
        require(activeTasks >= 0)
        require(completedToday >= 0)
        require(networkingActions >= 0)
        require(nextEventProgress in 0..100)
    }
}
