package com.herolife.feature.home

import com.herolife.feature.home.model.HomeDashboardState
import com.herolife.feature.profile.model.PlayerProfile
import org.junit.Assert.assertEquals
import org.junit.Test

class HomeDashboardStateTest {

    @Test
    fun state_keepsDashboardValues() {
        val profile = PlayerProfile(
            id = "local-player",
            displayName = "بازیکن",
            heroTitle = "جنگنده",
            level = 1,
            xp = 20,
            xpToNextLevel = 100,
            gold = 50,
            diamonds = 1
        )

        val state = HomeDashboardState(
            profile = profile,
            activeTasks = 8,
            completedToday = 3,
            networkingActions = 5,
            nextEventTitle = "ایونت بعدی",
            nextEventProgress = 40
        )

        assertEquals(8, state.activeTasks)
        assertEquals(40, state.nextEventProgress)
    }
}
