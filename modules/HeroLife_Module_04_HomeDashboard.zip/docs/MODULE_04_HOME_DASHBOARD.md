# Module 04/20 — Home Dashboard

ماژول مستقل:

`:feature:home`

## مسئولیت‌ها

- Home Dashboard فارسی و RTL
- اتصال Profile به Home
- نمایش Level / XP / Gold / Diamond
- خلاصه کارهای فعال
- خلاصه انجام‌های امروز
- خلاصه اقدامات شبکه‌سازی
- کارت رویداد بعدی
- Hero placeholder
- CTA اصلی «شروع بازی ۳۰ دقیقه‌ای»
- Bottom Navigation هدف نهایی

## وابستگی‌ها

- `:core:designsystem`
- `:feature:profile`

ماژول Home به `app` وابسته نیست.

## نکته معماری

`app/MainActivity.kt` فقط Composition Root است و Home را نمایش می‌دهد.
منطق Battle هنوز وارد Home نشده و در Module 07 به CTA متصل خواهد شد.
