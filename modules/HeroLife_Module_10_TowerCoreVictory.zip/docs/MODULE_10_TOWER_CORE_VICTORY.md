# Module 10/20 — Tower / Core / Victory / Defeat

Independent module: `:feature:objectives`

## Gameplay implemented

- Player Tower HP
- Player Core HP
- Enemy Tower HP
- Enemy Core HP
- Structure destruction
- Task completion damages enemy objective
- Enemy Core is locked behind Enemy Tower
- Later causes small incoming pressure
- Remove From Match causes stronger incoming pressure
- Overflow damage when a tower falls
- Victory when Enemy Core is destroyed
- Defeat when Player Core is destroyed
- Timeout evaluation
- Damage event model
- MatchEngine bridge
- MinionResolution bridge
- Cinematic structure HP UI
- Victory / Defeat overlay
- Unit tests

## Balance philosophy

The numbers are deliberately forgiving:
- Completing tasks should strongly favor victory.
- "Later" is a meaningful but small penalty.
- "Remove" is stronger, but not catastrophic.
- Punishment is not designed to make fake completion attractive.

These values are defaults and can later be tuned by the balance layer without changing the objective API.

## Next modules

11 — Combat VFX & Animation
12 — Sound & Female Announcer
13 — Reward Economy & Balance
