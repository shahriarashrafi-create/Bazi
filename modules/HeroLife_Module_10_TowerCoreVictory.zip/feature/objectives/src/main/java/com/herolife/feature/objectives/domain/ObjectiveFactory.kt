package com.herolife.feature.objectives.domain

import com.herolife.feature.objectives.model.ObjectiveOwner
import com.herolife.feature.objectives.model.ObjectiveRules
import com.herolife.feature.objectives.model.ObjectiveState
import com.herolife.feature.objectives.model.StructureState
import com.herolife.feature.objectives.model.StructureType

object ObjectiveFactory {

    fun create(
        rules: ObjectiveRules = ObjectiveRules()
    ): ObjectiveState =
        ObjectiveState(
            playerTower = StructureState(
                id = "player_tower",
                owner = ObjectiveOwner.PLAYER,
                type = StructureType.TOWER,
                maxHp = rules.playerTowerMaxHp,
                currentHp = rules.playerTowerMaxHp
            ),
            playerCore = StructureState(
                id = "player_core",
                owner = ObjectiveOwner.PLAYER,
                type = StructureType.CORE,
                maxHp = rules.playerCoreMaxHp,
                currentHp = rules.playerCoreMaxHp
            ),
            enemyTower = StructureState(
                id = "enemy_tower",
                owner = ObjectiveOwner.ENEMY,
                type = StructureType.TOWER,
                maxHp = rules.enemyTowerMaxHp,
                currentHp = rules.enemyTowerMaxHp
            ),
            enemyCore = StructureState(
                id = "enemy_core",
                owner = ObjectiveOwner.ENEMY,
                type = StructureType.CORE,
                maxHp = rules.enemyCoreMaxHp,
                currentHp = rules.enemyCoreMaxHp
            )
        )
}
