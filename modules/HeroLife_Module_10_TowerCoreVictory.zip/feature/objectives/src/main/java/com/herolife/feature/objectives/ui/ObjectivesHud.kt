package com.herolife.feature.objectives.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import com.herolife.feature.objectives.model.ObjectiveState

@Composable
fun ObjectivesHud(
    state: ObjectiveState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StructureHealthBar(
            structure = state.enemyTower
        )

        StructureHealthBar(
            structure = state.enemyCore
        )

        StructureHealthBar(
            structure = state.playerTower
        )

        StructureHealthBar(
            structure = state.playerCore
        )
    }
}
