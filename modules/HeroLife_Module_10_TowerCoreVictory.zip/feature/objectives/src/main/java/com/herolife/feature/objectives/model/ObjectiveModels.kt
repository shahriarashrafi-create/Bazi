package com.herolife.feature.objectives.model

enum class ObjectiveOwner {
    PLAYER,
    ENEMY
}

enum class StructureType {
    TOWER,
    CORE
}

enum class ObjectiveStatus {
    ACTIVE,
    DESTROYED
}

enum class MatchOutcome {
    IN_PROGRESS,
    VICTORY,
    DEFEAT
}

data class StructureState(
    val id: String,
    val owner: ObjectiveOwner,
    val type: StructureType,
    val maxHp: Int,
    val currentHp: Int,
    val status: ObjectiveStatus = ObjectiveStatus.ACTIVE
) {
    init {
        require(id.isNotBlank())
        require(maxHp > 0)
        require(currentHp in 0..maxHp)
        require(
            (currentHp == 0 && status == ObjectiveStatus.DESTROYED) ||
            (currentHp > 0 && status == ObjectiveStatus.ACTIVE)
        )
    }

    val hpFraction: Float
        get() = currentHp.toFloat() / maxHp.toFloat()

    val destroyed: Boolean
        get() = status == ObjectiveStatus.DESTROYED
}

data class ObjectiveRules(
    val playerTowerMaxHp: Int = 100,
    val enemyTowerMaxHp: Int = 100,
    val playerCoreMaxHp: Int = 160,
    val enemyCoreMaxHp: Int = 160,

    val damagePerCompletedTaskToEnemyTower: Int = 34,
    val damagePerCompletedTaskToEnemyCore: Int = 24,

    val laterDamageToPlayerTower: Int = 6,
    val removeDamageToPlayerTower: Int = 14,

    val overflowDamageMultiplierPercent: Int = 65
) {
    init {
        require(playerTowerMaxHp > 0)
        require(enemyTowerMaxHp > 0)
        require(playerCoreMaxHp > 0)
        require(enemyCoreMaxHp > 0)
        require(damagePerCompletedTaskToEnemyTower > 0)
        require(damagePerCompletedTaskToEnemyCore > 0)
        require(laterDamageToPlayerTower >= 0)
        require(removeDamageToPlayerTower >= laterDamageToPlayerTower)
        require(overflowDamageMultiplierPercent in 0..100)
    }
}

data class ObjectiveState(
    val playerTower: StructureState,
    val playerCore: StructureState,
    val enemyTower: StructureState,
    val enemyCore: StructureState,
    val outcome: MatchOutcome = MatchOutcome.IN_PROGRESS,
    val totalDamageDealt: Int = 0,
    val totalDamageReceived: Int = 0
)

data class DamageEvent(
    val amount: Int,
    val targetStructureId: String,
    val source: String
) {
    init {
        require(amount >= 0)
        require(targetStructureId.isNotBlank())
        require(source.isNotBlank())
    }
}
