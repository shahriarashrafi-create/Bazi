package com.herolife.feature.objectives.domain

import com.herolife.feature.minions.model.EncounterAction
import com.herolife.feature.minions.model.MinionResolution
import com.herolife.feature.objectives.model.DamageEvent
import com.herolife.feature.objectives.model.ObjectiveState

/**
 * Converts Module 09 minion outcomes into structure consequences.
 *
 * COMPLETE -> player attacks enemy objective
 * LATER -> small incoming pressure
 * REMOVE -> stronger incoming pressure
 * SWAP -> no direct structure damage
 */
object ObjectiveResolutionBridge {

    fun apply(
        engine: ObjectiveEngine,
        state: ObjectiveState,
        resolution: MinionResolution
    ): Pair<ObjectiveState, DamageEvent?> =
        when (resolution.action) {
            EncounterAction.COMPLETE -> {
                val result = engine.onTaskCompleted(state)
                result.first to result.second
            }

            EncounterAction.LATER -> {
                val result = engine.onTaskLater(state)
                result.first to result.second
            }

            EncounterAction.REMOVE_FROM_MATCH -> {
                val result = engine.onTaskRemoved(state)
                result.first to result.second
            }

            EncounterAction.SWAP -> {
                state to null
            }
        }
}
