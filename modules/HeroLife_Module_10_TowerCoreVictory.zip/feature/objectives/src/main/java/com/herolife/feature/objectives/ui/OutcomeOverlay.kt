package com.herolife.feature.objectives.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeRadius
import com.herolife.feature.objectives.model.MatchOutcome

@Composable
fun OutcomeOverlay(
    outcome: MatchOutcome,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = outcome != MatchOutcome.IN_PROGRESS,
        enter = fadeIn() + scaleIn(initialScale = 0.92f)
    ) {
        val victory = outcome == MatchOutcome.VICTORY

        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(
                    RoundedCornerShape(
                        HeroLifeRadius.hero
                    )
                )
                .background(
                    Brush.verticalGradient(
                        listOf(
                            if (victory) {
                                HeroLifeColors.GoldDark.copy(alpha = 0.92f)
                            } else {
                                HeroLifeColors.DangerDark.copy(alpha = 0.92f)
                            },
                            HeroLifeColors.Void
                        )
                    )
                )
                .padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = if (victory) {
                    "VICTORY"
                } else {
                    "DEFEAT"
                },
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Black,
                color = if (victory) {
                    HeroLifeColors.GoldBright
                } else {
                    HeroLifeColors.Danger
                }
            )

            Text(
                text = if (victory) {
                    "مسیر را باز کردی و میدان را گرفتی."
                } else {
                    "این نبرد تمام شد؛ رکورد بعدی از همین‌جا ساخته می‌شود."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = HeroLifeColors.TextPrimary
            )
        }
    }
}
