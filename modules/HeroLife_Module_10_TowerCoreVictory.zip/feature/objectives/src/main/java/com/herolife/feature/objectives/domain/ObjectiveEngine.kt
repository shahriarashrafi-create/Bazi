package com.herolife.feature.objectives.domain

import com.herolife.feature.objectives.model.DamageEvent
import com.herolife.feature.objectives.model.MatchOutcome
import com.herolife.feature.objectives.model.ObjectiveRules
import com.herolife.feature.objectives.model.ObjectiveState
import com.herolife.feature.objectives.model.ObjectiveStatus
import com.herolife.feature.objectives.model.StructureState

/**
 * Pure deterministic structure/combat objective engine.
 *
 * Balance goals:
 * - Completing real tasks should make victory consistently achievable.
 * - "Later" causes a small consequence.
 * - "Remove from match" causes a stronger consequence.
 * - Punishment must never be so severe that fake completion becomes rational.
 * - Enemy core cannot be damaged before enemy tower is destroyed.
 * - Player core receives overflow pressure only after player tower falls.
 */
class ObjectiveEngine(
    private val rules: ObjectiveRules = ObjectiveRules()
) {

    fun onTaskCompleted(
        state: ObjectiveState
    ): Pair<ObjectiveState, DamageEvent> {
        if (state.outcome != MatchOutcome.IN_PROGRESS) {
            return state to DamageEvent(
                amount = 0,
                targetStructureId = state.enemyCore.id,
                source = "match_finished"
            )
        }

        return if (!state.enemyTower.destroyed) {
            damageEnemyTower(state)
        } else {
            damageEnemyCore(state)
        }
    }

    fun onTaskLater(
        state: ObjectiveState
    ): Pair<ObjectiveState, DamageEvent> =
        applyEnemyPressure(
            state = state,
            rawDamage = rules.laterDamageToPlayerTower,
            source = "task_later"
        )

    fun onTaskRemoved(
        state: ObjectiveState
    ): Pair<ObjectiveState, DamageEvent> =
        applyEnemyPressure(
            state = state,
            rawDamage = rules.removeDamageToPlayerTower,
            source = "task_removed_from_match"
        )

    fun evaluateTimeout(
        state: ObjectiveState
    ): ObjectiveState {
        if (state.outcome != MatchOutcome.IN_PROGRESS) {
            return state
        }

        val victoryScore =
            destroyedScore(state.enemyTower) +
            destroyedScore(state.enemyCore) +
            state.enemyCore.maxHp - state.enemyCore.currentHp

        val defeatScore =
            destroyedScore(state.playerTower) +
            destroyedScore(state.playerCore) +
            state.playerCore.maxHp - state.playerCore.currentHp

        return state.copy(
            outcome = if (victoryScore > defeatScore) {
                MatchOutcome.VICTORY
            } else {
                MatchOutcome.DEFEAT
            }
        )
    }

    private fun damageEnemyTower(
        state: ObjectiveState
    ): Pair<ObjectiveState, DamageEvent> {
        val damage = rules.damagePerCompletedTaskToEnemyTower
        val updated = applyDamage(
            structure = state.enemyTower,
            damage = damage
        )

        val next = state.copy(
            enemyTower = updated,
            totalDamageDealt = state.totalDamageDealt + damage
        ).resolveOutcome()

        return next to DamageEvent(
            amount = damage,
            targetStructureId = state.enemyTower.id,
            source = "completed_task"
        )
    }

    private fun damageEnemyCore(
        state: ObjectiveState
    ): Pair<ObjectiveState, DamageEvent> {
        val damage = rules.damagePerCompletedTaskToEnemyCore
        val updated = applyDamage(
            structure = state.enemyCore,
            damage = damage
        )

        val next = state.copy(
            enemyCore = updated,
            totalDamageDealt = state.totalDamageDealt + damage
        ).resolveOutcome()

        return next to DamageEvent(
            amount = damage,
            targetStructureId = state.enemyCore.id,
            source = "completed_task"
        )
    }

    private fun applyEnemyPressure(
        state: ObjectiveState,
        rawDamage: Int,
        source: String
    ): Pair<ObjectiveState, DamageEvent> {
        if (state.outcome != MatchOutcome.IN_PROGRESS) {
            return state to DamageEvent(
                amount = 0,
                targetStructureId = state.playerCore.id,
                source = "match_finished"
            )
        }

        return if (!state.playerTower.destroyed) {
            val towerAfter = applyDamage(
                structure = state.playerTower,
                damage = rawDamage
            )

            val overflow = (rawDamage - state.playerTower.currentHp)
                .coerceAtLeast(0)

            val overflowToCore =
                (overflow * rules.overflowDamageMultiplierPercent) / 100

            val coreAfter = if (overflowToCore > 0) {
                applyDamage(
                    structure = state.playerCore,
                    damage = overflowToCore
                )
            } else {
                state.playerCore
            }

            val actualReceived =
                (state.playerTower.currentHp - towerAfter.currentHp) +
                (state.playerCore.currentHp - coreAfter.currentHp)

            val next = state.copy(
                playerTower = towerAfter,
                playerCore = coreAfter,
                totalDamageReceived = state.totalDamageReceived + actualReceived
            ).resolveOutcome()

            next to DamageEvent(
                amount = actualReceived,
                targetStructureId = if (towerAfter.destroyed && overflowToCore > 0) {
                    state.playerCore.id
                } else {
                    state.playerTower.id
                },
                source = source
            )
        } else {
            val coreAfter = applyDamage(
                structure = state.playerCore,
                damage = rawDamage
            )

            val actualReceived =
                state.playerCore.currentHp - coreAfter.currentHp

            val next = state.copy(
                playerCore = coreAfter,
                totalDamageReceived = state.totalDamageReceived + actualReceived
            ).resolveOutcome()

            next to DamageEvent(
                amount = actualReceived,
                targetStructureId = state.playerCore.id,
                source = source
            )
        }
    }

    private fun applyDamage(
        structure: StructureState,
        damage: Int
    ): StructureState {
        if (structure.destroyed || damage <= 0) {
            return structure
        }

        val remaining = (structure.currentHp - damage)
            .coerceAtLeast(0)

        return structure.copy(
            currentHp = remaining,
            status = if (remaining == 0) {
                ObjectiveStatus.DESTROYED
            } else {
                ObjectiveStatus.ACTIVE
            }
        )
    }

    private fun ObjectiveState.resolveOutcome(): ObjectiveState =
        when {
            enemyCore.destroyed -> copy(
                outcome = MatchOutcome.VICTORY
            )

            playerCore.destroyed -> copy(
                outcome = MatchOutcome.DEFEAT
            )

            else -> this
        }

    private fun destroyedScore(
        structure: StructureState
    ): Int =
        if (structure.destroyed) {
            structure.maxHp * 2
        } else {
            0
        }
}
