package com.herolife.feature.objectives.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.core.designsystem.HeroLifeRadius
import com.herolife.feature.objectives.model.ObjectiveOwner
import com.herolife.feature.objectives.model.StructureState
import com.herolife.feature.objectives.model.StructureType

@Composable
fun StructureHealthBar(
    structure: StructureState,
    modifier: Modifier = Modifier
) {
    val accent: Color =
        if (structure.owner == ObjectiveOwner.PLAYER) {
            HeroLifeColors.Crystal
        } else {
            HeroLifeColors.Danger
        }

    val title = when {
        structure.owner == ObjectiveOwner.PLAYER &&
            structure.type == StructureType.TOWER -> "برج شما"

        structure.owner == ObjectiveOwner.PLAYER &&
            structure.type == StructureType.CORE -> "هسته شما"

        structure.owner == ObjectiveOwner.ENEMY &&
            structure.type == StructureType.TOWER -> "برج دشمن"

        else -> "هسته دشمن"
    }

    val shape = RoundedCornerShape(HeroLifeRadius.medium)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(HeroLifeColors.Overlay)
            .border(
                width = 1.dp,
                color = accent.copy(alpha = 0.42f),
                shape = shape
            )
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = HeroLifeColors.TextPrimary
            )

            Text(
                text = "${structure.currentHp}/${structure.maxHp}",
                style = MaterialTheme.typography.labelLarge,
                color = accent
            )
        }

        LinearProgressIndicator(
            progress = { structure.hpFraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(
                    RoundedCornerShape(
                        HeroLifeRadius.pill
                    )
                ),
            color = accent,
            trackColor = HeroLifeColors.SurfaceHighlight
        )

        if (structure.destroyed) {
            Text(
                text = "نابود شد",
                style = MaterialTheme.typography.bodySmall,
                color = HeroLifeColors.Warning
            )
        }
    }
}
