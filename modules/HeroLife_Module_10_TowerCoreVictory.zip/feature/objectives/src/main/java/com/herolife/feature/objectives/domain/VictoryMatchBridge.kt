package com.herolife.feature.objectives.domain

import com.herolife.feature.match.domain.MatchEngine
import com.herolife.feature.match.model.MatchState
import com.herolife.feature.objectives.model.MatchOutcome
import com.herolife.feature.objectives.model.ObjectiveState

/**
 * Bridges objective result to Module 07 MatchEngine final state.
 */
object VictoryMatchBridge {

    fun sync(
        matchEngine: MatchEngine,
        matchState: MatchState,
        objectiveState: ObjectiveState
    ): MatchState =
        when (objectiveState.outcome) {
            MatchOutcome.IN_PROGRESS -> matchState

            MatchOutcome.VICTORY -> {
                if (matchState.status.name == "RUNNING") {
                    matchEngine.finish(
                        state = matchState,
                        victory = true
                    )
                } else {
                    matchState
                }
            }

            MatchOutcome.DEFEAT -> {
                if (matchState.status.name == "RUNNING") {
                    matchEngine.finish(
                        state = matchState,
                        victory = false
                    )
                } else {
                    matchState
                }
            }
        }
}
