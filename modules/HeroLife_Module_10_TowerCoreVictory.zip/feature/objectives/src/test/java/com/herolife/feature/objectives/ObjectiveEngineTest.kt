package com.herolife.feature.objectives

import com.herolife.feature.objectives.domain.ObjectiveEngine
import com.herolife.feature.objectives.domain.ObjectiveFactory
import com.herolife.feature.objectives.model.MatchOutcome
import com.herolife.feature.objectives.model.ObjectiveRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObjectiveEngineTest {

    @Test
    fun completeTaskDamagesEnemyTowerFirst() {
        val rules = ObjectiveRules(
            damagePerCompletedTaskToEnemyTower = 40
        )
        val engine = ObjectiveEngine(rules)
        val state = ObjectiveFactory.create(rules)

        val result = engine.onTaskCompleted(state).first

        assertEquals(
            rules.enemyTowerMaxHp - 40,
            result.enemyTower.currentHp
        )

        assertEquals(
            rules.enemyCoreMaxHp,
            result.enemyCore.currentHp
        )
    }

    @Test
    fun enemyCoreCannotBeDamagedBeforeTowerFalls() {
        val rules = ObjectiveRules(
            enemyTowerMaxHp = 100,
            damagePerCompletedTaskToEnemyTower = 100,
            damagePerCompletedTaskToEnemyCore = 25
        )

        val engine = ObjectiveEngine(rules)
        var state = ObjectiveFactory.create(rules)

        state = engine.onTaskCompleted(state).first

        assertTrue(state.enemyTower.destroyed)
        assertEquals(100, state.enemyCore.currentHp)

        state = engine.onTaskCompleted(state).first

        assertEquals(75, state.enemyCore.currentHp)
    }

    @Test
    fun removePenaltyIsStrongerThanLaterPenalty() {
        val rules = ObjectiveRules(
            laterDamageToPlayerTower = 6,
            removeDamageToPlayerTower = 14
        )

        val engine = ObjectiveEngine(rules)
        val base = ObjectiveFactory.create(rules)

        val later = engine.onTaskLater(base).first
        val removed = engine.onTaskRemoved(base).first

        assertTrue(
            removed.playerTower.currentHp <
                later.playerTower.currentHp
        )
    }

    @Test
    fun destroyingEnemyCoreMeansVictory() {
        val rules = ObjectiveRules(
            enemyTowerMaxHp = 10,
            enemyCoreMaxHp = 10,
            damagePerCompletedTaskToEnemyTower = 10,
            damagePerCompletedTaskToEnemyCore = 10
        )

        val engine = ObjectiveEngine(rules)
        var state = ObjectiveFactory.create(rules)

        state = engine.onTaskCompleted(state).first
        state = engine.onTaskCompleted(state).first

        assertEquals(
            MatchOutcome.VICTORY,
            state.outcome
        )
    }

    @Test
    fun timeoutUsesObjectiveAdvantage() {
        val rules = ObjectiveRules(
            enemyTowerMaxHp = 100,
            damagePerCompletedTaskToEnemyTower = 60
        )

        val engine = ObjectiveEngine(rules)
        var state = ObjectiveFactory.create(rules)

        state = engine.onTaskCompleted(state).first
        state = engine.evaluateTimeout(state)

        assertEquals(
            MatchOutcome.VICTORY,
            state.outcome
        )
    }
}
