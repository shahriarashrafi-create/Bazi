package com.herolife.feature.map.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.model.WorldPoint
import kotlin.math.sqrt

@Composable
fun VirtualJoystick(
    onDirectionChanged: (direction: WorldPoint, strength: Float) -> Unit,
    onReleased: () -> Unit,
    modifier: Modifier = Modifier
) {
    var knob = Offset.Zero

    Canvas(
        modifier = modifier
            .size(150.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { position ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val raw = position - center
                        val radius = size.minDimension * 0.36f
                        val length = sqrt(raw.x * raw.x + raw.y * raw.y)
                        val safe = if (length > radius && length > 0f) {
                            raw * (radius / length)
                        } else {
                            raw
                        }
                        knob = safe
                        val strength = (safe.getDistance() / radius).coerceIn(0f, 1f)
                        onDirectionChanged(
                            WorldPoint(safe.x, safe.y).normalized(),
                            strength
                        )
                    },
                    onDragEnd = {
                        knob = Offset.Zero
                        onReleased()
                    },
                    onDragCancel = {
                        knob = Offset.Zero
                        onReleased()
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val radius = size.minDimension * 0.36f
                        val candidate = knob + dragAmount
                        val length = candidate.getDistance()
                        knob = if (length > radius && length > 0f) {
                            candidate * (radius / length)
                        } else {
                            candidate
                        }

                        val strength = (knob.getDistance() / radius).coerceIn(0f, 1f)
                        onDirectionChanged(
                            direction = if (strength > 0f) {
                                WorldPoint(knob.x, knob.y).normalized()
                            } else {
                                WorldPoint.Zero
                            },
                            strength = strength
                        )
                    }
                )
            }
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val outerRadius = size.minDimension * 0.43f
        val innerRadius = size.minDimension * 0.19f

        drawCircle(
            color = HeroLifeColors.Void.copy(alpha = 0.72f),
            radius = outerRadius,
            center = center
        )

        drawCircle(
            color = HeroLifeColors.Crystal.copy(alpha = 0.36f),
            radius = outerRadius,
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )

        drawCircle(
            color = HeroLifeColors.Crystal.copy(alpha = 0.15f),
            radius = outerRadius * 0.67f,
            center = center,
            style = Stroke(width = 1.dp.toPx())
        )

        drawCircle(
            color = HeroLifeColors.Gold.copy(alpha = 0.94f),
            radius = innerRadius,
            center = center + knob
        )

        drawCircle(
            color = HeroLifeColors.GoldBright.copy(alpha = 0.72f),
            radius = innerRadius,
            center = center + knob,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
