package com.herolife.feature.map.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeBattleTopBar
import com.herolife.feature.map.model.BattleMapState

/**
 * Visual composition shell for Module 08.
 *
 * State mutation / frame ticking is intentionally kept outside this composable,
 * so a ViewModel or a future game loop can own the simulation deterministically.
 */
@Composable
fun MobaMapScreen(
    state: BattleMapState,
    timerText: String,
    levelText: String,
    gold: Long,
    diamonds: Long,
    onJoystickChanged: (directionX: Float, directionY: Float, strength: Float) -> Unit,
    onJoystickReleased: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize()
    ) {
        BattleMapCanvas(
            state = state,
            modifier = Modifier.fillMaxSize()
        )

        HeroLifeBattleTopBar(
            timer = timerText,
            levelText = levelText,
            gold = gold,
            diamonds = diamonds,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        )

        BattleMiniMap(
            state = state,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 18.dp, top = 150.dp)
        )

        VirtualJoystick(
            onDirectionChanged = { direction, strength ->
                onJoystickChanged(
                    direction.x,
                    direction.y,
                    strength
                )
            },
            onReleased = onJoystickReleased,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
        )
    }
}
