package com.herolife.feature.map.model

data class HeroMapState(
    val position: WorldPoint,
    val facing: WorldPoint = WorldPoint(1f, 0f),
    val moving: Boolean = false,
    val speedWorldUnitsPerSecond: Float = 210f
) {
    init {
        require(speedWorldUnitsPerSecond > 0f)
    }
}

data class CameraState(
    val center: WorldPoint,
    val viewportWorldWidth: Float = 1000f,
    val viewportWorldHeight: Float = 700f
) {
    init {
        require(viewportWorldWidth > 0f)
        require(viewportWorldHeight > 0f)
    }
}

data class JoystickState(
    val direction: WorldPoint = WorldPoint.Zero,
    val strength: Float = 0f,
    val active: Boolean = false
) {
    init {
        require(strength in 0f..1f)
    }
}

data class BattleMapState(
    val world: MapWorld,
    val hero: HeroMapState,
    val camera: CameraState,
    val joystick: JoystickState = JoystickState(),
    val selectedMinionId: String? = null
)
