package com.herolife.feature.map.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.domain.MapCoordinateMapper
import com.herolife.feature.map.model.BattleMapState

@Composable
fun BattleMiniMap(
    state: BattleMapState,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .size(132.dp)
            .background(
                brush = Brush.linearGradient(
                    listOf(
                        HeroLifeColors.Void.copy(alpha = 0.92f),
                        HeroLifeColors.DeepNavy.copy(alpha = 0.94f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
    ) {
        state.world.lanes.forEach { lane ->
            val start = MapCoordinateMapper.worldToMinimap(
                lane.start,
                state.world.bounds,
                size.width,
                size.height
            )
            val end = MapCoordinateMapper.worldToMinimap(
                lane.end,
                state.world.bounds,
                size.width,
                size.height
            )

            drawLine(
                color = HeroLifeColors.Divider,
                start = Offset(start.x, start.y),
                end = Offset(end.x, end.y),
                strokeWidth = 3.dp.toPx()
            )
        }

        state.world.towers.filterNot { it.destroyed }.forEach { tower ->
            val p = MapCoordinateMapper.worldToMinimap(
                tower.position,
                state.world.bounds,
                size.width,
                size.height
            )
            drawCircle(
                color = HeroLifeColors.Danger,
                radius = 4.5.dp.toPx(),
                center = Offset(p.x, p.y)
            )
        }

        state.world.minions.filter { it.active }.forEach { minion ->
            val p = MapCoordinateMapper.worldToMinimap(
                minion.position,
                state.world.bounds,
                size.width,
                size.height
            )
            drawCircle(
                color = HeroLifeColors.Warning,
                radius = 2.8.dp.toPx(),
                center = Offset(p.x, p.y)
            )
        }

        val hero = MapCoordinateMapper.worldToMinimap(
            state.hero.position,
            state.world.bounds,
            size.width,
            size.height
        )

        drawCircle(
            color = HeroLifeColors.Crystal,
            radius = 5.5.dp.toPx(),
            center = Offset(hero.x, hero.y)
        )

        drawCircle(
            color = HeroLifeColors.TextPrimary,
            radius = 5.5.dp.toPx(),
            center = Offset(hero.x, hero.y),
            style = Stroke(width = 1.3.dp.toPx())
        )
    }
}
