package com.herolife.feature.map.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.domain.MapCoordinateMapper
import com.herolife.feature.map.model.BattleMapState
import com.herolife.feature.map.model.LaneId

@Composable
fun BattleMapCanvas(
    state: BattleMapState,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(
                        HeroLifeColors.SurfaceHighlight,
                        HeroLifeColors.DeepNavy,
                        HeroLifeColors.Void
                    )
                )
            )
    ) {
        val w = size.width
        val h = size.height

        drawCircle(
            color = HeroLifeColors.CrystalDark.copy(alpha = 0.08f),
            radius = size.minDimension * 0.48f,
            center = Offset(w * 0.50f, h * 0.50f)
        )

        state.world.lanes.forEach { lane ->
            val a = MapCoordinateMapper.worldToScreen(
                lane.start,
                state.camera,
                w,
                h
            )
            val b = MapCoordinateMapper.worldToScreen(
                lane.end,
                state.camera,
                w,
                h
            )

            val laneColor = when (lane.id) {
                LaneId.NETWORKING -> HeroLifeColors.Crystal
                LaneId.PERSONAL_GROWTH -> HeroLifeColors.Gold
                LaneId.PERSONAL -> HeroLifeColors.Success
            }

            drawLine(
                color = laneColor.copy(alpha = 0.10f),
                start = Offset(a.x, a.y),
                end = Offset(b.x, b.y),
                strokeWidth = 34.dp.toPx()
            )

            drawLine(
                color = laneColor.copy(alpha = 0.58f),
                start = Offset(a.x, a.y),
                end = Offset(b.x, b.y),
                strokeWidth = 3.dp.toPx()
            )
        }

        state.world.towers
            .filterNot { it.destroyed }
            .forEach { tower ->
                val p = MapCoordinateMapper.worldToScreen(
                    tower.position,
                    state.camera,
                    w,
                    h
                )

                drawCircle(
                    color = HeroLifeColors.Danger.copy(alpha = 0.22f),
                    radius = 34.dp.toPx(),
                    center = Offset(p.x, p.y)
                )

                drawCircle(
                    color = HeroLifeColors.Danger,
                    radius = 17.dp.toPx(),
                    center = Offset(p.x, p.y)
                )

                drawCircle(
                    color = HeroLifeColors.GoldBright,
                    radius = 17.dp.toPx(),
                    center = Offset(p.x, p.y),
                    style = Stroke(width = 2.dp.toPx())
                )
            }

        state.world.minions
            .filter { it.active }
            .forEach { minion ->
                val p = MapCoordinateMapper.worldToScreen(
                    minion.position,
                    state.camera,
                    w,
                    h
                )

                drawCircle(
                    color = HeroLifeColors.DangerDark.copy(alpha = 0.38f),
                    radius = 20.dp.toPx(),
                    center = Offset(p.x, p.y)
                )

                drawCircle(
                    color = HeroLifeColors.Warning,
                    radius = 9.dp.toPx(),
                    center = Offset(p.x, p.y)
                )
            }

        val hero = MapCoordinateMapper.worldToScreen(
            state.hero.position,
            state.camera,
            w,
            h
        )

        drawCircle(
            color = HeroLifeColors.Crystal.copy(alpha = 0.16f),
            radius = 46.dp.toPx(),
            center = Offset(hero.x, hero.y)
        )

        drawCircle(
            color = HeroLifeColors.Crystal,
            radius = 22.dp.toPx(),
            center = Offset(hero.x, hero.y)
        )

        drawCircle(
            color = HeroLifeColors.TextPrimary,
            radius = 22.dp.toPx(),
            center = Offset(hero.x, hero.y),
            style = Stroke(width = 3.dp.toPx())
        )

        val facing = state.hero.facing.normalized()
        val arrow = Path().apply {
            moveTo(hero.x + facing.x * 34.dp.toPx(), hero.y + facing.y * 34.dp.toPx())
            lineTo(hero.x + facing.x * 22.dp.toPx() - facing.y * 7.dp.toPx(),
                hero.y + facing.y * 22.dp.toPx() + facing.x * 7.dp.toPx())
            lineTo(hero.x + facing.x * 22.dp.toPx() + facing.y * 7.dp.toPx(),
                hero.y + facing.y * 22.dp.toPx() - facing.x * 7.dp.toPx())
            close()
        }

        drawPath(
            path = arrow,
            color = HeroLifeColors.GoldBright
        )
    }
}
