package com.herolife.feature.map.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.herolife.core.designsystem.HeroLifeColors
import com.herolife.feature.map.model.WorldPoint
import kotlin.math.sqrt

@Composable
fun VirtualJoystick(
    onDirectionChanged: (WorldPoint, Float) -> Unit,
    onReleased: () -> Unit,
    modifier: Modifier = Modifier
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Canvas(
        modifier = modifier
            .size(150.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { touchOffset: Offset ->
                        val centerX: Float = size.width.toFloat() / 2f
                        val centerY: Float = size.height.toFloat() / 2f
                        val rawX: Float = touchOffset.x - centerX
                        val rawY: Float = touchOffset.y - centerY
                        val radius: Float =
                            minOf(size.width.toFloat(), size.height.toFloat()) * 0.36f

                        val length: Float = sqrt(rawX * rawX + rawY * rawY)
                        val scale: Float =
                            if (length > radius && length > 0f) radius / length else 1f

                        val safeX: Float = rawX * scale
                        val safeY: Float = rawY * scale
                        knobOffset = Offset(safeX, safeY)

                        val strength: Float =
                            if (radius > 0f) {
                                (sqrt(safeX * safeX + safeY * safeY) / radius)
                                    .coerceIn(0f, 1f)
                            } else {
                                0f
                            }

                        val direction: WorldPoint =
                            if (strength > 0f) {
                                WorldPoint(safeX, safeY).normalized()
                            } else {
                                WorldPoint.Zero
                            }

                        onDirectionChanged(direction, strength)
                    },
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        onReleased()
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        onReleased()
                    },
                    onDrag = { change, dragAmount: Offset ->
                        change.consume()

                        val radius: Float =
                            minOf(size.width.toFloat(), size.height.toFloat()) * 0.36f

                        val candidateX: Float = knobOffset.x + dragAmount.x
                        val candidateY: Float = knobOffset.y + dragAmount.y
                        val length: Float =
                            sqrt(candidateX * candidateX + candidateY * candidateY)

                        val scale: Float =
                            if (length > radius && length > 0f) radius / length else 1f

                        val safeX: Float = candidateX * scale
                        val safeY: Float = candidateY * scale
                        knobOffset = Offset(safeX, safeY)

                        val strength: Float =
                            if (radius > 0f) {
                                (sqrt(safeX * safeX + safeY * safeY) / radius)
                                    .coerceIn(0f, 1f)
                            } else {
                                0f
                            }

                        val direction: WorldPoint =
                            if (strength > 0f) {
                                WorldPoint(safeX, safeY).normalized()
                            } else {
                                WorldPoint.Zero
                            }

                        onDirectionChanged(direction, strength)
                    }
                )
            }
    ) {
        val canvasWidth: Float = size.width
        val canvasHeight: Float = size.height
        val minDimension: Float = minOf(canvasWidth, canvasHeight)

        val center = Offset(
            x = canvasWidth / 2f,
            y = canvasHeight / 2f
        )

        val outerRadius: Float = minDimension * 0.43f
        val innerRadius: Float = minDimension * 0.19f

        drawCircle(
            color = HeroLifeColors.Void.copy(alpha = 0.72f),
            radius = outerRadius,
            center = center
        )

        drawCircle(
            color = HeroLifeColors.Crystal.copy(alpha = 0.36f),
            radius = outerRadius,
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )

        drawCircle(
            color = HeroLifeColors.Crystal.copy(alpha = 0.15f),
            radius = outerRadius * 0.67f,
            center = center,
            style = Stroke(width = 1.dp.toPx())
        )

        val knobCenter = Offset(
            x = center.x + knobOffset.x,
            y = center.y + knobOffset.y
        )

        drawCircle(
            color = HeroLifeColors.Gold.copy(alpha = 0.94f),
            radius = innerRadius,
            center = knobCenter
        )

        drawCircle(
            color = HeroLifeColors.GoldBright.copy(alpha = 0.72f),
            radius = innerRadius,
            center = knobCenter,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
