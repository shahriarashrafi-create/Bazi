package com.herolife.feature.map.domain

import com.herolife.feature.map.model.CameraState
import com.herolife.feature.map.model.WorldBounds
import com.herolife.feature.map.model.WorldPoint

data class ScreenPoint(
    val x: Float,
    val y: Float
)

object MapCoordinateMapper {

    fun worldToScreen(
        point: WorldPoint,
        camera: CameraState,
        screenWidth: Float,
        screenHeight: Float
    ): ScreenPoint {
        val left = camera.center.x - camera.viewportWorldWidth / 2f
        val top = camera.center.y - camera.viewportWorldHeight / 2f

        val xRatio = (point.x - left) / camera.viewportWorldWidth
        val yRatio = (point.y - top) / camera.viewportWorldHeight

        return ScreenPoint(
            x = xRatio * screenWidth,
            y = yRatio * screenHeight
        )
    }

    fun worldToMinimap(
        point: WorldPoint,
        bounds: WorldBounds,
        minimapWidth: Float,
        minimapHeight: Float
    ): ScreenPoint {
        val xRatio = (point.x - bounds.left) / bounds.width
        val yRatio = (point.y - bounds.top) / bounds.height

        return ScreenPoint(
            x = xRatio * minimapWidth,
            y = yRatio * minimapHeight
        )
    }
}
