package com.herolife.feature.map.controller

import com.herolife.feature.map.domain.MovementEngine
import com.herolife.feature.map.model.BattleMapState
import com.herolife.feature.map.model.CameraState
import com.herolife.feature.map.model.DefaultBattleWorld
import com.herolife.feature.map.model.HeroMapState
import com.herolife.feature.map.model.WorldPoint

/**
 * Small controller around the pure movement engine.
 *
 * It deliberately has no Android dependency. A ViewModel can wrap this later.
 */
class MapController(
    initialState: BattleMapState = defaultInitialState()
) {
    var state: BattleMapState = initialState
        private set

    fun onJoystick(
        directionX: Float,
        directionY: Float,
        strength: Float
    ) {
        state = MovementEngine.updateJoystick(
            state = state,
            direction = WorldPoint(directionX, directionY),
            strength = strength
        )
    }

    fun onJoystickReleased() {
        state = MovementEngine.releaseJoystick(state)
    }

    fun onFrame(deltaSeconds: Float) {
        state = MovementEngine.tick(state, deltaSeconds)
    }

    companion object {
        fun defaultInitialState(): BattleMapState {
            val world = DefaultBattleWorld.create()
            val hero = HeroMapState(
                position = WorldPoint(350f, 800f)
            )
            val camera = CameraState(
                center = hero.position
            )

            return BattleMapState(
                world = world,
                hero = hero,
                camera = camera
            )
        }
    }
}
