package com.herolife.feature.map.domain

import com.herolife.feature.map.model.BattleMapState
import com.herolife.feature.map.model.CameraState
import com.herolife.feature.map.model.HeroMapState
import com.herolife.feature.map.model.JoystickState
import com.herolife.feature.map.model.WorldBounds
import com.herolife.feature.map.model.WorldPoint
import kotlin.math.max

/**
 * Pure movement engine.
 *
 * No Android classes are used here, which makes movement deterministic,
 * testable, and reusable by a future renderer.
 */
object MovementEngine {

    fun updateJoystick(
        state: BattleMapState,
        direction: WorldPoint,
        strength: Float
    ): BattleMapState {
        val safeStrength = strength.coerceIn(0f, 1f)
        val safeDirection = if (safeStrength <= 0f) {
            WorldPoint.Zero
        } else {
            direction.normalized()
        }

        return state.copy(
            joystick = JoystickState(
                direction = safeDirection,
                strength = safeStrength,
                active = safeStrength > 0.01f
            )
        )
    }

    fun releaseJoystick(state: BattleMapState): BattleMapState =
        state.copy(
            joystick = JoystickState(),
            hero = state.hero.copy(moving = false)
        )

    fun tick(
        state: BattleMapState,
        deltaSeconds: Float
    ): BattleMapState {
        if (deltaSeconds <= 0f) return state

        val joystick = state.joystick
        if (!joystick.active || joystick.strength <= 0f) {
            return state.copy(hero = state.hero.copy(moving = false))
        }

        val safeDelta = deltaSeconds.coerceAtMost(0.050f)
        val distance =
            state.hero.speedWorldUnitsPerSecond *
                joystick.strength *
                safeDelta

        val delta = joystick.direction * distance
        val nextPosition = (state.hero.position + delta)
            .coerceIn(state.world.bounds)

        val nextHero = state.hero.copy(
            position = nextPosition,
            facing = joystick.direction,
            moving = true
        )

        return state.copy(
            hero = nextHero,
            camera = followHero(
                camera = state.camera,
                hero = nextHero,
                bounds = state.world.bounds
            )
        )
    }

    fun followHero(
        camera: CameraState,
        hero: HeroMapState,
        bounds: WorldBounds
    ): CameraState {
        val halfW = camera.viewportWorldWidth / 2f
        val halfH = camera.viewportWorldHeight / 2f

        val minX = bounds.left + halfW
        val maxX = bounds.right - halfW
        val minY = bounds.top + halfH
        val maxY = bounds.bottom - halfH

        val centerX = if (minX <= maxX) {
            hero.position.x.coerceIn(minX, maxX)
        } else {
            bounds.center.x
        }

        val centerY = if (minY <= maxY) {
            hero.position.y.coerceIn(minY, maxY)
        } else {
            bounds.center.y
        }

        return camera.copy(
            center = WorldPoint(centerX, centerY)
        )
    }

    fun distanceTo(
        from: WorldPoint,
        to: WorldPoint
    ): Float = (to - from).magnitude()

    fun isWithinInteractionRange(
        hero: WorldPoint,
        target: WorldPoint,
        range: Float = 110f
    ): Boolean = distanceTo(hero, target) <= max(0f, range)
}
