package com.herolife.feature.map.model

import kotlin.math.sqrt

data class WorldPoint(
    val x: Float,
    val y: Float
) {
    operator fun plus(other: WorldPoint) = WorldPoint(x + other.x, y + other.y)
    operator fun minus(other: WorldPoint) = WorldPoint(x - other.x, y - other.y)
    operator fun times(scale: Float) = WorldPoint(x * scale, y * scale)

    fun magnitude(): Float = sqrt(x * x + y * y)

    fun normalized(): WorldPoint {
        val length = magnitude()
        return if (length <= 0.0001f) Zero else WorldPoint(x / length, y / length)
    }

    fun coerceIn(bounds: WorldBounds): WorldPoint = WorldPoint(
        x = x.coerceIn(bounds.left, bounds.right),
        y = y.coerceIn(bounds.top, bounds.bottom)
    )

    companion object {
        val Zero = WorldPoint(0f, 0f)
    }
}

data class WorldBounds(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    init {
        require(right > left)
        require(bottom > top)
    }

    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val center: WorldPoint get() = WorldPoint(
        x = left + width / 2f,
        y = top + height / 2f
    )
}

enum class LaneId {
    NETWORKING,
    PERSONAL_GROWTH,
    PERSONAL
}

data class LaneDefinition(
    val id: LaneId,
    val title: String,
    val start: WorldPoint,
    val end: WorldPoint,
    val pressure: Int
) {
    init {
        require(pressure in 0..100)
    }
}

data class TowerNode(
    val id: String,
    val lane: LaneId,
    val position: WorldPoint,
    val enemy: Boolean = true,
    val destroyed: Boolean = false
)

data class MinionNode(
    val id: String,
    val lane: LaneId,
    val position: WorldPoint,
    val taskTitle: String,
    val active: Boolean = true
)

data class MapWorld(
    val bounds: WorldBounds,
    val lanes: List<LaneDefinition>,
    val towers: List<TowerNode>,
    val minions: List<MinionNode>
)

object DefaultBattleWorld {
    val bounds = WorldBounds(
        left = 0f,
        top = 0f,
        right = 2400f,
        bottom = 1600f
    )

    fun create(): MapWorld {
        val lanes = listOf(
            LaneDefinition(
                id = LaneId.NETWORKING,
                title = "شبکه‌سازی",
                start = WorldPoint(250f, 1350f),
                end = WorldPoint(2150f, 250f),
                pressure = 48
            ),
            LaneDefinition(
                id = LaneId.PERSONAL_GROWTH,
                title = "رشد فردی",
                start = WorldPoint(250f, 800f),
                end = WorldPoint(2150f, 800f),
                pressure = 32
            ),
            LaneDefinition(
                id = LaneId.PERSONAL,
                title = "شخصی",
                start = WorldPoint(250f, 250f),
                end = WorldPoint(2150f, 1350f),
                pressure = 67
            )
        )

        val towers = listOf(
            TowerNode("tower-networking-1", LaneId.NETWORKING, WorldPoint(1550f, 600f)),
            TowerNode("tower-growth-1", LaneId.PERSONAL_GROWTH, WorldPoint(1650f, 800f)),
            TowerNode("tower-personal-1", LaneId.PERSONAL, WorldPoint(1550f, 1000f))
        )

        val minions = listOf(
            MinionNode(
                id = "m1",
                lane = LaneId.NETWORKING,
                position = WorldPoint(900f, 980f),
                taskTitle = "ارتباط‌سازی با ۳ نفر"
            ),
            MinionNode(
                id = "m2",
                lane = LaneId.PERSONAL_GROWTH,
                position = WorldPoint(1050f, 800f),
                taskTitle = "۲۰ دقیقه مطالعه"
            ),
            MinionNode(
                id = "m3",
                lane = LaneId.PERSONAL,
                position = WorldPoint(1050f, 620f),
                taskTitle = "کار شخصی مهم"
            )
        )

        return MapWorld(
            bounds = bounds,
            lanes = lanes,
            towers = towers,
            minions = minions
        )
    }
}
