package com.herolife.feature.map

import com.herolife.feature.map.controller.MapController
import com.herolife.feature.map.domain.MovementEngine
import com.herolife.feature.map.model.WorldPoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MovementEngineTest {

    @Test
    fun heroMovesOnlyWhenJoystickIsActive() {
        val controller = MapController()
        val start = controller.state.hero.position

        controller.onFrame(0.016f)
        assertEquals(start, controller.state.hero.position)

        controller.onJoystick(1f, 0f, 1f)
        controller.onFrame(0.016f)

        assertTrue(controller.state.hero.position.x > start.x)
    }

    @Test
    fun releasingJoystickStopsMovement() {
        val controller = MapController()

        controller.onJoystick(1f, 0f, 1f)
        controller.onFrame(0.016f)
        controller.onJoystickReleased()

        assertFalse(controller.state.joystick.active)
        assertFalse(controller.state.hero.moving)
    }

    @Test
    fun heroCannotLeaveWorldBounds() {
        val controller = MapController()

        controller.onJoystick(-1f, 0f, 1f)

        repeat(5000) {
            controller.onFrame(0.050f)
        }

        assertTrue(
            controller.state.hero.position.x >=
                controller.state.world.bounds.left
        )
    }

    @Test
    fun interactionRangeIsDeterministic() {
        val hero = WorldPoint(100f, 100f)
        val targetNear = WorldPoint(150f, 100f)
        val targetFar = WorldPoint(500f, 100f)

        assertTrue(
            MovementEngine.isWithinInteractionRange(
                hero,
                targetNear,
                range = 110f
            )
        )

        assertFalse(
            MovementEngine.isWithinInteractionRange(
                hero,
                targetFar,
                range = 110f
            )
        )
    }
}
