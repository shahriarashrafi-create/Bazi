# Module 08/20 — MOBA Map & Manual Movement

Independent module: `:feature:map`

## هدف

این ماژول اولین لایه بصری واقعی میدان نبرد HeroLife است.

## قابلیت‌ها

- World coordinate system
- سه Lane:
  - شبکه‌سازی
  - رشد فردی
  - شخصی
- Manual movement only
- Virtual joystick
- No auto movement
- Slow/professional movement speed contract
- Camera follow
- Camera world-bound clamping
- Hero facing direction
- Minion map nodes
- Tower map nodes
- Lane pressure metadata
- Cinematic Canvas renderer
- Minimap renderer
- Battle HUD integration
- Pure/testable movement engine
- Interaction-range calculation
- Independent controller
- Unit tests

## معماری

Renderer و simulation از هم جدا هستند.

`MovementEngine` هیچ Android dependency ندارد و pure Kotlin است.
این تصمیم برای تست، performance، replay و ارتقای renderer در آینده مهم است.

## ادامه مسیر

Module 09:
Task -> Minion behavior, encounter panel, Later, Remove, Swap.

Module 10:
Tower/Core health, damage, victory/defeat objective graph.

Module 11:
Combat VFX, animation and hit feedback.

این ماژول عمداً هیچ auto-path یا auto-move ندارد.
حرکت Hero فقط از ورودی دستی بازیکن انجام می‌شود.
