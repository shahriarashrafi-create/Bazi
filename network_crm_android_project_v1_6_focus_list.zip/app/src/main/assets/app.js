const STAGES = {
  connect: { label: 'ارتباط‌سازی', icon: 'i-users', className: 'connect', points: 10 },
  preconsult: { label: 'پیش‌مشاوره', icon: 'i-message', className: 'preconsult', points: 25 },
  invite: { label: 'دعوت', icon: 'i-send', className: 'invite', points: 50 },
  followup: { label: 'فالوآپ', icon: 'i-sprout', className: 'followup', points: 100 },
};

const makeId = () => (globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(16).slice(2)}`);
const now = Date.now();
const seed = [
  {id:makeId(),name:'علی محمدی',phone:'0912 345 6789',stage:'connect',note:'معرفی از طرف حسین',done:false,createdAt:now-5_000},
  {id:makeId(),name:'سارا رضایی',phone:'0935 987 6543',stage:'preconsult',note:'علاقه‌مند به اطلاعات بیشتر',done:true,createdAt:now-10_000},
  {id:makeId(),name:'مهدی احمدی',phone:'0919 111 2233',stage:'invite',note:'دعوت برای جلسه شنبه',done:false,createdAt:now-15_000},
  {id:makeId(),name:'نرگس کریمی',phone:'0912 444 5566',stage:'followup',note:'پیگیری سه‌شنبه',done:false,createdAt:now-20_000},
  {id:makeId(),name:'رضا قاسمی',phone:'0930 777 8899',stage:'connect',note:'',done:false,createdAt:now-25_000},
  {id:makeId(),name:'الهام موسوی',phone:'0912 222 3344',stage:'preconsult',note:'',done:false,createdAt:now-30_000},
  {id:makeId(),name:'حمید نادری',phone:'0936 555 6677',stage:'',note:'از مخاطبین گوشی',done:false,createdAt:now-35_000},
  {id:makeId(),name:'کامران عباسی',phone:'0919 888 7766',stage:'followup',note:'منتظر پاسخ',done:false,createdAt:now-40_000},
];

const storageKey = 'networkCRM.contacts.v3';
let stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
if (!stored) {
  const previous = JSON.parse(localStorage.getItem('networkCRM.contacts.v2') || 'null') || JSON.parse(localStorage.getItem('networkCRM.contacts') || 'null');
  if (Array.isArray(previous)) {
    stored = previous.map(c => ({
      ...c,
      stage: c.stage === 'reference' ? '' : (c.stage || ''),
      done: Boolean(c.done),
    }));
  }
}
let contacts = Array.isArray(stored)
  ? stored.map(c=>({...c, done:Boolean(c.done), rewardedStages:Array.isArray(c.rewardedStages)?c.rewardedStages:[]}))
  : seed.map(c=>({...c, rewardedStages:[]}));
let activeStage = 'all';
let stageTargetIds = [];
let actionTargetId = null;
let filters = { stage: 'all', note: 'any', done: 'any' };

const gameStorageKey = 'networkCRM.game.v1';
const XP_PER_LEVEL = 1000;
const DAILY_MISSION_TARGET = 5;
const dayKey = (d=new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const defaultGame = () => ({
  totalXp: 11730,
  todayPoints: 280,
  streak: 5,
  todayCompletions: 3,
  todayDate: dayKey(),
  lastActivityDate: dayKey(),
});
let game = {...defaultGame(), ...(JSON.parse(localStorage.getItem(gameStorageKey) || 'null') || {})};

function normalizeGameDay(){
  const today = dayKey();
  if(game.todayDate !== today){
    game.todayDate = today;
    game.todayPoints = 0;
    game.todayCompletions = 0;
  }
}
normalizeGameDay();

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fa = n => Number(n).toLocaleString('fa-IR');
const escapeHTML = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials = name => String(name || '').trim().split(/\s+/).slice(0,2).map(x=>x[0] || '').join('');
const icon = id => `<svg aria-hidden="true"><use href="#${id}"/></svg>`;

function save(){ localStorage.setItem(storageKey, JSON.stringify(contacts)); }
function saveGame(){ localStorage.setItem(gameStorageKey, JSON.stringify(game)); }
function awardGamePoints(amount=20){
  normalizeGameDay();
  const today = dayKey();
  const yesterday = dayKey(new Date(Date.now() - 86400000));
  if(game.lastActivityDate !== today){
    game.streak = game.lastActivityDate === yesterday ? Math.max(1, Number(game.streak||0) + 1) : 1;
    game.lastActivityDate = today;
  }
  game.totalXp = Number(game.totalXp||0) + amount;
  game.todayPoints = Number(game.todayPoints||0) + amount;
  game.todayCompletions = Number(game.todayCompletions||0) + 1;
  saveGame();
}
function toast(msg){
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._timer);
  el._timer = setTimeout(()=>el.classList.remove('show'), 2300);
}
function openDialog(id){ const d=$(id); if(d && !d.open) d.showModal(); }
function closeDialog(id){ const d=$(id); if(d?.open) d.close(); }

function renderStats(){
  const stats = [
    {key:'all', label:'همه', icon:'i-users', className:'all', count:contacts.length},
    ...Object.entries(STAGES).map(([key,s])=>({key,label:s.label,icon:s.icon,className:s.className,count:contacts.filter(c=>c.stage===key).length}))
  ];
  $('#stats').innerHTML = stats.map(s => `
    <button type="button" class="stat ${s.className} ${activeStage===s.key?'active':''}" data-stat-stage="${s.key}" title="${escapeHTML(s.label)}">
      ${icon(s.icon)}<span class="label">${escapeHTML(s.label)}</span><span class="num">${fa(s.count)}</span>
    </button>`).join('');
  $$('[data-stat-stage]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.statStage;
    render();
  });
}

function renderGamification(){
  normalizeGameDay();
  const totalXp = Math.max(0, Number(game.totalXp||0));
  const level = Math.floor(totalXp / XP_PER_LEVEL) + 1;
  const xpInLevel = totalXp % XP_PER_LEVEL;
  const xpPercent = Math.max(0, Math.min(100, (xpInLevel / XP_PER_LEVEL) * 100));
  $('#levelNumber').textContent = fa(level);
  $('#xpFill').style.width = `${xpPercent}%`;
  $('#streakDays').textContent = fa(Math.max(0, Number(game.streak||0)));
  $('#todayScore').textContent = fa(Math.max(0, Number(game.todayPoints||0)));
}


function renderTabs(){
  const items = [{key:'all',label:'همه'}, ...Object.entries(STAGES).map(([key,v])=>({key,label:v.label}))];
  $('#stageTabs').innerHTML = items.map(x=>`<button class="stage-tab ${activeStage===x.key?'active':''}" data-stage-tab="${x.key}">${x.label}</button>`).join('');
  $$('[data-stage-tab]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.stageTab;
    filters.stage = 'all';
    $('#filterStage').value = 'all';
    render();
  });
}

function visibleContacts(){
  const arr = contacts.filter(c => activeStage === 'all' || c.stage === activeStage);
  arr.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
  return arr;
}

function badgeFor(c){
  if (!c.stage) return `<button class="badge none" data-stage-change="${c.id}" title="انتخاب مرحله">${icon('i-users')}<span>بدون مرحله</span></button>`;
  const s=STAGES[c.stage];
  return `<button class="badge ${s?.className || 'none'}" data-stage-change="${c.id}" title="تغییر مرحله">${icon(s?.icon || 'i-users')}<span>${escapeHTML(s?.label || 'بدون مرحله')}</span></button>`;
}

function relativeActivity(c){
  if(c.done) return 'انجام‌شده در این مرحله';
  if(c.note?.trim()) return c.note.trim();
  const days = Math.max(0, Math.floor((Date.now() - Number(c.createdAt || Date.now())) / 86400000));
  if(days <= 0) return 'امروز اضافه شده';
  if(days === 1) return '۱ روز پیش';
  return `${fa(days)} روز پیش`;
}

function renderContacts(){
  const arr = visibleContacts();
  if(!arr.length){
    $('#contacts').innerHTML = `<div class="empty"><strong>مخاطبی در این بخش نیست</strong>از دکمه + مخاطب جدید اضافه کن یا از کارت‌های بالا مرحله دیگری را انتخاب کن.</div>`;
    return;
  }

  $('#contacts').innerHTML = arr.map(c => `
    <article class="contact ${c.done?'done':''}" data-contact-row="${c.id}">
      <input class="done-check" type="checkbox" aria-label="${c.done?'برداشتن تیک':'علامت انجام شد برای'} ${escapeHTML(c.name)}" data-done="${c.id}" ${c.done?'checked':''} />
      <div class="info">
        <div class="name">${escapeHTML(c.name)}</div>
        <div class="quick-actions" aria-label="راه‌های ارتباطی">
          <button type="button" data-call="${c.id}" aria-label="تماس با ${escapeHTML(c.name)}" title="تماس">${icon('i-phone')}</button>
          <button type="button" data-sms="${c.id}" aria-label="پیامک به ${escapeHTML(c.name)}" title="پیامک">${icon('i-sms')}</button>
          <button type="button" class="telegram" data-telegram="${c.id}" aria-label="تلگرام ${escapeHTML(c.name)}" title="تلگرام">${icon('i-telegram')}</button>
        </div>
      </div>
      <div class="stage-side">${badgeFor(c)}</div>
      <button class="menu-btn" data-menu="${c.id}" aria-label="گزینه‌های ${escapeHTML(c.name)}">${icon('i-more')}</button>
    </article>`).join('');

  $$('[data-done]').forEach(box => box.onchange = () => {
    const id = box.dataset.done;
    let reward = 0;
    contacts = contacts.map(c => {
      if(c.id !== id) return c;
      const next = {...c, done:box.checked};
      if(box.checked && !c.done){
        const rewardKey = c.stage || 'reference';
        const rewardedStages = Array.isArray(c.rewardedStages) ? c.rewardedStages : [];
        if(!rewardedStages.includes(rewardKey)){
          next.rewardedStages = [...rewardedStages, rewardKey];
          reward = c.stage ? (STAGES[c.stage]?.points || 10) : 5;
        }
      }
      return next;
    });
    if(reward) awardGamePoints(reward);
    save();
    render();
    toast(box.checked ? (reward ? `انجام شد؛ +${fa(reward)} امتیاز` : 'این کار انجام‌شده علامت خورد') : 'تیک انجام‌شده برداشته شد');
  });
  $$('[data-stage-change]').forEach(btn => btn.onclick = () => openStageDialog([btn.dataset.stageChange]));
  $$('[data-menu]').forEach(btn => btn.onclick = () => openActionDialog(btn.dataset.menu));
  $$('[data-call]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.call, 'call'));
  $$('[data-sms]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.sms, 'sms'));
  $$('[data-telegram]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.telegram, 'telegram'));
}

function renderFilterState(){}
function render(){ renderGamification(); renderStats(); renderContacts(); }

function openContactDialog(id=null){
  const c = contacts.find(x=>x.id===id);
  $('#dialogTitle').textContent = c ? 'ویرایش مخاطب' : 'افزودن مخاطب';
  $('#contactId').value = c?.id || '';
  $('#nameInput').value = c?.name || '';
  $('#phoneInput').value = c?.phone || '';
  $('#stageInput').value = c?.stage || '';
  $('#noteInput').value = c?.note || '';
  openDialog('#contactDialog');
  if (c) setTimeout(()=>$('#nameInput').focus(),50);
}

$('#contactForm').addEventListener('submit', e => {
  e.preventDefault();
  const name=$('#nameInput').value.trim(), phone=$('#phoneInput').value.trim();
  if(!name || !phone){ toast('نام و شماره موبایل را وارد کن'); return; }
  const id=$('#contactId').value;
  const nextStage=$('#stageInput').value;
  const data={name,phone,stage:nextStage,note:$('#noteInput').value.trim()};
  if(id){
    const idx=contacts.findIndex(c=>c.id===id);
    if(idx>=0){
      const stageChanged = contacts[idx].stage !== nextStage;
      contacts[idx]={...contacts[idx],...data, done:stageChanged ? false : Boolean(contacts[idx].done)};
    }
    toast('مخاطب ویرایش شد');
  } else {
    contacts.unshift({id:makeId(),createdAt:Date.now(),done:false,rewardedStages:[],...data});
    toast('مخاطب به لیست مرجع اضافه شد');
  }
  save(); closeDialog('#contactDialog'); render();
});

function openStageDialog(ids){
  stageTargetIds = ids;
  const options = Object.entries(STAGES).map(([key,v])=>`
    <button type="button" class="stage-option" data-stage-option="${key}"><span>${icon(v.icon)} ${v.label}</span>${icon('i-chevron')}</button>`).join('');
  $('#stageOptions').innerHTML = options + `
    <button type="button" class="stage-option remove-stage" data-stage-option=""><span>${icon('i-users')} فقط در لیست مرجع</span>${icon('i-chevron')}</button>`;
  $$('[data-stage-option]').forEach(btn => btn.onclick = () => {
    const newStage = btn.dataset.stageOption;
    contacts = contacts.map(c => stageTargetIds.includes(c.id) ? {...c, stage:newStage, done:false} : c);
    save(); closeDialog('#stageDialog'); render();
    toast(newStage ? 'مرحله تغییر کرد و تیک انجام‌شده برداشته شد' : 'به لیست مرجع منتقل شد و تیک برداشته شد');
  });
  openDialog('#stageDialog');
}

function openActionDialog(id){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  actionTargetId=id;
  $('#actionContactName').textContent=c.name;
  openDialog('#actionDialog');
}

$('#editContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openContactDialog(id); };
$('#moveContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openStageDialog([id]); };
$('#deleteContactAction').onclick=()=>{
  const c=contacts.find(x=>x.id===actionTargetId); if(!c) return;
  if(confirm(`«${c.name}» از لیست حذف شود؟`)){
    contacts=contacts.filter(x=>x.id!==c.id); save(); closeDialog('#actionDialog'); render(); toast('مخاطب حذف شد');
  }
};
$('#callContactAction').onclick=()=>contactAction(actionTargetId,'call');
$('#smsContactAction').onclick=()=>contactAction(actionTargetId,'sms');
$('#telegramContactAction').onclick=()=>contactAction(actionTargetId,'telegram');

function normalizedPhone(value=''){
  return String(value).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9+]/g,'');
}
function telegramPhone(value=''){
  let p = normalizedPhone(value);
  if (p.startsWith('00')) p = '+' + p.slice(2);
  if (p.startsWith('0') && p.length >= 10) p = '+98' + p.slice(1);
  else if (p.startsWith('98') && !p.startsWith('+')) p = '+' + p;
  return p;
}
function androidBridgeMethod(name){
  return window.AndroidContacts && typeof window.AndroidContacts[name] === 'function';
}
function contactAction(id, type){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  const phone=c.phone;
  try{
    if(type==='call'){
      if(androidBridgeMethod('openDialer')) window.AndroidContacts.openDialer(phone);
      else window.location.href=`tel:${normalizedPhone(phone)}`;
    } else if(type==='sms'){
      if(androidBridgeMethod('openSms')) window.AndroidContacts.openSms(phone);
      else window.location.href=`sms:${normalizedPhone(phone)}`;
    } else if(type==='telegram'){
      if(androidBridgeMethod('openTelegram')) window.AndroidContacts.openTelegram(phone);
      else window.location.href=`tg://resolve?phone=${encodeURIComponent(telegramPhone(phone))}`;
    }
  }catch(e){ toast('باز کردن برنامه مربوطه ممکن نشد'); }
}
window.receiveExternalActionError = function(message){ toast(message || 'باز کردن برنامه مربوطه ممکن نشد'); };

function pickContactFromPhone(){
  if(androidBridgeMethod('pickContact')){
    window.AndroidContacts.pickContact();
  }else{
    toast('در نسخه وب، فایل CSV یا VCF مخاطبین را انتخاب کن');
    $('#contactFile').click();
  }
}
window.receiveAndroidPickedContact = function(payload){
  try{
    const c = typeof payload === 'string' ? JSON.parse(payload) : payload;
    if(!c?.phone){ toast('برای این مخاطب شماره تلفن پیدا نشد'); return; }
    if(!$('#contactDialog').open) openContactDialog();
    $('#nameInput').value = c.name || 'بدون نام';
    $('#phoneInput').value = c.phone || '';
    setTimeout(()=>$('#stageInput').focus(),100);
    toast('مخاطب انتخاب شد؛ مرحله را مشخص کن و ذخیره کن');
  }catch(e){ toast('خواندن مخاطب انتخاب‌شده با خطا روبه‌رو شد'); }
};
window.receiveAndroidContactsError = function(message){ toast(message || 'دسترسی به مخاطبین ممکن نیست'); };

function parseCSVLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch==='"' && line[i+1]==='"' && q){cur+='"';i++;}
    else if(ch==='"')q=!q;
    else if(ch===',' && !q){out.push(cur);cur='';}
    else cur+=ch;
  }
  out.push(cur); return out;
}
async function importContactFile(file){
  if(!file) return;
  const text=await file.text(); let added=0;
  if(file.name.toLowerCase().endsWith('.csv') || file.type.includes('csv')){
    const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean);
    const start = /نام|name/i.test(lines[0]||'') ? 1 : 0;
    for(let i=start;i<lines.length;i++){
      const [name,phone,,note] = parseCSVLine(lines[i]);
      if(name?.trim() && phone?.trim()){
        contacts.unshift({id:makeId(),name:name.trim(),phone:phone.trim(),stage:'',note:(note||'').trim(),done:false,rewardedStages:[],createdAt:Date.now()+added});
        added++;
      }
    }
  }else{
    const cards=text.split(/END:VCARD/i);
    for(const card of cards){
      const name=(card.match(/\nFN(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      const phone=(card.match(/\nTEL(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      if(name&&phone){contacts.unshift({id:makeId(),name,phone,stage:'',note:'از فایل مخاطبین',done:false,rewardedStages:[],createdAt:Date.now()+added});added++;}
    }
  }
  if(added){save();render();toast(`${fa(added)} مخاطب اضافه شد`);} else toast('مخاطبی از فایل پیدا نشد');
}

function exportCSV(){
  const rows=[['نام','شماره','مرحله','انجام شده','یادداشت'],...contacts.map(c=>[c.name,c.phone,c.stage?STAGES[c.stage]?.label||'':'',c.done?'بله':'خیر',c.note||''])];
  const csv='\uFEFF'+rows.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='contacts.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('خروجی CSV ساخته شد');
}

$('#addBtn').onclick=()=>openContactDialog();
$('#importBtn').onclick=()=>{ openContactDialog(); pickContactFromPhone(); };
$('#pickPhoneContactBtn').onclick=pickContactFromPhone;
$('#menuBtn').onclick=()=>openDialog('#menuDialog');
$('#pickContactMenuBtn').onclick=()=>{ closeDialog('#menuDialog'); openContactDialog(); setTimeout(pickContactFromPhone,120); };
$('#fileImportBtn').onclick=()=>{ closeDialog('#menuDialog'); $('#contactFile').click(); };
$('#contactFile').onchange=e=>{ importContactFile(e.target.files?.[0]); e.target.value=''; };
$('#exportBtn').onclick=()=>{exportCSV();closeDialog('#menuDialog')};
$('#clearBtn').onclick=()=>{
  if(confirm('همه مخاطبین و اطلاعات ذخیره‌شده پاک شوند؟')){
    contacts=[];
    game={totalXp:0,todayPoints:0,streak:0,todayCompletions:0,todayDate:dayKey(),lastActivityDate:''};
    save();saveGame();closeDialog('#menuDialog');render();toast('همه داده‌ها و پیشرفت پاک شد');
  }
};


$$('[data-close]').forEach(btn=>btn.onclick=()=>closeDialog(`#${btn.dataset.close}`));
$$('dialog').forEach(d=>d.addEventListener('click',e=>{ if(e.target===d) d.close(); }));


const DAILY_TIPS = [
  {title:'اول اقدام، بعد نتیجه', text:'امروز روی انجام یک اقدام ساده تمرکز کن؛ یک تماس خوب از ده بار فکر کردن ارزشمندتر است.'},
  {title:'یادداشت کوتاه بگذار', text:'بعد از تماس، یک جمله درباره نتیجه بنویس تا فالوآپ بعدی دقیق‌تر و شخصی‌تر باشد.'},
  {title:'مرحله را سریع جلو ببر', text:'وقتی کار یک مرحله انجام شد تیک بزن؛ اگر مخاطب آماده بود به مرحله بعد منتقلش کن تا تیک جدید از صفر شروع شود.'},
  {title:'از افراد گرم شروع کن', text:'مخاطب‌هایی که اخیراً پاسخ داده‌اند یا یادداشت مشخص دارند، معمولاً بهترین نقطه برای شروع امروز هستند.'},
];
let tipIndex = Number(localStorage.getItem('networkCRM.tipIndex') || 0) % DAILY_TIPS.length;
function renderTip(){
  const tip = DAILY_TIPS[tipIndex] || DAILY_TIPS[0];
  $('#tipTitle').textContent = tip.title;
  $('#tipText').textContent = tip.text;
}
function openTips(){ renderTip(); openDialog('#tipsDialog'); }
function openReport(){
  const done = contacts.filter(c=>c.done).length;
  const completion = contacts.length ? Math.round(done / contacts.length * 100) : 0;
  const totalXp = Math.max(0, Number(game.totalXp||0));
  const level = Math.floor(totalXp / XP_PER_LEVEL) + 1;
  $('#reportGrid').innerHTML = `
    <div class="report-kpi"><span>کل مخاطبین</span><strong>${fa(contacts.length)}</strong></div>
    <div class="report-kpi"><span>کارهای تیک‌خورده</span><strong>${fa(done)}</strong></div>
    <div class="report-kpi"><span>نرخ انجام</span><strong>${fa(completion)}٪</strong></div>
    <div class="report-kpi"><span>سطح فعلی</span><strong>${fa(level)}</strong></div>`;
  const maxCount = Math.max(1, ...Object.keys(STAGES).map(k=>contacts.filter(c=>c.stage===k).length));
  $('#reportStageList').innerHTML = Object.entries(STAGES).map(([key,s])=>{
    const n=contacts.filter(c=>c.stage===key).length;
    const width=Math.round(n/maxCount*100);
    return `<div class="report-stage"><strong>${escapeHTML(s.label)}</strong><div class="report-bar"><i style="width:${width}%"></i></div><span>${fa(n)}</span></div>`;
  }).join('');
  $('#reportMessage').textContent = completion >= 70 ? 'ریتمت عالی است؛ همین پیوستگی را حفظ کن.' : completion >= 35 ? 'پیشرفت خوب است؛ چند اقدام کوچک دیگر امروز نتیجه را بهتر می‌کند.' : 'از یک مخاطب شروع کن؛ هر تیک یک قدم واقعی در مسیر پیشرفت است.';
  openDialog('#reportDialog');
}
$('#bottomAddBtn').onclick=()=>openContactDialog();
if($('#tipsBtn')) $('#tipsBtn').onclick=openTips;
if($('#reportBtn')) $('#reportBtn').onclick=openReport;
if($('#nextTipBtn')) $('#nextTipBtn').onclick=()=>{ tipIndex=(tipIndex+1)%DAILY_TIPS.length; localStorage.setItem('networkCRM.tipIndex', String(tipIndex)); renderTip(); };

render();
