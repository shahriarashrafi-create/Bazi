const STAGES = {
  connect: { label: 'ارتباط‌سازی', icon: 'i-users', className: 'connect' },
  preconsult: { label: 'پیش‌مشاوره', icon: 'i-message', className: 'preconsult' },
  invite: { label: 'دعوت', icon: 'i-send', className: 'invite' },
  followup: { label: 'فالوآپ', icon: 'i-check', className: 'followup' },
};

const makeId = () => (crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(16).slice(2)}`);
const now = Date.now();
const seed = [
  {id:makeId(),name:'علی محمدی',phone:'0912 345 6789',stage:'connect',note:'معرفی از طرف حسین',createdAt:now-5_000},
  {id:makeId(),name:'سارا رضایی',phone:'0935 987 6543',stage:'preconsult',note:'علاقه‌مند به اطلاعات بیشتر',createdAt:now-10_000},
  {id:makeId(),name:'مهدی احمدی',phone:'0919 111 2233',stage:'invite',note:'دعوت برای جلسه شنبه',createdAt:now-15_000},
  {id:makeId(),name:'نرگس کریمی',phone:'0912 444 5566',stage:'followup',note:'پیگیری سه‌شنبه',createdAt:now-20_000},
  {id:makeId(),name:'رضا قاسمی',phone:'0930 777 8899',stage:'connect',note:'',createdAt:now-25_000},
  {id:makeId(),name:'الهام موسوی',phone:'0912 222 3344',stage:'preconsult',note:'',createdAt:now-30_000},
  {id:makeId(),name:'حمید نادری',phone:'0936 555 6677',stage:'',note:'از مخاطبین گوشی',createdAt:now-35_000},
  {id:makeId(),name:'کامران عباسی',phone:'0919 888 7766',stage:'followup',note:'منتظر پاسخ',createdAt:now-40_000},
];

const storageKey = 'networkCRM.contacts.v2';
let stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
// مهاجرت داده نسخه قبلی: reference دیگر «مرحله» نیست و به بدون‌مرحله تبدیل می‌شود.
if (!stored) {
  const old = JSON.parse(localStorage.getItem('networkCRM.contacts') || 'null');
  stored = old?.map(c => ({...c, stage: c.stage === 'reference' ? '' : c.stage}));
}
let contacts = Array.isArray(stored) ? stored : seed;
let activeStage = 'all';
let selected = new Set();
let stageTargetIds = [];
let actionTargetId = null;
let filters = { stage: 'all', note: 'any' };

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fa = n => Number(n).toLocaleString('fa-IR');
const escapeHTML = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials = name => name.trim().split(/\s+/).slice(0,2).map(x=>x[0] || '').join('');
const icon = id => `<svg aria-hidden="true"><use href="#${id}"/></svg>`;

function save(){ localStorage.setItem(storageKey, JSON.stringify(contacts)); }
function toast(msg){
  const el = $('#toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(el._timer); el._timer = setTimeout(()=>el.classList.remove('show'), 2200);
}
function openDialog(id){ const d=$(id); if(d && !d.open) d.showModal(); }
function closeDialog(id){ const d=$(id); if(d?.open) d.close(); }

function renderStats(){
  const stats = [
    {key:'all', label:'همه', icon:'i-users', className:'all', count:contacts.length},
    ...Object.entries(STAGES).map(([key,s])=>({key,label:s.label,icon:s.icon,className:s.className,count:contacts.filter(c=>c.stage===key).length}))
  ];
  $('#stats').innerHTML = stats.map(s => `
    <div class="stat ${s.className}" title="${escapeHTML(s.label)}">
      ${icon(s.icon)}
      <span class="label">${escapeHTML(s.label)}</span>
      <span class="num">${fa(s.count)}</span>
    </div>`).join('');
}

function renderTabs(){
  const items = [{key:'all',label:'همه'}, ...Object.entries(STAGES).map(([key,v])=>({key,label:v.label}))];
  $('#stageTabs').innerHTML = items.map(x=>`<button class="stage-tab ${activeStage===x.key?'active':''}" data-stage-tab="${x.key}">${x.label}</button>`).join('');
  $$('[data-stage-tab]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.stageTab;
    filters.stage = 'all';
    $('#filterStage').value = 'all';
    render();
  });
}

function visibleContacts(){
  const q = $('#searchInput').value.trim().toLowerCase();
  let arr = contacts.filter(c => {
    const stageByTab = activeStage === 'all' || c.stage === activeStage;
    const stageByFilter = filters.stage === 'all' || (filters.stage === 'none' ? !c.stage : c.stage === filters.stage);
    const matchesText = !q || [c.name,c.phone,c.note].some(v => (v||'').toLowerCase().includes(q));
    const matchesNote = filters.note === 'any' || (filters.note === 'yes' ? !!c.note?.trim() : !c.note?.trim());
    return stageByTab && stageByFilter && matchesText && matchesNote;
  });
  const sort = $('#sortSelect').value;
  if (sort === 'newest') arr.sort((a,b)=>b.createdAt-a.createdAt);
  if (sort === 'oldest') arr.sort((a,b)=>a.createdAt-b.createdAt);
  if (sort === 'name') arr.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
  return arr;
}

function badgeFor(c){
  if (!c.stage) return `<button class="badge none" data-stage-change="${c.id}" title="انتخاب مرحله">بدون مرحله</button>`;
  const s=STAGES[c.stage];
  return `<button class="badge ${s?.className || 'none'}" data-stage-change="${c.id}" title="تغییر مرحله">${escapeHTML(s?.label || 'بدون مرحله')}</button>`;
}

function renderContacts(){
  const arr=visibleContacts();
  $('#listCount').textContent = `${fa(arr.length)} مخاطب`;
  if(!arr.length){
    $('#contacts').innerHTML = `<div class="empty"><strong>مخاطبی پیدا نشد</strong>جستجو یا فیلتر را تغییر بده، یا مخاطب جدید اضافه کن.</div>`;
    return;
  }
  $('#contacts').innerHTML = arr.map(c => `
    <article class="contact ${selected.has(c.id)?'selected':''}" data-contact-row="${c.id}">
      <input class="check" type="checkbox" aria-label="انتخاب ${escapeHTML(c.name)}" data-id="${c.id}" ${selected.has(c.id)?'checked':''}/>
      <div class="avatar" aria-hidden="true">${escapeHTML(initials(c.name))}</div>
      <div class="info">
        <div class="name">${escapeHTML(c.name)}</div>
        <div class="phone">${escapeHTML(c.phone)}</div>
        ${c.note?`<div class="note">${escapeHTML(c.note)}</div>`:''}
      </div>
      ${badgeFor(c)}
      <button class="chevron-btn" data-edit="${c.id}" aria-label="باز کردن ${escapeHTML(c.name)}">${icon('i-chevron')}</button>
      <button class="menu-btn" data-menu="${c.id}" aria-label="گزینه‌های ${escapeHTML(c.name)}">${icon('i-more')}</button>
    </article>`).join('');

  $$('.check').forEach(box => box.onchange = () => {
    box.checked ? selected.add(box.dataset.id) : selected.delete(box.dataset.id);
    renderContacts(); renderBulk();
  });
  $$('[data-stage-change]').forEach(btn => btn.onclick = () => openStageDialog([btn.dataset.stageChange]));
  $$('[data-edit]').forEach(btn => btn.onclick = () => openContactDialog(btn.dataset.edit));
  $$('[data-menu]').forEach(btn => btn.onclick = () => openActionDialog(btn.dataset.menu));
}

function renderBulk(){
  const bar = $('#bulkBar');
  if(selected.size){ bar.classList.remove('hidden'); $('#selectedCount').textContent=fa(selected.size); }
  else bar.classList.add('hidden');
}
function renderFilterState(){
  const active = filters.stage !== 'all' || filters.note !== 'any';
  $('#filterBtn').classList.toggle('has-filter', active);
}
function render(){ renderStats(); renderTabs(); renderContacts(); renderBulk(); renderFilterState(); }

function openContactDialog(id=null){
  const c = contacts.find(x=>x.id===id);
  $('#dialogTitle').textContent = c ? 'ویرایش مخاطب' : 'افزودن مخاطب';
  $('#contactId').value = c?.id || '';
  $('#nameInput').value = c?.name || '';
  $('#phoneInput').value = c?.phone || '';
  $('#stageInput').value = c?.stage || '';
  $('#noteInput').value = c?.note || '';
  openDialog('#contactDialog');
  setTimeout(()=>$('#nameInput').focus(),50);
}

$('#contactForm').addEventListener('submit', e => {
  e.preventDefault();
  const name=$('#nameInput').value.trim(), phone=$('#phoneInput').value.trim();
  if(!name || !phone){ toast('نام و شماره موبایل را وارد کن'); return; }
  const id=$('#contactId').value;
  const data={name,phone,stage:$('#stageInput').value,note:$('#noteInput').value.trim()};
  if(id){
    const idx=contacts.findIndex(c=>c.id===id);
    if(idx>=0) contacts[idx]={...contacts[idx],...data};
    toast('مخاطب ویرایش شد');
  } else {
    contacts.unshift({id:makeId(),createdAt:Date.now(),...data});
    toast('مخاطب به لیست مرجع اضافه شد');
  }
  save(); closeDialog('#contactDialog'); render();
});

function openStageDialog(ids){
  stageTargetIds = ids;
  const options = Object.entries(STAGES).map(([key,v])=>`
    <button type="button" class="stage-option" data-stage-option="${key}">
      <span>${icon(v.icon)} ${v.label}</span>${icon('i-chevron')}
    </button>`).join('');
  $('#stageOptions').innerHTML = options + `
    <button type="button" class="stage-option remove-stage" data-stage-option="">
      <span>${icon('i-users')} فقط در لیست مرجع</span>${icon('i-chevron')}
    </button>`;
  $$('[data-stage-option]').forEach(btn => btn.onclick = () => {
    contacts = contacts.map(c => stageTargetIds.includes(c.id) ? {...c,stage:btn.dataset.stageOption} : c);
    save(); selected.clear(); closeDialog('#stageDialog'); render();
    toast(btn.dataset.stageOption ? 'مرحله مخاطب تغییر کرد' : 'مخاطب فقط در لیست مرجع قرار گرفت');
  });
  openDialog('#stageDialog');
}

function openActionDialog(id){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  actionTargetId=id;
  $('#actionContactName').textContent=c.name;
  $('#actionContactPhone').textContent=c.phone;
  openDialog('#actionDialog');
}

$('#editContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openContactDialog(id); };
$('#moveContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openStageDialog([id]); };
$('#deleteContactAction').onclick=()=>{
  const c=contacts.find(x=>x.id===actionTargetId); if(!c) return;
  if(confirm(`«${c.name}» از لیست حذف شود؟`)){
    contacts=contacts.filter(x=>x.id!==c.id); selected.delete(c.id); save(); closeDialog('#actionDialog'); render(); toast('مخاطب حذف شد');
  }
};

function normalizedPhone(value=''){
  return String(value).replace(/[^0-9+]/g,'');
}

window.receiveAndroidContacts = function(payload){
  try{
    const picked = typeof payload === 'string' ? JSON.parse(payload) : payload;
    if(!Array.isArray(picked)){ toast('مخاطبی دریافت نشد'); return; }
    const existing = new Set(contacts.map(c=>normalizedPhone(c.phone)));
    let added=0, skipped=0;
    picked.forEach(p=>{
      const name=(p?.name || 'بدون نام').trim();
      const phone=(p?.phone || '').trim();
      const key=normalizedPhone(phone);
      if(!phone) return;
      if(key && existing.has(key)){ skipped++; return; }
      contacts.unshift({id:makeId(),name,phone,stage:'',note:'از مخاطبین گوشی',createdAt:Date.now()+added});
      if(key) existing.add(key);
      added++;
    });
    if(added){ save(); render(); }
    if(added && skipped) toast(`${fa(added)} مخاطب اضافه شد؛ ${fa(skipped)} تکراری نادیده گرفته شد`);
    else if(added) toast(`${fa(added)} مخاطب به لیست مرجع اضافه شد`);
    else if(skipped) toast('همه مخاطبین انتخاب‌شده قبلاً در لیست بودند');
    else toast('مخاطبی برای افزودن پیدا نشد');
  }catch(err){ console.warn(err); toast('ورود مخاطبین با خطا روبه‌رو شد'); }
};

window.receiveAndroidContactsError = function(message){ toast(message || 'دسترسی به مخاطبین ممکن نیست'); };

async function importContacts(){
  // در نسخه APK، این پل مستقیماً مخاطبین گوشی را می‌خواند.
  if(window.AndroidContacts?.importAllContacts){
    window.AndroidContacts.importAllContacts();
    return;
  }
  // نسخه وب در مرورگرهای پشتیبانی‌شده از Contact Picker استفاده می‌کند.
  if(navigator.contacts?.select){
    try{
      const picked=await navigator.contacts.select(['name','tel'],{multiple:true});
      let added=0;
      picked.forEach(p=>{
        const name=p.name?.[0] || 'بدون نام'; const phone=p.tel?.[0] || '';
        if(phone){ contacts.unshift({id:makeId(),name,phone,stage:'',note:'از مخاطبین گوشی',createdAt:Date.now()+added}); added++; }
      });
      if(added){ save(); render(); toast(`${fa(added)} مخاطب به لیست مرجع اضافه شد`); }
      return;
    }catch(err){ if(err?.name==='AbortError') return; console.warn(err); }
  }
  toast('برای این مرورگر، فایل CSV یا VCF مخاطبین را انتخاب کن.');
  setTimeout(()=>$('#contactFile').click(),500);
}

$('#contactFile').addEventListener('change', async e=>{
  const file=e.target.files[0]; if(!file) return;
  const text=await file.text(); let added=0;
  if(file.name.toLowerCase().endsWith('.csv')){
    text.split(/\r?\n/).forEach((line,i)=>{
      if(!line.trim()) return;
      const parts=line.split(',').map(x=>x.trim().replace(/^"|"$/g,''));
      if(i===0 && /name|نام/i.test(parts[0])) return;
      const [name,phone,note='']=parts;
      if(name&&phone){contacts.unshift({id:makeId(),name,phone,stage:'',note,createdAt:Date.now()+added});added++;}
    });
  } else {
    text.split(/END:VCARD/i).forEach(card=>{
      const n=(card.match(/(?:^|\n)FN[^:]*:(.+)/i)||[])[1]?.trim();
      const p=(card.match(/(?:^|\n)TEL[^:]*:(.+)/i)||[])[1]?.trim();
      if(n&&p){contacts.unshift({id:makeId(),name:n,phone:p,stage:'',note:'از فایل مخاطبین',createdAt:Date.now()+added});added++;}
    });
  }
  if(added){save();render();toast(`${fa(added)} مخاطب وارد شد`)} else toast('مخاطبی در فایل پیدا نشد');
  e.target.value='';
});

function exportCSV(){
  const rows=[['نام','شماره','مرحله','یادداشت'],...contacts.map(c=>[c.name,c.phone,c.stage?STAGES[c.stage]?.label||'':'',c.note||''])];
  const csv='\uFEFF'+rows.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='contacts.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('خروجی CSV ساخته شد');
}

$('#searchInput').oninput=()=>renderContacts();
$('#sortSelect').onchange=()=>renderContacts();
$('#addBtn').onclick=()=>openContactDialog();
$('#fab').onclick=()=>openContactDialog();
$('#importBtn').onclick=importContacts;
$('#menuBtn').onclick=()=>openDialog('#menuDialog');
$('#exportBtn').onclick=()=>{exportCSV();closeDialog('#menuDialog')};
$('#clearBtn').onclick=()=>{
  if(confirm('همه مخاطبین و اطلاعات ذخیره‌شده پاک شوند؟')){contacts=[];selected.clear();save();closeDialog('#menuDialog');render();toast('همه داده‌ها پاک شد');}
};

$('#filterBtn').onclick=()=>{
  $('#filterStage').value=filters.stage; $('#filterNote').value=filters.note; openDialog('#filterDialog');
};
$('#filterForm').onsubmit=e=>{
  e.preventDefault(); filters={stage:$('#filterStage').value,note:$('#filterNote').value}; closeDialog('#filterDialog'); render();
};
$('#resetFilterBtn').onclick=()=>{
  filters={stage:'all',note:'any'}; $('#filterStage').value='all';$('#filterNote').value='any';closeDialog('#filterDialog');render();
};

$('#selectAllBtn').onclick=()=>{
  const ids=visibleContacts().map(c=>c.id); const all=ids.length && ids.every(id=>selected.has(id));
  ids.forEach(id=> all ? selected.delete(id) : selected.add(id)); renderContacts();renderBulk();
};
$('#bulkStageBtn').onclick=()=>{ if(selected.size) openStageDialog([...selected]); };
$('#bulkDeleteBtn').onclick=()=>{
  if(!selected.size) return;
  if(confirm(`${fa(selected.size)} مخاطب از لیست حذف شوند؟`)){
    contacts=contacts.filter(c=>!selected.has(c.id));selected.clear();save();render();toast('مخاطبین انتخاب‌شده حذف شدند');
  }
};
$('#bulkNoteBtn').onclick=()=>{if(selected.size){$('#bulkNoteInput').value='';openDialog('#bulkNoteDialog')}};
$('#bulkNoteForm').onsubmit=e=>{
  e.preventDefault(); const note=$('#bulkNoteInput').value.trim(); if(!note)return;
  contacts=contacts.map(c=>selected.has(c.id)?{...c,note:c.note?`${c.note} | ${note}`:note}:c);save();selected.clear();closeDialog('#bulkNoteDialog');render();toast('یادداشت ثبت شد');
};

$$('[data-close]').forEach(btn=>btn.onclick=()=>closeDialog(`#${btn.dataset.close}`));
$$('dialog').forEach(d=>d.addEventListener('click',e=>{ if(e.target===d) d.close(); }));

render();
