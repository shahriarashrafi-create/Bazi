# Network CRM - Android project

این ZIP یک پروژه واقعی Android/Gradle است و برای ساخت APK آماده شده است.

## ساخت APK در GitHub Actions
فایل `settings.gradle` و `gradlew` در ریشه ZIP قرار دارند تا workflow پروژه Android را پیدا کند.

دستور استاندارد ساخت:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK خروجی در این مسیر ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

## قابلیت‌ها
- لیست مرجع مخاطبین
- مراحل ارتباط‌سازی، پیش‌مشاوره، دعوت و فالوآپ
- انتقال مخاطب بین مراحل
- جستجو، فیلتر، مرتب‌سازی و انتخاب گروهی
- افزودن و ویرایش مخاطب
- ورود مستقیم مخاطبین گوشی با permission اندروید
- جلوگیری از ورود تکراری بر اساس شماره تلفن
- ذخیره محلی اطلاعات داخل WebView

## نکته
در اولین استفاده از «مخاطبین گوشی»، اندروید اجازه دسترسی به Contacts را درخواست می‌کند.
