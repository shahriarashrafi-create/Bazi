@echo off
setlocal
set GRADLE_VERSION=8.7
set BASE_DIR=%~dp0
set DIST_DIR=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%
set ZIP_PATH=%BASE_DIR%.gradle-dist\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%BASE_DIR%.gradle-dist" mkdir "%BASE_DIR%.gradle-dist"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_PATH%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_PATH%' '%BASE_DIR%.gradle-dist'"
)
call "%DIST_DIR%\bin\gradle.bat" %*
