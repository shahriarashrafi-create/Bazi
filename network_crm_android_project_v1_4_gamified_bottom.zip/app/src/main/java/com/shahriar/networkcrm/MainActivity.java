package com.shahriar.networkcrm;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int CONTACTS_PERMISSION_REQUEST = 501;
    private static final int FILE_CHOOSER_REQUEST = 502;
    private static final int CONTACT_PICK_REQUEST = 503;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        webView = new WebView(this);
        webView.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidContactsBridge(), "AndroidContacts");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidContactsBridge {
        /** باز کردن انتخاب‌گر بومی اندروید برای انتخاب فقط یک مخاطب در هر بار. */
        @JavascriptInterface
        public void pickContact() {
            runOnUiThread(MainActivity.this::launchContactPicker);
        }

        /** برای سازگاری با نسخه قبلی نگه داشته شده است. */
        @JavascriptInterface
        public void importAllContacts() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                    readContactsAndSendToWeb();
                } else {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_PERMISSION_REQUEST);
                }
            });
        }

        /** فقط شماره‌گیر را باز می‌کند؛ تماس خودکار برقرار نمی‌شود و مجوز CALL_PHONE لازم نیست. */
        @JavascriptInterface
        public void openDialer(String phone) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone == null ? "" : phone)));
                    startActivity(intent);
                } catch (Exception e) {
                    sendExternalActionError("باز کردن شماره‌گیر ممکن نشد.");
                }
            });
        }

        /** برنامه پیامک را با شماره مخاطب باز می‌کند؛ پیام بدون تایید کاربر ارسال نمی‌شود. */
        @JavascriptInterface
        public void openSms(String phone) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone)));
                    startActivity(intent);
                } catch (Exception e) {
                    sendExternalActionError("باز کردن پیامک ممکن نشد.");
                }
            });
        }

        /** تلاش می‌کند چت تلگرام را با شماره بین‌المللی مخاطب باز کند. */
        @JavascriptInterface
        public void openTelegram(String phone) {
            runOnUiThread(() -> {
                String normalized = normalizeTelegramPhone(phone);
                try {
                    Uri uri = Uri.parse("tg://resolve?phone=" + Uri.encode(normalized));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    sendExternalActionError("تلگرام روی گوشی نصب نیست یا این لینک را پشتیبانی نمی‌کند.");
                } catch (Exception e) {
                    sendExternalActionError("باز کردن تلگرام ممکن نشد.");
                }
            });
        }
    }

    private void launchContactPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(intent, CONTACT_PICK_REQUEST);
        } catch (ActivityNotFoundException e) {
            sendContactImportError("برنامه مخاطبین گوشی در دسترس نیست.");
        } catch (Exception e) {
            sendContactImportError("باز کردن مخاطبین گوشی ممکن نشد.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CONTACTS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                readContactsAndSendToWeb();
            } else {
                sendContactImportError("برای وارد کردن همه مخاطبین، دسترسی مخاطبین را فعال کنید.");
            }
        }
    }

    private void readPickedContact(Uri uri) {
        if (uri == null) return;
        String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };

        try (Cursor cursor = getContentResolver().query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String name = nameIndex >= 0 ? cursor.getString(nameIndex) : "";
                String phone = phoneIndex >= 0 ? cursor.getString(phoneIndex) : "";
                if (name == null || name.trim().isEmpty()) name = "بدون نام";
                if (phone == null || phone.trim().isEmpty()) {
                    sendContactImportError("برای این مخاطب شماره تلفن پیدا نشد.");
                    return;
                }

                JSONObject item = new JSONObject();
                item.put("name", name.trim());
                item.put("phone", phone.trim());
                evaluateJs("window.receiveAndroidPickedContact(" + item.toString() + ")");
            } else {
                sendContactImportError("اطلاعات مخاطب انتخاب‌شده خوانده نشد.");
            }
        } catch (Exception e) {
            sendContactImportError("خواندن مخاطب انتخاب‌شده با خطا روبه‌رو شد.");
        }
    }

    private void readContactsAndSendToWeb() {
        final Map<String, JSONObject> unique = new LinkedHashMap<>();
        String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };

        try (Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC")) {

            if (cursor != null) {
                int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                while (cursor.moveToNext()) {
                    String name = nameIndex >= 0 ? cursor.getString(nameIndex) : "";
                    String phone = phoneIndex >= 0 ? cursor.getString(phoneIndex) : "";
                    if (phone == null || phone.trim().isEmpty()) continue;
                    if (name == null || name.trim().isEmpty()) name = "بدون نام";
                    String normalized = phone.replaceAll("[^0-9+]", "");
                    if (normalized.isEmpty()) normalized = phone;
                    if (unique.containsKey(normalized)) continue;
                    JSONObject item = new JSONObject();
                    item.put("name", name.trim());
                    item.put("phone", phone.trim());
                    unique.put(normalized, item);
                }
            }

            JSONArray array = new JSONArray();
            for (JSONObject obj : unique.values()) array.put(obj);
            String encoded = JSONObject.quote(array.toString());
            evaluateJs("window.receiveAndroidContacts && window.receiveAndroidContacts(" + encoded + ")");
        } catch (Exception e) {
            sendContactImportError("خواندن مخاطبین گوشی با خطا روبه‌رو شد.");
        }
    }

    private String normalizeTelegramPhone(String value) {
        if (value == null) return "";
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if (ch >= '0' && ch <= '9') digits.append(ch);
            else if (ch >= '\u06F0' && ch <= '\u06F9') digits.append((char) ('0' + (ch - '\u06F0')));
            else if (ch >= '\u0660' && ch <= '\u0669') digits.append((char) ('0' + (ch - '\u0660')));
            else if (ch == '+' && digits.length() == 0) digits.append(ch);
        }
        String p = digits.toString();
        if (p.startsWith("00")) p = "+" + p.substring(2);
        if (p.startsWith("0") && p.length() >= 10) p = "+98" + p.substring(1);
        else if (p.startsWith("98")) p = "+" + p;
        return p;
    }

    private void sendContactImportError(String message) {
        String encoded = JSONObject.quote(message);
        evaluateJs("window.receiveAndroidContactsError && window.receiveAndroidContactsError(" + encoded + ")");
    }

    private void sendExternalActionError(String message) {
        String encoded = JSONObject.quote(message);
        evaluateJs("window.receiveExternalActionError && window.receiveExternalActionError(" + encoded + ")");
    }

    private void evaluateJs(String javascript) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(javascript, null);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CONTACT_PICK_REQUEST) {
            if (resultCode == RESULT_OK && data != null) readPickedContact(data.getData());
            return;
        }

        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidContacts");
            webView.destroy();
        }
        super.onDestroy();
    }
}
