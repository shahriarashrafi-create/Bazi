const STAGES = {
  connect: { label: 'ارتباط‌سازی', icon: 'i-users', className: 'connect' },
  preconsult: { label: 'پیش‌مشاوره', icon: 'i-message', className: 'preconsult' },
  invite: { label: 'دعوت', icon: 'i-send', className: 'invite' },
  followup: { label: 'فالوآپ', icon: 'i-check', className: 'followup' },
};

const makeId = () => (globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(16).slice(2)}`);
const now = Date.now();
const seed = [
  {id:makeId(),name:'علی محمدی',phone:'0912 345 6789',stage:'connect',note:'معرفی از طرف حسین',done:false,createdAt:now-5_000},
  {id:makeId(),name:'سارا رضایی',phone:'0935 987 6543',stage:'preconsult',note:'علاقه‌مند به اطلاعات بیشتر',done:true,createdAt:now-10_000},
  {id:makeId(),name:'مهدی احمدی',phone:'0919 111 2233',stage:'invite',note:'دعوت برای جلسه شنبه',done:false,createdAt:now-15_000},
  {id:makeId(),name:'نرگس کریمی',phone:'0912 444 5566',stage:'followup',note:'پیگیری سه‌شنبه',done:false,createdAt:now-20_000},
  {id:makeId(),name:'رضا قاسمی',phone:'0930 777 8899',stage:'connect',note:'',done:false,createdAt:now-25_000},
  {id:makeId(),name:'الهام موسوی',phone:'0912 222 3344',stage:'preconsult',note:'',done:false,createdAt:now-30_000},
  {id:makeId(),name:'حمید نادری',phone:'0936 555 6677',stage:'',note:'از مخاطبین گوشی',done:false,createdAt:now-35_000},
  {id:makeId(),name:'کامران عباسی',phone:'0919 888 7766',stage:'followup',note:'منتظر پاسخ',done:false,createdAt:now-40_000},
];

const storageKey = 'networkCRM.contacts.v3';
let stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
if (!stored) {
  const previous = JSON.parse(localStorage.getItem('networkCRM.contacts.v2') || 'null') || JSON.parse(localStorage.getItem('networkCRM.contacts') || 'null');
  if (Array.isArray(previous)) {
    stored = previous.map(c => ({
      ...c,
      stage: c.stage === 'reference' ? '' : (c.stage || ''),
      done: Boolean(c.done),
    }));
  }
}
let contacts = Array.isArray(stored) ? stored.map(c=>({...c, done:Boolean(c.done)})) : seed;
let activeStage = 'all';
let stageTargetIds = [];
let actionTargetId = null;
let filters = { stage: 'all', note: 'any', done: 'any' };

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fa = n => Number(n).toLocaleString('fa-IR');
const escapeHTML = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials = name => String(name || '').trim().split(/\s+/).slice(0,2).map(x=>x[0] || '').join('');
const icon = id => `<svg aria-hidden="true"><use href="#${id}"/></svg>`;

function save(){ localStorage.setItem(storageKey, JSON.stringify(contacts)); }
function toast(msg){
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._timer);
  el._timer = setTimeout(()=>el.classList.remove('show'), 2300);
}
function openDialog(id){ const d=$(id); if(d && !d.open) d.showModal(); }
function closeDialog(id){ const d=$(id); if(d?.open) d.close(); }

function renderStats(){
  const stats = [
    {key:'all', label:'همه', icon:'i-users', className:'all', count:contacts.length},
    ...Object.entries(STAGES).map(([key,s])=>({key,label:s.label,icon:s.icon,className:s.className,count:contacts.filter(c=>c.stage===key).length}))
  ];
  $('#stats').innerHTML = stats.map(s => `
    <div class="stat ${s.className}" title="${escapeHTML(s.label)}">
      ${icon(s.icon)}<span class="label">${escapeHTML(s.label)}</span><span class="num">${fa(s.count)}</span>
    </div>`).join('');
}

function renderTabs(){
  const items = [{key:'all',label:'همه'}, ...Object.entries(STAGES).map(([key,v])=>({key,label:v.label}))];
  $('#stageTabs').innerHTML = items.map(x=>`<button class="stage-tab ${activeStage===x.key?'active':''}" data-stage-tab="${x.key}">${x.label}</button>`).join('');
  $$('[data-stage-tab]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.stageTab;
    filters.stage = 'all';
    $('#filterStage').value = 'all';
    render();
  });
}

function visibleContacts(){
  const q = $('#searchInput').value.trim().toLowerCase();
  let arr = contacts.filter(c => {
    const stageByTab = activeStage === 'all' || c.stage === activeStage;
    const stageByFilter = filters.stage === 'all' || (filters.stage === 'none' ? !c.stage : c.stage === filters.stage);
    const matchesText = !q || [c.name,c.phone,c.note].some(v => (v||'').toLowerCase().includes(q));
    const matchesNote = filters.note === 'any' || (filters.note === 'yes' ? !!c.note?.trim() : !c.note?.trim());
    const matchesDone = filters.done === 'any' || (filters.done === 'yes' ? !!c.done : !c.done);
    return stageByTab && stageByFilter && matchesText && matchesNote && matchesDone;
  });
  const sort = $('#sortSelect').value;
  if (sort === 'newest') arr.sort((a,b)=>b.createdAt-a.createdAt);
  if (sort === 'oldest') arr.sort((a,b)=>a.createdAt-b.createdAt);
  if (sort === 'name') arr.sort((a,b)=>a.name.localeCompare(b.name,'fa'));
  return arr;
}

function badgeFor(c){
  if (!c.stage) return `<button class="badge none" data-stage-change="${c.id}" title="انتخاب مرحله">بدون مرحله</button>`;
  const s=STAGES[c.stage];
  return `<button class="badge ${s?.className || 'none'}" data-stage-change="${c.id}" title="تغییر مرحله">${escapeHTML(s?.label || 'بدون مرحله')}</button>`;
}

function renderContacts(){
  const arr = visibleContacts();
  $('#listCount').textContent = `${fa(arr.length)} مخاطب`;
  if(!arr.length){
    $('#contacts').innerHTML = `<div class="empty"><strong>مخاطبی پیدا نشد</strong>جستجو یا فیلتر را تغییر بده، یا مخاطب جدید اضافه کن.</div>`;
    return;
  }

  $('#contacts').innerHTML = arr.map(c => `
    <article class="contact ${c.done?'done':''}" data-contact-row="${c.id}">
      <input class="done-check" type="checkbox" aria-label="${c.done?'برداشتن تیک':'علامت انجام شد برای'} ${escapeHTML(c.name)}" data-done="${c.id}" ${c.done?'checked':''} />
      <div class="avatar" aria-hidden="true">${escapeHTML(initials(c.name))}</div>
      <div class="info">
        <div class="name">${escapeHTML(c.name)}</div>
        <div class="phone">${escapeHTML(c.phone)}</div>
        ${c.note?`<div class="note">${escapeHTML(c.note)}</div>`:''}
        <div class="quick-actions">
          <button type="button" data-call="${c.id}" aria-label="تماس با ${escapeHTML(c.name)}">${icon('i-phone')}<span>تماس</span></button>
          <button type="button" data-sms="${c.id}" aria-label="پیامک به ${escapeHTML(c.name)}">${icon('i-sms')}<span>پیام</span></button>
          <button type="button" class="telegram" data-telegram="${c.id}" aria-label="تلگرام ${escapeHTML(c.name)}">${icon('i-telegram')}<span>تلگرام</span></button>
        </div>
      </div>
      ${badgeFor(c)}
      <button class="menu-btn" data-menu="${c.id}" aria-label="گزینه‌های ${escapeHTML(c.name)}">${icon('i-more')}</button>
    </article>`).join('');

  $$('[data-done]').forEach(box => box.onchange = () => {
    const id = box.dataset.done;
    contacts = contacts.map(c => c.id === id ? {...c, done:box.checked} : c);
    save();
    renderContacts();
    toast(box.checked ? 'این کار انجام‌شده علامت خورد' : 'تیک انجام‌شده برداشته شد');
  });
  $$('[data-stage-change]').forEach(btn => btn.onclick = () => openStageDialog([btn.dataset.stageChange]));
  $$('[data-menu]').forEach(btn => btn.onclick = () => openActionDialog(btn.dataset.menu));
  $$('[data-call]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.call, 'call'));
  $$('[data-sms]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.sms, 'sms'));
  $$('[data-telegram]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.telegram, 'telegram'));
}

function renderFilterState(){
  const active = filters.stage !== 'all' || filters.note !== 'any' || filters.done !== 'any';
  $('#filterBtn').classList.toggle('has-filter', active);
}
function render(){ renderStats(); renderTabs(); renderContacts(); renderFilterState(); }

function openContactDialog(id=null){
  const c = contacts.find(x=>x.id===id);
  $('#dialogTitle').textContent = c ? 'ویرایش مخاطب' : 'افزودن مخاطب';
  $('#contactId').value = c?.id || '';
  $('#nameInput').value = c?.name || '';
  $('#phoneInput').value = c?.phone || '';
  $('#stageInput').value = c?.stage || '';
  $('#noteInput').value = c?.note || '';
  openDialog('#contactDialog');
  if (c) setTimeout(()=>$('#nameInput').focus(),50);
}

$('#contactForm').addEventListener('submit', e => {
  e.preventDefault();
  const name=$('#nameInput').value.trim(), phone=$('#phoneInput').value.trim();
  if(!name || !phone){ toast('نام و شماره موبایل را وارد کن'); return; }
  const id=$('#contactId').value;
  const nextStage=$('#stageInput').value;
  const data={name,phone,stage:nextStage,note:$('#noteInput').value.trim()};
  if(id){
    const idx=contacts.findIndex(c=>c.id===id);
    if(idx>=0){
      const stageChanged = contacts[idx].stage !== nextStage;
      contacts[idx]={...contacts[idx],...data, done:stageChanged ? false : Boolean(contacts[idx].done)};
    }
    toast('مخاطب ویرایش شد');
  } else {
    contacts.unshift({id:makeId(),createdAt:Date.now(),done:false,...data});
    toast('مخاطب به لیست مرجع اضافه شد');
  }
  save(); closeDialog('#contactDialog'); render();
});

function openStageDialog(ids){
  stageTargetIds = ids;
  const options = Object.entries(STAGES).map(([key,v])=>`
    <button type="button" class="stage-option" data-stage-option="${key}"><span>${icon(v.icon)} ${v.label}</span>${icon('i-chevron')}</button>`).join('');
  $('#stageOptions').innerHTML = options + `
    <button type="button" class="stage-option remove-stage" data-stage-option=""><span>${icon('i-users')} فقط در لیست مرجع</span>${icon('i-chevron')}</button>`;
  $$('[data-stage-option]').forEach(btn => btn.onclick = () => {
    const newStage = btn.dataset.stageOption;
    contacts = contacts.map(c => stageTargetIds.includes(c.id) ? {...c, stage:newStage, done:false} : c);
    save(); closeDialog('#stageDialog'); render();
    toast(newStage ? 'مرحله تغییر کرد و تیک انجام‌شده برداشته شد' : 'به لیست مرجع منتقل شد و تیک برداشته شد');
  });
  openDialog('#stageDialog');
}

function openActionDialog(id){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  actionTargetId=id;
  $('#actionContactName').textContent=c.name;
  $('#actionContactPhone').textContent=c.phone;
  openDialog('#actionDialog');
}

$('#editContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openContactDialog(id); };
$('#moveContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openStageDialog([id]); };
$('#deleteContactAction').onclick=()=>{
  const c=contacts.find(x=>x.id===actionTargetId); if(!c) return;
  if(confirm(`«${c.name}» از لیست حذف شود؟`)){
    contacts=contacts.filter(x=>x.id!==c.id); save(); closeDialog('#actionDialog'); render(); toast('مخاطب حذف شد');
  }
};
$('#callContactAction').onclick=()=>contactAction(actionTargetId,'call');
$('#smsContactAction').onclick=()=>contactAction(actionTargetId,'sms');
$('#telegramContactAction').onclick=()=>contactAction(actionTargetId,'telegram');

function normalizedPhone(value=''){
  return String(value).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9+]/g,'');
}
function telegramPhone(value=''){
  let p = normalizedPhone(value);
  if (p.startsWith('00')) p = '+' + p.slice(2);
  if (p.startsWith('0') && p.length >= 10) p = '+98' + p.slice(1);
  else if (p.startsWith('98') && !p.startsWith('+')) p = '+' + p;
  return p;
}
function androidBridgeMethod(name){
  return window.AndroidContacts && typeof window.AndroidContacts[name] === 'function';
}
function contactAction(id, type){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  const phone=c.phone;
  try{
    if(type==='call'){
      if(androidBridgeMethod('openDialer')) window.AndroidContacts.openDialer(phone);
      else window.location.href=`tel:${normalizedPhone(phone)}`;
    } else if(type==='sms'){
      if(androidBridgeMethod('openSms')) window.AndroidContacts.openSms(phone);
      else window.location.href=`sms:${normalizedPhone(phone)}`;
    } else if(type==='telegram'){
      if(androidBridgeMethod('openTelegram')) window.AndroidContacts.openTelegram(phone);
      else window.location.href=`tg://resolve?phone=${encodeURIComponent(telegramPhone(phone))}`;
    }
  }catch(e){ toast('باز کردن برنامه مربوطه ممکن نشد'); }
}
window.receiveExternalActionError = function(message){ toast(message || 'باز کردن برنامه مربوطه ممکن نشد'); };

function pickContactFromPhone(){
  if(androidBridgeMethod('pickContact')){
    window.AndroidContacts.pickContact();
  }else{
    toast('در نسخه وب، فایل CSV یا VCF مخاطبین را انتخاب کن');
    $('#contactFile').click();
  }
}
window.receiveAndroidPickedContact = function(payload){
  try{
    const c = typeof payload === 'string' ? JSON.parse(payload) : payload;
    if(!c?.phone){ toast('برای این مخاطب شماره تلفن پیدا نشد'); return; }
    if(!$('#contactDialog').open) openContactDialog();
    $('#nameInput').value = c.name || 'بدون نام';
    $('#phoneInput').value = c.phone || '';
    setTimeout(()=>$('#stageInput').focus(),100);
    toast('مخاطب انتخاب شد؛ مرحله را مشخص کن و ذخیره کن');
  }catch(e){ toast('خواندن مخاطب انتخاب‌شده با خطا روبه‌رو شد'); }
};
window.receiveAndroidContactsError = function(message){ toast(message || 'دسترسی به مخاطبین ممکن نیست'); };

function parseCSVLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch==='"' && line[i+1]==='"' && q){cur+='"';i++;}
    else if(ch==='"')q=!q;
    else if(ch===',' && !q){out.push(cur);cur='';}
    else cur+=ch;
  }
  out.push(cur); return out;
}
async function importContactFile(file){
  if(!file) return;
  const text=await file.text(); let added=0;
  if(file.name.toLowerCase().endsWith('.csv') || file.type.includes('csv')){
    const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean);
    const start = /نام|name/i.test(lines[0]||'') ? 1 : 0;
    for(let i=start;i<lines.length;i++){
      const [name,phone,,note] = parseCSVLine(lines[i]);
      if(name?.trim() && phone?.trim()){
        contacts.unshift({id:makeId(),name:name.trim(),phone:phone.trim(),stage:'',note:(note||'').trim(),done:false,createdAt:Date.now()+added});
        added++;
      }
    }
  }else{
    const cards=text.split(/END:VCARD/i);
    for(const card of cards){
      const name=(card.match(/\nFN(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      const phone=(card.match(/\nTEL(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      if(name&&phone){contacts.unshift({id:makeId(),name,phone,stage:'',note:'از فایل مخاطبین',done:false,createdAt:Date.now()+added});added++;}
    }
  }
  if(added){save();render();toast(`${fa(added)} مخاطب اضافه شد`);} else toast('مخاطبی از فایل پیدا نشد');
}

function exportCSV(){
  const rows=[['نام','شماره','مرحله','انجام شده','یادداشت'],...contacts.map(c=>[c.name,c.phone,c.stage?STAGES[c.stage]?.label||'':'',c.done?'بله':'خیر',c.note||''])];
  const csv='\uFEFF'+rows.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='contacts.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('خروجی CSV ساخته شد');
}

$('#searchInput').oninput=()=>renderContacts();
$('#sortSelect').onchange=()=>renderContacts();
$('#addBtn').onclick=()=>openContactDialog();
$('#fab').onclick=()=>openContactDialog();
$('#importBtn').onclick=()=>{ openContactDialog(); pickContactFromPhone(); };
$('#pickPhoneContactBtn').onclick=pickContactFromPhone;
$('#menuBtn').onclick=()=>openDialog('#menuDialog');
$('#pickContactMenuBtn').onclick=()=>{ closeDialog('#menuDialog'); openContactDialog(); setTimeout(pickContactFromPhone,120); };
$('#fileImportBtn').onclick=()=>{ closeDialog('#menuDialog'); $('#contactFile').click(); };
$('#contactFile').onchange=e=>{ importContactFile(e.target.files?.[0]); e.target.value=''; };
$('#exportBtn').onclick=()=>{exportCSV();closeDialog('#menuDialog')};
$('#clearBtn').onclick=()=>{
  if(confirm('همه مخاطبین و اطلاعات ذخیره‌شده پاک شوند؟')){contacts=[];save();closeDialog('#menuDialog');render();toast('همه داده‌ها پاک شد');}
};

$('#filterBtn').onclick=()=>{
  $('#filterStage').value=filters.stage; $('#filterNote').value=filters.note; $('#filterDone').value=filters.done; openDialog('#filterDialog');
};
$('#filterForm').onsubmit=e=>{
  e.preventDefault();
  filters={stage:$('#filterStage').value,note:$('#filterNote').value,done:$('#filterDone').value};
  closeDialog('#filterDialog'); render();
};
$('#resetFilterBtn').onclick=()=>{
  filters={stage:'all',note:'any',done:'any'};
  $('#filterStage').value='all';$('#filterNote').value='any';$('#filterDone').value='any';
  closeDialog('#filterDialog');render();
};

$$('[data-close]').forEach(btn=>btn.onclick=()=>closeDialog(`#${btn.dataset.close}`));
$$('dialog').forEach(d=>d.addEventListener('click',e=>{ if(e.target===d) d.close(); }));

render();
